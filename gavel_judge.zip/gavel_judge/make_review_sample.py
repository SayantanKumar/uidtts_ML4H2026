#!/usr/bin/env python3
"""
make_review_sample.py

Builds the manual review packets from the GAVEL round robin judge outputs.

Drop this in the judge_outputs folder and run it:

    cd judge_outputs
    python3 make_review_sample.py

Sampling. 150 discrepancies, 50 from each of the three pairings. A finding
belongs to a pair of extractors, not to one extractor, so "50 per pairing" is
the only split that is both disjoint and balanced. Within a pairing the 50 are
stratified by finding type, because the decisive findings are 58% TIMING and a
simple random draw would land about 5 VALUE and 8 DUPLICATE across the whole
sample, which is too few to say anything about either.

Reviewer split. The 150 become three packets of 50: one reviewed by both people
for inter-annotator agreement, one for each reviewer alone. Every packet is
balanced across pairings and strata, so the agreement estimate is not drawn
from one corner of the corpus.

Outputs, all under manual_review/:

    README.md               the instructions to send with the packets
    common_50/review.xlsx   both reviewers, do this one first
    <name_a>_50/review.xlsx
    <name_b>_50/review.xlsx
    sample_manifest.csv     all 150 with full provenance, for the merge later

Standard library plus openpyxl.
"""

import argparse
import collections
import csv
import json
import os
import random
import sys

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
except ImportError:
    sys.exit("openpyxl is needed: pip install openpyxl")

# stratum -> how many per pairing. Sums to 50.
ALLOCATION = collections.OrderedDict([
    ("TIMING", 15),
    ("B_ONLY", 10),
    ("A_ONLY", 8),
    ("DUPLICATE", 7),
    ("VALUE", 5),
    ("UNCLEAR", 5),
])

VERDICTS = ["A", "B", "BOTH", "NEITHER", "UNCLEAR"]

# columns the reviewer fills in
REVIEW_COLS = [
    ("judge_correct", 15, "yes or no. Did the judge reach the right verdict? Judge the "
                          "verdict itself; if it is right but the reasoning or the cited "
                          "evidence is wrong, mark yes and say so in notes."),
    ("notes", 70, "Optional. Why it is wrong, or anything worth saying. Leave blank when "
                  "the judge was simply right."),
]

CONTEXT_COLS = [
    ("id", 10), ("pairing", 16), ("case", 12), ("A is", 8), ("B is", 8),
    ("type", 13), ("judge verdict", 13), ("grounding", 11), ("polarity", 9),
    ("A event", 42), ("A time", 9), ("B event", 42), ("B time", 9),
    ("note evidence", 60), ("table evidence", 50), ("judge reason", 55),
]

HEADER_FILL = PatternFill("solid", fgColor="17635F")
INPUT_FILL = PatternFill("solid", fgColor="FFF7D6")
BAND_FILL = PatternFill("solid", fgColor="F1F3EE")
THIN = Side(style="thin", color="DCDFD8")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def stratum_of(finding):
    verdict = finding.get("verdict")
    if verdict in ("A", "B"):
        return finding.get("type")
    if verdict == "UNCLEAR":
        return "UNCLEAR"
    return None  # BOTH and NEITHER are not sampled


def collect(root, drop):
    pool = collections.defaultdict(list)
    skipped = []
    for name in sorted(os.listdir(root)):
        folder = os.path.join(root, name)
        if not os.path.isdir(folder) or "_vs_" not in name or name.startswith((".", "__")):
            continue
        a_name, b_name = name.split("_vs_", 1)
        for fn in sorted(os.listdir(folder)):
            if not fn.endswith(".json"):
                continue
            case = fn[:-5]
            if (name, case) in drop:
                skipped.append(f"{name}/{case}")
                continue
            try:
                obj = json.load(open(os.path.join(folder, fn), encoding="utf-8"))
            except Exception as exc:
                sys.stderr.write(f"skipping {folder}/{fn}: {exc}\n")
                continue
            if not isinstance(obj, list):
                continue
            for i, f in enumerate(obj):
                if not isinstance(f, dict):
                    continue
                s = stratum_of(f)
                if s in ALLOCATION:
                    pool[(name, s)].append(dict(
                        pairing=name, a_name=a_name, b_name=b_name,
                        case=case, idx=i, stratum=s, f=f))
    return pool, skipped


def choose_cases(pool, pairings, n_cases, rng, tries=5000):
    """Pick n_cases at random, but only from cases every pairing judged, and only
    a set that can actually supply the allocation. VALUE in glm52_vs_dsv32 runs
    under half a finding per case, so a blind draw of 10 comes up short about
    three times in four. Rejection sampling keeps the strata exact; the cost is a
    mild tilt toward cases carrying more VALUE and DUPLICATE findings."""
    seen = collections.defaultdict(set)
    for (pairing, _), rows in pool.items():
        for r in rows:
            seen[pairing].add(r["case"])
    common = sorted(set.intersection(*[seen[p] for p in pairings])) if pairings else []
    if len(common) <= n_cases:
        return common, 0
    supply = collections.defaultdict(collections.Counter)
    for (pairing, stratum), rows in pool.items():
        for r in rows:
            supply[(pairing, r["case"])][stratum] += 1
    for attempt in range(1, tries + 1):
        pick = rng.sample(common, n_cases)
        if all(sum(supply[(p, c)][s] for c in pick) >= want
               for p in pairings for s, want in ALLOCATION.items()):
            return sorted(pick), attempt
    return sorted(rng.sample(common, n_cases)), -1


def restrict(pool, cases):
    keep = set(cases)
    return {k: [r for r in rows if r["case"] in keep] for k, rows in pool.items()}


def sample(pool, pairings, rng):
    picked = []
    short = []
    for pairing in pairings:
        for stratum, want in ALLOCATION.items():
            have = pool.get((pairing, stratum), [])
            if len(have) < want:
                short.append((pairing, stratum, len(have), want))
            take = rng.sample(have, min(want, len(have)))
            picked.extend(take)
    return picked, short


SECTIONS = {
    "note": ("===== BEGIN DISCHARGE NOTE =====", "===== END DISCHARGE NOTE ====="),
    "a": ("===== BEGIN TIMELINE A =====", "===== END TIMELINE A ====="),
    "b": ("===== BEGIN TIMELINE B =====", "===== END TIMELINE B ====="),
    "structured": ("===== BEGIN STRUCTURED EVIDENCE =====", "===== END STRUCTURED EVIDENCE ====="),
}


def carve(text, key):
    start, end = SECTIONS[key]
    i = text.index(start) + len(start)
    return text[i:text.index(end)].strip("\n")


def find_prompts(root, given):
    """Locate the round robin prompt folder. It is the only place the note,
    the structured evidence and the two timelines exist together in the exact
    form the judge saw them."""
    if given:
        candidates = [given]
    else:
        parent = os.path.dirname(os.path.abspath(root))
        candidates = [os.path.join(root, "round_robin_prompts"),
                      os.path.join(parent, "round_robin_prompts_MIMIC"),
                      os.path.join(parent, "round_robin_prompts")]
        candidates += [os.path.join(parent, d) for d in sorted(os.listdir(parent))
                       if d.startswith("round_robin_prompts")]
    for c in candidates:
        if os.path.isdir(c) and any(
                os.path.isdir(os.path.join(c, d)) and "_vs_" in d for d in os.listdir(c)):
            return c
    return None


def write_case_material(out_root, picked, prompts):
    """One folder per case, holding the note, the structured evidence and every
    timeline the sampled rows refer to. A timeline, the note and the structured
    summary are byte-identical across the pairings a case appears in, so each is
    written once."""
    wanted = collections.defaultdict(set)
    seen = {}
    for row in picked:
        wanted[row["case"]].add((row["pairing"], row["a_name"], row["b_name"]))
    written = 0
    for case, pairs in sorted(wanted.items()):
        folder = os.path.join(out_root, "cases", case)
        os.makedirs(folder, exist_ok=True)
        for pairing, a_name, b_name in sorted(pairs):
            path = os.path.join(prompts, pairing, f"prompt_{case}.txt")
            if not os.path.isfile(path):
                sys.stderr.write(f"no prompt file for {pairing}/{case}, "
                                 f"case material incomplete\n")
                continue
            text = open(path, encoding="utf-8").read()
            if case not in seen:
                open(os.path.join(folder, "discharge_note.txt"), "w",
                     encoding="utf-8").write(carve(text, "note") + "\n")
                open(os.path.join(folder, "structured_evidence.txt"), "w",
                     encoding="utf-8").write(carve(text, "structured") + "\n")
                seen[case] = True
                written += 2
            for key, name in (("a", a_name), ("b", b_name)):
                dest = os.path.join(folder, f"timeline_{name}.txt")
                if not os.path.exists(dest):
                    open(dest, "w", encoding="utf-8").write(carve(text, key) + "\n")
                    written += 1
    return len(wanted), written


def deal(picked, packets, rng):
    """Round robin within each (pairing, stratum) cell so every packet ends up
    balanced on both, rather than one packet drawing a whole stratum."""
    cells = collections.defaultdict(list)
    for row in picked:
        cells[(row["pairing"], row["stratum"])].append(row)
    buckets = {name: [] for name in packets}
    order = list(packets)
    turn = 0
    for key in sorted(cells):
        group = cells[key]
        rng.shuffle(group)
        for row in group:
            buckets[order[turn % len(order)]].append(row)
            turn += 1
    return buckets


def sheet_row(row, n):
    f = row["f"]

    def g(k):
        v = f.get(k)
        return "" if v is None else str(v)

    return [
        n, row["pairing"], row["case"], row["a_name"], row["b_name"],
        g("type"), g("verdict"), g("grounding"), g("polarity"),
        g("a_event"), g("a_time"), g("b_event"), g("b_time"),
        g("note_evidence"), g("table_evidence"), g("reason"),
    ]


def write_workbook(path, rows, title, blurb):
    wb = Workbook()
    ws = wb.active
    ws.title = "review"

    ws["A1"] = title
    ws["A1"].font = Font(name="Arial", size=13, bold=True)
    ws["A2"] = blurb
    ws["A2"].font = Font(name="Arial", size=10, italic=True, color="5C6B73")
    ws["A3"] = ("Fill in the five shaded columns on the right. Everything left of them is the "
                "judge's output and should not be edited. Open the matching prompt file for the "
                "note and the structured evidence: <pairing>/prompt_<case>.txt")
    ws["A3"].font = Font(name="Arial", size=10, color="5C6B73")
    for r in (1, 2, 3):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=len(CONTEXT_COLS))

    head = 5
    headers = [c[0] for c in CONTEXT_COLS] + [c[0] for c in REVIEW_COLS]
    for j, name in enumerate(headers, start=1):
        cell = ws.cell(row=head, column=j, value=name)
        cell.font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.border = BORDER

    first = head + 1
    band, last_case = False, None
    for i, row in enumerate(rows):
        if row["case"] != last_case:
            band = not band
            last_case = row["case"]
        values = sheet_row(row, i + 1)
        for j, val in enumerate(values, start=1):
            cell = ws.cell(row=first + i, column=j, value=val)
            cell.font = Font(name="Arial", size=10, bold=(j == 3))
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = BORDER
            if band:
                cell.fill = BAND_FILL
        for j in range(len(CONTEXT_COLS) + 1, len(headers) + 1):
            cell = ws.cell(row=first + i, column=j)
            cell.fill = INPUT_FILL
            cell.font = Font(name="Arial", size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = BORDER

    last = first + len(rows) - 1
    widths = [c[1] for c in CONTEXT_COLS] + [c[1] for c in REVIEW_COLS]
    for j, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[head].height = 28
    ws.freeze_panes = ws.cell(row=first, column=1)
    ws.auto_filter.ref = f"A{head}:{get_column_letter(len(headers))}{last}"

    col = {name: len(CONTEXT_COLS) + k + 1 for k, (name, _, _) in enumerate(REVIEW_COLS)}
    for name, options in (("judge_correct", ["yes", "no"]),):
        letter = get_column_letter(col[name])
        dv = DataValidation(type="list", formula1='"' + ",".join(options) + '"',
                            allow_blank=True, showDropDown=False)
        ws.add_data_validation(dv)
        dv.add(f"{letter}{first}:{letter}{last}")

    legend = wb.create_sheet("how to fill this in")
    legend["A1"] = "Columns you fill in"
    legend["A1"].font = Font(name="Arial", size=13, bold=True)
    legend.append([])
    for name, _, desc in REVIEW_COLS:
        legend.append([name, desc])
    legend.append([])
    legend.append(["shaded cells", "the only cells to edit"])
    legend.append(["everything else", "the judge's output, leave as is"])
    for row in legend.iter_rows():
        for cell in row:
            cell.font = Font(name="Arial", size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    legend["A1"].font = Font(name="Arial", size=13, bold=True)
    legend.column_dimensions["A"].width = 22
    legend.column_dimensions["B"].width = 96

    wb.save(path)


README = """# GAVEL manual review

{n} discrepancies for both reviewers to score independently, drawn from
{pool_cases} case reports.

## The three folders

- `{shared_name}/` &ndash; both reviewers score every row in this one. That
  overlap is what the inter-annotator agreement is computed from.
- one folder per reviewer &ndash; scored by that person alone.

No row appears in more than one folder, and all three are drawn from the same
{total}-item pool with the same stratum profile, so they are interchangeable in
everything except who scores them.

## What to do

Open the `review.xlsx` in your folder. Each row is one difference the judge found between two
extracted timelines, together with the verdict it reached and the evidence it
cited. Decide whether that verdict is right.

Fill in two columns:

- **judge_correct** - yes or no. Did the judge reach the right verdict? Judge
  the verdict itself. If the verdict is right but the reasoning or the cited
  evidence is wrong, mark yes and say so in notes.
- **notes** - optional. Why it is wrong, or anything worth saying. Leave it
  blank when the judge was simply right.

Nothing else needs filling in. Everything left of those two columns is the
judge's output and should not be edited.

The rows are grouped by case and shaded in alternating blocks, so you can read
one note, clear every row on that case, and move on. Both of you score every
row. Do not compare answers until both are finished; the whole point is an
independent second read.

## Where the source material is

`cases/<case>/` holds everything the judge saw for that case, and nothing more:

- `discharge_note.txt` - the note, exactly as it went into the prompt
- `structured_evidence.txt` - the tabular EHR summary between its markers
- `timeline_<extractor>.txt` - one file per extractor, two columns, `event | time`

The `A is` and `B is` columns on each row tell you which two timelines that row
is about. A row marked `A is human, B is glm52` means open `timeline_human.txt`
and `timeline_glm52.txt` in that case folder.

Grep across `cases/` to find a term quickly, for example
`grep -rn "lactate" cases/`.

## Rules the judge was working under

Worth knowing, since a verdict can be right under these and look wrong without
them.

- A and B are interchangeable labels. Neither side is more trustworthy.
- t=0 is admission. A day is 24 hours, a week 168, a month 720, a year 8760.
- Timing tolerance is the larger of 3 hours or 10% of the distance from t=0, so
  a smaller gap is agreement and should not have been raised at all.
- A component split of the same entity at the same time is agreement.
  Granularity is never penalised.
- An interval takes its start. A fully ambiguous history takes t=0.
- Structured evidence calibrates a timestamp or a value, but never demotes a
  note-supported event on the grounds that the tables do not list it.
- UNCLEAR is preferred over a confident wrong verdict.

## How the sample was built

{pool_cases} case reports are drawn first, from the set every pairing judged, so the
whole review sits on a handful of notes rather than dozens. Within those cases a
finding belongs to a pair of extractors rather than to one extractor, so the
pool is {per} from each of the three pairings, {total} in total, and the {n} rows here
are drawn from that pool balanced across pairing and finding type. {cases} of the
case reports ended up carrying at least one row.

Within a pairing the pool is stratified: 15 TIMING, 10 B_ONLY, 8 A_ONLY,
7 DUPLICATE, 5 VALUE, 5 UNCLEAR. Stratifying rather than sampling at random is
deliberate. The decisive findings are 58% TIMING, so a simple random draw would
contain almost no VALUE or DUPLICATE. The strata are oversampled relative to the
corpus, so any overall accuracy figure has to be reweighted back to the corpus
proportions. `sample_manifest.csv` carries the stratum on every row for exactly
that.

The case draw is rejection sampled: only about one random set of {pool_cases} in four can
supply five VALUE findings in glm52_vs_dsv32, which averages under half a
finding per case. Holding the strata exact therefore tilts the case set mildly
toward cases carrying more VALUE and DUPLICATE findings. Worth stating in the
paper alongside the reweighting.

UNCLEAR is in the sample on purpose. In the earlier n10 adjudication, 21 of the
29 judge disagreements were one judge abstaining where structured evidence
existed, so wrongful abstention was the largest single error mode. A
decisive-only sample cannot measure it.

## What the numbers will support

At n={n}, raw agreement between the two of you at 90% carries a Wilson interval of
[78.6%, 95.7%]. That is enough to show you are broadly consistent and to justify
scoring more rows the same way. It is not enough for a precise kappa in the
paper.

If agreement comes in below about 80%, the two of you disagreeing on what counts
as correct matters more than the judge's accuracy, and the definitions need
another pass before more rows are worth scoring.
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--out", default="manual_review")
    ap.add_argument("--cases", type=int, default=10,
                    help="how many case reports the whole review is drawn from, so the "
                         "reviewers open a handful of notes rather than dozens")
    ap.add_argument("--per-pairing", type=int, default=50,
                    help="drawn from each pairing before the shared packet is taken")
    ap.add_argument("--n", type=int, default=50, help="rows in the shared packet")
    ap.add_argument("--reviewers", default="sayantan,nick",
                    help="comma separated names, one packet each on top of the shared one. "
                         "Pass an empty string to write only the shared packet.")
    ap.add_argument("--shared-name", default="shared_50",
                    help="folder for the packet both reviewers score")
    ap.add_argument("--prompts", default=None,
                    help="the round robin prompt folder. Found automatically if it sits "
                         "beside judge_outputs.")
    ap.add_argument("--seed", type=int, default=20260825)
    ap.add_argument("--drop", default="",
                    help="pairing/case to exclude, comma separated, e.g. "
                         "a_vs_b/12345678. Empty by default.")
    args = ap.parse_args()

    drop = set()
    for item in args.drop.split(","):
        item = item.strip()
        if "/" in item:
            p, c = item.rsplit("/", 1)
            drop.add((p, c))

    if sum(ALLOCATION.values()) != args.per_pairing:
        sys.exit(f"ALLOCATION sums to {sum(ALLOCATION.values())}, "
                 f"--per-pairing is {args.per_pairing}; edit one to match")

    rng = random.Random(args.seed)
    pool, skipped = collect(args.root, drop)
    pairings = sorted({p for p, _ in pool})
    if not pairings:
        sys.exit(f"no <a>_vs_<b> folders with .json files under {os.path.abspath(args.root)}")

    chosen, attempts = choose_cases(pool, pairings, args.cases, rng)
    if attempts == -1:
        sys.stderr.write(f"no draw of {args.cases} cases could supply every stratum; "
                         f"using the last draw and taking what exists\n")
    pool = restrict(pool, chosen)

    picked, short = sample(pool, pairings, rng)
    for pairing, stratum, have, want in short:
        sys.stderr.write(f"only {have} {stratum} in {pairing}, wanted {want}\n")

    # packets, dealt so each stays balanced across pairing and stratum. p0 is the
    # shared one; the rest are handed out per reviewer. The deal is a pure
    # function of the seed, so p0 is identical whether or not --reviewers is set.
    n_packets = max(1, len(picked) // args.n)
    buckets = deal(picked, [f"p{i}" for i in range(n_packets)], rng)
    reviewers = [x.strip() for x in args.reviewers.split(",") if x.strip()]
    if len(reviewers) > n_packets - 1:
        sys.exit(f"{len(picked)} in the pool leaves only {n_packets - 1} packet(s) "
                 f"besides the shared one, but {len(reviewers)} reviewers were named")

    def ordered(bucket):
        # grouped by case, so a reviewer reads one note and clears every row on it
        return sorted(bucket[:args.n],
                      key=lambda r: (r["case"], r["pairing"], r["stratum"], r["idx"]))

    rows = ordered(buckets["p0"])
    extra = [(name, ordered(buckets[f"p{i+1}"])) for i, name in enumerate(reviewers)]

    out = os.path.join(args.root, args.out)
    os.makedirs(out, exist_ok=True)

    prompts = find_prompts(args.root, args.prompts)
    if prompts:
        every = list(rows)
        for _, block in extra:
            every.extend(block)
        n_cases, n_files = write_case_material(out, every, prompts)
    else:
        n_cases = n_files = 0
        sys.stderr.write("could not find the round robin prompt folder, so no case material "
                         "was written. Pass --prompts /path/to/round_robin_prompts_MIMIC\n")

    shared_dir = os.path.join(out, args.shared_name)
    os.makedirs(shared_dir, exist_ok=True)
    write_workbook(os.path.join(shared_dir, "review.xlsx"), rows,
                   "GAVEL manual review",
                   f"{len(rows)} discrepancies, reviewed independently by both reviewers. "
                   f"Do not compare answers until both are finished.")

    for name, block in extra:
        folder = os.path.join(out, f"{name}_{len(block)}")
        os.makedirs(folder, exist_ok=True)
        write_workbook(os.path.join(folder, "review.xlsx"), block,
                       f"GAVEL manual review, {name}",
                       f"{len(block)} discrepancies for {name} alone. No overlap with the "
                       f"shared packet or with the other reviewer. Same case reports, same "
                       f"instructions.")

    with open(os.path.join(out, "README.md"), "w", encoding="utf-8") as fh:
        fh.write(README.format(n=len(rows), per=args.per_pairing,
                               total=len(picked), cases=n_cases,
                               pool_cases=len(chosen),
                               shared_name=args.shared_name))

    manifest = []
    for packet, block in [("shared", rows)] + extra:
        for i, row in enumerate(block):
            manifest.append(dict(packet=packet, row_id=i + 1, pairing=row["pairing"],
                                 case=row["case"], finding_index=row["idx"],
                                 stratum=row["stratum"], a_name=row["a_name"],
                                 b_name=row["b_name"],
                                 judge_verdict=row["f"].get("verdict"),
                                 judge_type=row["f"].get("type"),
                                 grounding=row["f"].get("grounding")))

    cols = ["packet", "row_id", "pairing", "case", "finding_index", "stratum",
            "a_name", "b_name", "judge_verdict", "judge_type", "grounding"]
    with open(os.path.join(out, "sample_manifest.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(manifest)

    by_p = collections.Counter(r["pairing"] for r in rows)
    by_s = collections.Counter(r["stratum"] for r in rows)
    print(f"cases: {len(chosen)} drawn from the {len(pairings)}-way common set"
          + (f" ({attempts} draws to satisfy every stratum)" if attempts > 0 else ""))
    print(f"  {', '.join(chosen)}")
    print(f"pool: {len(picked)} discrepancies, {args.per_pairing} from each of "
          f"{len(pairings)} pairings")
    print(f"{args.shared_name}: {len(rows)} rows, both reviewers")
    print(f"  pairings {dict(sorted(by_p.items()))}")
    print(f"  strata   {dict(sorted(by_s.items()))}")
    for name, block in extra:
        print(f"{name}_{len(block)}: {len(block)} rows, {name} only")
        print(f"  pairings {dict(sorted(collections.Counter(r['pairing'] for r in block).items()))}")
        print(f"  strata   {dict(sorted(collections.Counter(r['stratum'] for r in block).items()))}")
    if prompts:
        print(f"  case material: {n_cases} cases, {n_files} files from {prompts}")
    if skipped:
        print("  excluded:", ", ".join(sorted(set(skipped))))
    print(f"wrote {out}/")


if __name__ == "__main__":
    main()

# GAVEL judge

Scripts to build the judge prompts, run the judge, and produce the leaderboard
and manual review numbers.

GAVEL is an LLM-as-judge that audits a **pair** of extracted clinical timelines
against the source note and structured EHR evidence, and returns a typed,
evidence-bearing verdict for every place the two differ. It does not score a
timeline on its own. Discrepancy types are VALUE, TIMING, A_ONLY, B_ONLY,
SHARED_UNSUPPORTED and DUPLICATE; verdicts are A, B, BOTH, NEITHER and UNCLEAR.

No data is stored here. The scripts read whatever corpus you point them at, and
study-specific values such as case identifiers are passed on the command line.

## Contents

| file | what it does |
| --- | --- |
| `structured_judge_prompt_2col.txt` | the judge prompt, with four placeholders |
| `make_round_robin_n40.py` | builds one prompt per case per pairing |
| `run_judge_gavel.sh` | Slurm driver: starts the server, walks every prompt |
| `run_judge_gavel.py` | sends one prompt, parses the reply |
| `llm_server_utils.sh` | starts and stops llama-server |
| `make_elo_report.py` | Bradley-Terry leaderboard as a self-contained HTML report |
| `make_review_sample.py` | draws the stratified manual review packets |
| `manual_review_report.py` | agreement and judge accuracy from the filled packets |

## 1. Build the prompts

Expects a corpus folder holding the notes, the structured summaries, and one
folder per extractor:

```
corpus/
  i2m4_n40_notes/            <case>.txt
  summary/                   timeline_<case>_summary.txt
  manual_final_n40_2col/     the human timelines, .csv with an event,time header
  <name>_timelines/          gzipped model timelines
  <name>_unimodal/           gzipped model timelines
```

Then:

```
cd corpus
python3 make_round_robin_n40.py --template structured_judge_prompt_2col.txt
```

Writes `round_robin_prompts/<a>_vs_<b>/prompt_<case>.txt`, plus `manifest.csv`
with per-prompt sizes and `build_report.txt` with everything skipped and why.

`--list-pairings` prints every pairing the corpus supports with case counts and
writes nothing. `--pairings` takes a preset (`all`, `done`, `remaining`) or a
comma-separated list. Extractors are declared in the `SOURCES` table near the top
of the script; adding a timeline set is one line.

Timelines are rendered as two columns under an `event | time` header, with all
extractor metadata stripped. Event text passes through verbatim so exact-text
matching still works when comparing runs.

## 2. Run the judge

Copy the four run files into the prompt folder and submit from inside it:

```
cd round_robin_prompts
sbatch run_judge_gavel.sh
```

Four things are site specific and must be set in the environment first:

```
export GAVEL_CONDA_ENV=/path/to/conda/env
export LLAMA_SERVER=/path/to/llama.cpp/build/bin/llama-server
export MODEL_PATH=/path/to/model.gguf
export MODEL_ALIAS=judge                 # optional
```

The `#SBATCH --partition`, `--qos` and `--gres` lines are cluster specific too.

Output mirrors the prompt tree:

```
judge_outputs/<pairing>/<case>.json      the findings array
                       <case>.raw.txt    only when the reply would not parse
              run_log.csv                one row per prompt
              failed.txt                 only if a call failed
```

The pairing has to be in the output path because the same case appears in
several pairings; a flat folder keyed on case id would collide.

Reruns are safe. A case with a `.json` is skipped, so a job that hits the wall
clock picks up where it stopped. A reply that will not parse leaves `.raw.txt`
and no `.json`, so resubmitting retries it. Five consecutive call failures stop
the job, which almost always means the server died.

**Token budget.** `LLAMA_CTX_SIZE` and `LLAMA_MAX_TOKENS` are exported once in
`run_judge_gavel.sh` and read by both the server and the request, so they cannot
disagree. Set them generously. Reasoning tokens count against the output cap, so
a cap sized on the length of the JSON alone will truncate most calls and cost
several passes. In our run, prompts reached about 130k tokens and completions
about 185k.

## 3. Leaderboard

```
cd judge_outputs
python3 make_elo_report.py
```

Every decisive finding is charged against whichever extractor the judge ruled
was wrong and slotted into one of seven weighted error categories. The weighted
points become each side's share of that case, and Bradley-Terry fits the
strengths that best explain every share at once. Intervals come from resampling
case reports.

Writes `gavel_report.html`, which carries its own data: the weight dials refit
the leaderboard in the browser with no server.

Five sections: the weights, the leaderboard, the raw discrepancy counts, a
direct head-to-head test for extractor pairs that differ in one controlled way,
and, with `--annotation-batch`, a split by annotation batch.

```
python3 make_elo_report.py --annotation-batch ../config/annotation_batch.txt
```

Section 5 is skipped if the file is not given. See `config/` for the format.

## 4. Manual review

Draw the packets:

```
cd judge_outputs
python3 make_review_sample.py
```

Ten case reports are drawn first, so reviewers read a handful of notes rather
than dozens, then findings are sampled per pairing and stratified by type. The
stratification is deliberate: TIMING dominates the corpus, so a proportional
draw contains almost no VALUE or DUPLICATE findings. Because the strata are not
proportional, accuracy has to be standardised back to the corpus mix, which
`manual_review_report.py` does.

Writes one folder per reviewer plus a shared packet, each an `.xlsx` with the
finding and its evidence, a `cases/` folder with the note, structured evidence
and timelines for every sampled case, and `sample_manifest.csv` with the stratum
on every row.

Then, once the packets come back:

```
python3 manual_review_report.py \
    --by reviewer_a=shared.xlsx,own.xlsx \
    --by reviewer_b=shared_b.xlsx \
    --judge-outputs ../judge_outputs
```

`--by` is mandatory and deliberately cannot be inferred from filenames: a packet
named for one reviewer may have been scored by another, and guessing would
silently swap the agreement and accuracy samples.

Reports inter-annotator agreement on the shared rows, judge accuracy raw and
standardised with a stratified bootstrap interval, a sensitivity analysis on
what "correct" is taken to mean, and a mechanical audit of findings raised
inside the judge's own timing tolerance.

## Requirements

Python 3.8+. `make_review_sample.py` and `manual_review_report.py` need
`openpyxl`; everything else is standard library. The run scripts need a
llama.cpp server build and Slurm.

## Reproducing a published run

Study-specific values are not baked into the scripts. To reproduce a particular
analysis you need, alongside the corpus: the exclusion list passed to `--drop`,
the annotation-batch file, and the sampling seed. `make_review_sample.py` is
seeded and reproducible, but the draw depends on which pairings are present, so
run it against the same set of pairing folders the original sample used.

#!/usr/bin/env python3
"""
manual_review_report.py

Everything the GAVEL manual review contributes to the manuscript, computed from
the filled workbooks in one pass, with the reasoning for each choice printed
beside the number.

    python3 manual_review_report.py \
        --by nick=nick_manual_review.xlsx,nick_50.xlsx,sayantan_50_reviewed.xlsx \
        --by sayantan=review_SK_n50.xlsx \
        --judge-outputs ../judge_outputs

Every workbook must be assigned to whoever actually scored it. Do not infer this
from filenames: in this study the packet named for one reviewer was scored by
the other, and getting it wrong silently swaps the agreement and accuracy
samples.

--judge-outputs points at the folder of <a>_vs_<b>/<case>.json. It is needed for
the corpus stratum mix and for the tolerance audit. Without it the script still
runs and says which figures it had to omit.

Writes report.txt, per_row.csv and disagreements.csv unless --no-write.
Needs openpyxl.
"""

import argparse
import collections
import csv
import json
import math
import os
import random
import sys

HEADER_ROW = 5
VERDICT_COL = "judge_correct"
NOTES_COL = "notes"
CONTEXT = ["pairing", "case", "type", "judge verdict", "grounding",
           "A is", "B is", "A event", "A time", "B event", "B time"]

# A_ONLY and B_ONLY are the same phenomenon seen from the two slots: an event on
# one timeline and not the other. Which slot it lands in is an artefact of how the
# pairing was ordered, not a property of the finding, so they are reported as one
# category. Merging also keeps the report from implying the A and B positions are
# comparable when the judge may not treat them symmetrically.
MERGE = {"A_ONLY": "ONE_SIDED", "B_ONLY": "ONE_SIDED"}

# The judge's stated timing rule: raise no TIMING difference when the two times
# differ by less than the larger of 3 hours or 10% of the distance from t=0.
TOL_FLOOR_HOURS = 3.0
TOL_FRACTION = 0.10


def wilson(hits, n, z=1.96):
    if not n:
        return (0.0, 0.0)
    p = hits / n
    den = 1 + z * z / n
    centre = p + z * z / (2 * n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((centre - half) / den, (centre + half) / den)


def as_float(v):
    try:
        return float(str(v).strip())
    except Exception:
        return None


def row_key(rec):
    """Identify a row by the finding it describes. The id column restarts at 1 in
    every packet, so joining on it would match unrelated findings."""
    return "|".join("" if rec.get(c) is None else str(rec.get(c)).strip()
                    for c in ["pairing", "case", "A event", "A time",
                              "B event", "B time"])


def base_type(rec):
    kind = str(rec.get("type", "")).strip()
    return MERGE.get(kind, kind)


def stratum(rec, split=frozenset()):
    """Finding type, and for the types in `split`, whether the judge ruled.

    UNCLEAR is a verdict rather than a type, so a finding the judge declined to
    rule on keeps its own type and is marked. Only types that actually occur both
    ways are labelled; adding ", decisive" to a type that is always decisive
    would be noise. `split` is worked out from the data rather than assumed."""
    kind = base_type(rec)
    if kind not in split:
        return kind
    if str(rec.get("judge verdict", "")).strip().upper() == "UNCLEAR":
        return kind + ", UNCLEAR"
    return kind + ", decisive"


def verdict(value):
    """Reviewers do not always stay inside the dropdown. A trailing question mark
    is read as the answer given and counted as hedged, because discarding those
    rows would drop exactly the hardest calls."""
    if value is None:
        return None, False
    raw = str(value).strip().lower()
    hedged = raw.endswith("?")
    core = raw.rstrip("?").strip()
    if core in ("yes", "y", "correct"):
        return "yes", hedged
    if core in ("no", "n", "incorrect"):
        return "no", hedged
    return None, hedged


def inside_tolerance(rec):
    """True when a TIMING finding's gap falls inside the judge's own tolerance,
    meaning the prompt says it should not have been raised at all. Returns None
    when either side has no numeric time.

    'Distance from t=0' does not say whose time to use, so the larger absolute
    time is taken, which is the most permissive reading and therefore the most
    conservative way to accuse the judge of a breach."""
    if str(rec.get("type", "")).strip() != "TIMING":
        return None
    a, b = as_float(rec.get("A time")), as_float(rec.get("B time"))
    if a is None or b is None:
        return None
    tol = max(TOL_FLOOR_HOURS, TOL_FRACTION * max(abs(a), abs(b)))
    return abs(a - b) < tol


def read_workbook(path):
    try:
        from openpyxl import load_workbook
    except ImportError:
        sys.exit("openpyxl is needed: pip install openpyxl")
    wb = load_workbook(path, data_only=True)
    ws = wb["review"] if "review" in wb.sheetnames else wb[wb.sheetnames[0]]
    header = [ws.cell(row=HEADER_ROW, column=c).value
              for c in range(1, ws.max_column + 1)]
    if VERDICT_COL not in header:
        sys.exit(f"{path}: no '{VERDICT_COL}' column on row {HEADER_ROW}")
    out = {}
    for r in range(HEADER_ROW + 1, ws.max_row + 1):
        rec = dict(zip(header, [ws.cell(row=r, column=c).value
                                for c in range(1, ws.max_column + 1)]))
        if rec.get("id") in (None, ""):
            continue
        rec["_file"] = os.path.basename(path)
        out[row_key(rec)] = rec
    return out


def corpus_mix(root, drop, split=frozenset()):
    """Stratum counts over every finding the review could have sampled, on the
    same partition the review uses. Decisive and abstained are counted
    separately so the weights line up with the sample strata."""
    counts = collections.Counter()
    for name in sorted(os.listdir(root)):
        folder = os.path.join(root, name)
        if not os.path.isdir(folder) or "_vs_" not in name:
            continue
        for fn in sorted(os.listdir(folder)):
            if not fn.endswith(".json") or (name, fn[:-5]) in drop:
                continue
            try:
                obj = json.load(open(os.path.join(folder, fn), encoding="utf-8"))
            except Exception:
                continue
            for f in obj if isinstance(obj, list) else []:
                if not isinstance(f, dict):
                    continue
                v = str(f.get("verdict", "")).upper()
                kind = str(f.get("type", "")).strip()
                kind = MERGE.get(kind, kind)
                if v not in ("A", "B", "UNCLEAR"):
                    continue
                if kind not in split:
                    counts[kind] += 1
                elif v == "UNCLEAR":
                    counts[kind + ", UNCLEAR"] += 1
                else:
                    counts[kind + ", decisive"] += 1
    return counts


def corpus_tolerance_audit(root, drop):
    """How often the judge raised a TIMING finding inside its own tolerance,
    across the whole corpus rather than only the reviewed sample. This is
    mechanical, needs no reviewer, and is the one judge error that can be
    counted exhaustively."""
    total = breach = 0
    by_file = collections.Counter()
    denom = collections.Counter()
    for name in sorted(os.listdir(root)):
        folder = os.path.join(root, name)
        if not os.path.isdir(folder) or "_vs_" not in name:
            continue
        for fn in sorted(os.listdir(folder)):
            if not fn.endswith(".json") or (name, fn[:-5]) in drop:
                continue
            try:
                obj = json.load(open(os.path.join(folder, fn), encoding="utf-8"))
            except Exception:
                continue
            for f in obj if isinstance(obj, list) else []:
                if not isinstance(f, dict) or f.get("type") != "TIMING":
                    continue
                a, b = as_float(f.get("a_time")), as_float(f.get("b_time"))
                if a is None or b is None:
                    continue
                total += 1
                denom[f"{name}/{fn[:-5]}"] += 1
                tol = max(TOL_FLOOR_HOURS, TOL_FRACTION * max(abs(a), abs(b)))
                if abs(a - b) < tol:
                    breach += 1
                    by_file[f"{name}/{fn[:-5]}"] += 1
    return total, breach, by_file, denom


def reweight(by_stratum, weights, rounds, seed):
    """Accuracy standardised to the corpus mix, with a stratified bootstrap
    interval.

    The sample deliberately oversamples the rare finding types, so the raw share
    is not an estimate of corpus accuracy and must be standardised. A Wilson
    interval is wrong for the standardised figure because it is a weighted
    combination of six rates, so the interval is resampled within stratum
    instead. Strata never sampled are dropped from the denominator, which
    assumes their accuracy resembles the sampled ones."""
    covered = [s for s in by_stratum if s in weights and by_stratum[s]]
    if not covered:
        return None
    total = sum(weights[s] for s in covered)
    w = {s: weights[s] / total for s in covered}
    point = sum(w[s] * sum(by_stratum[s]) / len(by_stratum[s]) for s in covered)
    rng = random.Random(seed)
    draws = []
    for _ in range(rounds):
        draws.append(sum(w[s] * sum(rng.choice(by_stratum[s])
                                    for _ in by_stratum[s]) / len(by_stratum[s])
                         for s in covered))
    draws.sort()
    return point, draws[int(0.025 * len(draws))], draws[int(0.975 * len(draws))], w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--by", action="append", default=[], metavar="NAME=f1,f2",
                    help="who scored which workbooks. Repeat per reviewer.")
    ap.add_argument("--root", default=".", help="folder holding the workbooks")
    ap.add_argument("--judge-outputs", default=None)
    ap.add_argument("--drop", default="",
                    help="pairing/case excluded from the corpus, comma separated. "
                         "Must match whatever was excluded when the sample was drawn.")
    ap.add_argument("--rounds", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=20260910)
    ap.add_argument("--no-write", action="store_true")
    args = ap.parse_args()

    if not args.by:
        sys.exit("--by is required, e.g. --by nick=a.xlsx,b.xlsx --by sayantan=c.xlsx")

    lines = []

    def say(text=""):
        print(text)
        lines.append(text)

    # ---------------------------------------------------------------- load
    books = collections.OrderedDict()
    for spec in args.by:
        if "=" not in spec:
            sys.exit(f"--by needs NAME=file,file : got {spec}")
        name, files = spec.split("=", 1)
        name = name.strip()
        books.setdefault(name, {})
        for f in files.split(","):
            f = f.strip()
            if not f:
                continue
            path = f if os.path.isabs(f) else os.path.join(args.root, f)
            part = read_workbook(path)
            clash = set(books[name]) & set(part)
            if clash:
                say(f"WARNING: {len(clash)} findings appear twice in {name}'s "
                    f"workbooks; keeping the first")
            for k, v in part.items():
                books[name].setdefault(k, v)
    names = list(books)

    say("=" * 78)
    say("GAVEL manual review, figures for the manuscript")
    say("=" * 78)
    say()
    say("PROVENANCE")
    say("  Every workbook is assigned to whoever scored it, not to whoever the")
    say("  packet was named for. Rows are matched across workbooks by the finding")
    say("  they describe, since the id column restarts at 1 in each packet.")
    for n in names:
        srcs = sorted({r["_file"] for r in books[n].values()})
        say(f"    {n}: {len(books[n])} findings from {', '.join(srcs)}")

    marks = {}
    hedged = collections.defaultdict(list)
    for n in names:
        marks[n] = {}
        for k, rec in books[n].items():
            v, h = verdict(rec.get(VERDICT_COL))
            marks[n][k] = v
            if h:
                hedged[n].append(k)
    for n in names:
        blank = [k for k in books[n] if marks[n][k] is None]
        if blank:
            say(f"    {n}: {len(blank)} rows with no usable verdict, excluded")
        if hedged[n]:
            say(f"    {n}: {len(hedged[n])} rows hedged with '?', counted as the "
                f"answer given")

    # ------------------------------------------------- inter-rater agreement
    say()
    say("-" * 78)
    say("1. INTER-ANNOTATOR AGREEMENT")
    say("-" * 78)
    say("  Computed only on findings two people both scored. Everything else in")
    say("  this report rests on a single reader, so this is the only measure of")
    say("  whether the review criteria are shared rather than personal.")
    pairs_done = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = names[i], names[j]
            common = [k for k in set(books[a]) & set(books[b])
                      if marks[a][k] and marks[b][k]]
            if not common:
                say(f"  {a} and {b} scored no findings in common.")
                continue
            tab = collections.Counter((marks[a][k], marks[b][k]) for k in common)
            n = len(common)
            hits = tab[("yes", "yes")] + tab[("no", "no")]
            po = hits / n
            ra = collections.Counter()
            cb = collections.Counter()
            for (x, y), v in tab.items():
                ra[x] += v
                cb[y] += v
            pe = sum(ra[c] * cb[c] for c in ("yes", "no")) / (n * n)
            kappa = (po - pe) / (1 - pe) if pe < 1 else float("nan")
            lo, hi = wilson(hits, n)

            # Kappa's usual analytic interval treats expected agreement as fixed
            # when it is estimated from the same marginals, and the normal
            # approximation is poor at this n with this prevalence. Resampling
            # rows instead. Resamples where one reviewer used a single class make
            # kappa undefined; they are counted rather than quietly dropped.
            rng = random.Random(args.seed)
            draws, undefined = [], 0
            obs = [(marks[a][k], marks[b][k]) for k in common]
            for _ in range(args.rounds):
                samp = [rng.choice(obs) for _ in obs]
                t2 = collections.Counter(samp)
                m = len(samp)
                po2 = (t2[("yes", "yes")] + t2[("no", "no")]) / m
                r2 = collections.Counter()
                c2 = collections.Counter()
                for (x, y), v in t2.items():
                    r2[x] += v
                    c2[y] += v
                pe2 = sum(r2[c] * c2[c] for c in ("yes", "no")) / (m * m)
                if pe2 >= 1:
                    undefined += 1
                else:
                    draws.append((po2 - pe2) / (1 - pe2))
            draws.sort()
            klo = draws[int(0.025 * len(draws))]
            khi = draws[int(0.975 * len(draws))]
            say()
            say(f"  {a} vs {b}, n = {n}")
            say(f"    {'':16}{(b+' yes'):>14}{(b+' no'):>12}")
            for row in ("yes", "no"):
                say(f"    {(a+' '+row):16}{tab[(row,'yes')]:>14}{tab[(row,'no')]:>12}")
            say(f"    raw agreement   {po:.3f} ({hits}/{n})  95% CI "
                f"[{lo:.3f}, {hi:.3f}]")
            say(f"    Cohen's kappa   {kappa:.3f}  95% CI [{klo:.3f}, {khi:.3f}]")
            say(f"                    ({args.rounds} row resamples; undefined in "
                f"{undefined}, where a resample left one reviewer with a single class)")
            say(f"    PABAK           {2*po-1:.3f}  95% CI [{2*lo-1:.3f}, {2*hi-1:.3f}]")
            say(f"                    (exact: PABAK is 2*agreement-1, so its interval is")
            say(f"                    the Wilson interval transformed, not resampled)")
            say(f"    upheld the judge: {a} {ra['yes']}/{n}, {b} {cb['yes']}/{n}")
            prevalence = max(ra["yes"], ra["no"], cb["yes"], cb["no"]) / n
            if prevalence > 0.85:
                say(f"    Note: {100*prevalence:.0f}% of rows fall in one class, so chance agreement is")
                say(f"    already {pe:.2f} and kappa is deflated by the prevalence problem. Report")
                say(f"    raw agreement as the headline, with kappa and PABAK beside it.")
            pairs_done.append((a, b, common))

    # ----------------------------------------------------- judge accuracy
    # A type is split by verdict status only if it genuinely occurs both ways in
    # the corpus. Everything else stays a plain type name.
    split = set()
    drop = set()
    for item in args.drop.split(","):
        item = item.strip()
        if "/" in item:
            p, c = item.rsplit("/", 1)
            drop.add((p, c))
    # Split a type by verdict status only where the reviewed sample actually
    # contains rows both ways. Splitting on a corpus minority the reviewers never
    # saw would create a stratum with no data and no rate to standardise with.
    primary_guess = max(names, key=lambda n: len(books[n]))
    seen = collections.Counter()
    for k, rec in books[primary_guess].items():
        if not marks[primary_guess][k]:
            continue
        kind = base_type(rec)
        side = "u" if str(rec.get("judge verdict", "")).strip().upper() == "UNCLEAR" else "d"
        seen[(kind, side)] += 1
    split = {k for k, _ in seen if seen[(k, "d")] and seen[(k, "u")]}

    weights = None
    if args.judge_outputs and os.path.isdir(args.judge_outputs):
        counts = corpus_mix(args.judge_outputs, drop, split)
        tot = sum(counts.values())
        weights = {s: counts[s] / tot for s in counts if counts[s]}
    say()
    say(f"  A_ONLY and B_ONLY are reported together as ONE_SIDED. Which side an")
    say(f"  event falls on is an artefact of how the pairing was ordered, not a")
    say(f"  property of the finding.")
    if split:
        say(f"  {', '.join(sorted(split))} is split by whether the judge reached a")
        say(f"  verdict, because it occurs both ways. Every other type is always")
        say(f"  decisive here and is left unqualified.")

    primary = max(names, key=lambda n: len(books[n]))
    say()
    say("-" * 78)
    say("2. JUDGE ACCURACY")
    say("-" * 78)
    say(f"  Reported from {primary}, who scored the most findings ({len(books[primary])}).")
    say("  Pooling reviewers would mix a two-reader adjudicated subset with")
    say("  single-reader rows and give the shared packet double weight, so one")
    say("  reader's full pass is the cleaner estimate.")
    say()
    for n in names:
        rows = [k for k in books[n] if marks[n][k]]
        hits = sum(1 for k in rows if marks[n][k] == "yes")
        lo, hi = wilson(hits, len(rows))
        tag = "  <- reported" if n == primary else ""
        say(f"    {n:12} {hits}/{len(rows)} = {100*hits/len(rows):.1f}%  95% CI "
            f"[{100*lo:.1f}, {100*hi:.1f}]{tag}")
    say()
    say("  The raw share is not corpus accuracy. The sample deliberately")
    say("  oversamples rare finding types so they can be estimated at all, so it")
    say("  has to be standardised to the corpus mix before it is quoted.")

    by_s = collections.defaultdict(list)
    for k in books[primary]:
        if marks[primary][k]:
            by_s[stratum(books[primary][k], split)].append(1 if marks[primary][k] == "yes" else 0)

    if weights:
        res = reweight(by_s, weights, args.rounds, args.seed)
        if res:
            point, lo, hi, w = res
            say()
            say(f"    standardised accuracy  {100*point:.1f}%  95% CI "
                f"[{100*lo:.1f}, {100*hi:.1f}]")
            say(f"    ({args.rounds} stratified bootstrap resamples, seed {args.seed})")
            say()
            def sort_key(s):
                base = s.rsplit(",", 1)[0]
                return (-sum(w[x] for x in w if x.rsplit(",", 1)[0] == base),
                        base, s.endswith("UNCLEAR"))
            say(f"    {'stratum':24}{'n':>5}{'upheld':>10}{'rate':>9}{'corpus':>10}"
                f"{'contribution':>15}")
            for s in sorted(w, key=sort_key):
                say(f"    {s:24}{len(by_s[s]):>5}{sum(by_s[s]):>7}/{len(by_s[s]):<3}"
                    f"{100*sum(by_s[s])/len(by_s[s]):>8.2f}%{100*w[s]:>9.2f}%"
                    f"{100*w[s]*sum(by_s[s])/len(by_s[s]):>14.2f}")
            say(f"    {'total':24}{sum(len(v) for v in by_s.values()):>5}"
                f"{sum(sum(v) for v in by_s.values()):>7}/"
                f"{sum(len(v) for v in by_s.values()):<3}{'':8}{100*sum(w.values()):>9.2f}%"
                f"{100*point:>14.2f}")
            say()
            say("    Contribution is rate x corpus weight, and the column sums to the")
            say("    standardised figure above. Everything is carried at full precision")
            say("    internally, so recomputing from figures rounded to whole percent")
            say("    lands about a third of a point high.")
            say()
            say("    The two TIMING rows are separate strata, not nested: one is the")
            say("    timing findings the judge ruled on, the other the ones it left")
            say("    UNCLEAR. The corpus column sums to 100%.")
            say()
            say("    n is fixed by the sampling design and is not meant to be even. The")
            say("    sample was stratified so the rare types could be estimated at all:")
            say("    a proportional draw of 50 per pairing would have held about 2 VALUE")
            say("    and 3 DUPLICATE findings, too few to say anything about either, so")
            say("    TIMING was cut from a proportional 25 to 15 to pay for them.")
            say("    Standardising afterwards restores the corpus mix, which is why the")
            say("    raw share above is not the number to quote.")
            missing = [s for s in weights if s not in w]
            if missing:
                share = sum(weights[s] for s in missing)
                say()
                say(f"    {len(missing)} strata were never sampled, together {100*share:.2f}% of")
                say(f"    the corpus, and are dropped from the denominator:")
                for m in sorted(missing):
                    say(f"      {m}")
            zero = [s for s in w if sum(by_s[s]) == len(by_s[s])]
            if zero:
                say(f"    {', '.join(zero)} scored 100%, contributing no variance, so the")
                say(f"    interval is mildly optimistic.")
    else:
        say()
        say("    Standardised accuracy needs --judge-outputs for the corpus mix.")
        say("    Omitted.")

    # ------------------------------------------------ definitional sensitivity
    say()
    say("-" * 78)
    say("3. SENSITIVITY TO WHAT 'CORRECT' MEANS")
    say("-" * 78)
    say("  The review column asked whether the judge reached the right verdict.")
    say("  It did not say how to treat a finding that should not have been raised")
    say("  at all, and the reviewers resolved that differently. The gap is worth")
    say("  more than sampling error, so both readings belong in the manuscript.")
    say()
    strict = [(k, marks[primary][k]) for k in books[primary] if marks[primary][k]]
    lenient = []
    for k, v in strict:
        rec = books[primary][k]
        if v == "no" and (inside_tolerance(rec) is True
                          or str(rec.get("judge verdict", "")).strip().upper() == "UNCLEAR"):
            v = "yes"
        lenient.append((k, v))
    for label, data in (("as scored, a wrongly raised finding counts against the judge", strict),
                        ("verdict only, ignoring whether it should have been raised", lenient)):
        hits = sum(1 for _, v in data if v == "yes")
        lo, hi = wilson(hits, len(data))
        line = (f"    {hits}/{len(data)} = {100*hits/len(data):.1f}%  95% CI "
                f"[{100*lo:.1f}, {100*hi:.1f}]")
        if weights:
            bs = collections.defaultdict(list)
            for k, v in data:
                bs[stratum(books[primary][k], split)].append(1 if v == "yes" else 0)
            r2 = reweight(bs, weights, args.rounds, args.seed)
            if r2:
                line += f"   standardised {100*r2[0]:.1f}% [{100*r2[1]:.1f}, {100*r2[2]:.1f}]"
        say(f"  {label}")
        say(line)
    moved = sum(1 for (k, a), (_, b) in zip(strict, lenient) if a != b)
    say()
    say(f"    {moved} of {len(strict)} rows turn on this distinction.")
    say("    Recommendation: report the first figure and give the second as a")
    say("    sensitivity, or split the question into two columns in any future")
    say("    round so the two are measured rather than conflated.")

    # ----------------------------------------------------- tolerance audit
    say()
    say("-" * 78)
    say("4. TOLERANCE AUDIT, MECHANICAL")
    say("-" * 78)
    say("  The prompt tells the judge to raise no TIMING difference smaller than")
    say("  the larger of 3 hours or 10% of the distance from t=0. Whether a")
    say("  finding breaches that is arithmetic, so it can be checked on every")
    say("  finding in the corpus rather than only the reviewed sample. This is")
    say("  the one judge error with no sampling uncertainty at all.")
    say()
    in_sample = [k for k in books[primary] if inside_tolerance(books[primary][k]) is True]
    if in_sample:
        rej = sum(1 for k in in_sample if marks[primary][k] == "no")
        say(f"    in the reviewed sample: {len(in_sample)} such findings, "
            f"{primary} rejected {rej}")
    if args.judge_outputs and os.path.isdir(args.judge_outputs):
        total, breach, by_file, denom = corpus_tolerance_audit(args.judge_outputs, drop)
        say(f"    corpus-wide: {breach} of {total} TIMING findings with two numeric")
        say(f"    times fall inside the tolerance = {100*breach/total:.1f}%")
        worst = by_file.most_common(5)
        if worst:
            say(f"    most affected files:")
            for f, c in worst:
                say(f"      {f:34}{c:>5}/{denom[f]:<5} = {100*c/denom[f]:.0f}%")
            top_share = worst[0][1] / breach
            if top_share > 0.4:
                say(f"    {100*top_share:.0f}% of all breaches sit in one file, so this is a")
                say(f"    localised failure rather than a property of the judge. Consider")
                say(f"    excluding that file and reporting the audit with and without it.")
    else:
        say("    Corpus-wide audit needs --judge-outputs. Omitted.")

    # ------------------------------------------------------------ caveats
    say()
    say("-" * 78)
    say("5. WHAT NOT TO CLAIM")
    say("-" * 78)
    cases = {str(books[primary][k].get("case")) for k in books[primary]}
    say(f"  The {len(books[primary])} reviewed findings come from {len(cases)} case reports, not from that many")
    say("  independent notes. Findings within a case are correlated, so the")
    say("  intervals above are mildly optimistic.")
    say("  Agreement is measured on the shared packet only; the remaining rows")
    say("  have one reader and no measure of reliability.")
    say("  Standardisation assumes the unsampled strata behave like the sampled")
    say("  ones, and that the reviewed cases are typical of the corpus.")

    if args.no_write:
        return
    out = args.root
    with open(os.path.join(out, "report.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    allk = sorted(set().union(*[set(b) for b in books.values()]))
    with open(os.path.join(out, "per_row.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(CONTEXT + ["stratum", "inside_tolerance"]
                   + [f"{n}_verdict" for n in names]
                   + [f"{n}_notes" for n in names] + ["agree"])
        for k in allk:
            src = next(books[n][k] for n in names if k in books[n])
            vals = [marks[n].get(k) for n in names if k in books[n]]
            w.writerow([src.get(c) for c in CONTEXT]
                       + [stratum(src, split), inside_tolerance(src)]
                       + [marks[n].get(k, "") if k in books[n] else "" for n in names]
                       + [books[n][k].get(NOTES_COL) if k in books[n] else "" for n in names]
                       + ["" if len(vals) < 2 else ("yes" if len(set(vals)) == 1 else "no")])
    with open(os.path.join(out, "disagreements.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(CONTEXT + ["stratum", "inside_tolerance"]
                   + [f"{n}_verdict" for n in names]
                   + [f"{n}_notes" for n in names])
        for a, b, common in pairs_done:
            for k in common:
                if marks[a][k] != marks[b][k]:
                    src = books[a][k]
                    w.writerow([src.get(c) for c in CONTEXT]
                               + [stratum(src, split), inside_tolerance(src)]
                               + [marks[n].get(k, "") for n in names]
                               + [books[n][k].get(NOTES_COL) if k in books[n] else ""
                                  for n in names])
    print(f"\nwrote report.txt, per_row.csv and disagreements.csv in {os.path.abspath(out)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
make_round_robin_n40.py

Builds the GAVEL round-robin judge prompts from the i2m4_n40_Jack bundle.

Run it from inside the bundle root (the folder holding dsv32_n40_timelines/,
glm52_n40_timelines/, i2m4_n40_notes/, manual_final_n40_2col/).

    python3 make_round_robin_n40.py --template judge_template.txt

Writes:
    <out>/human_vs_glm52/prompt_<id>.txt
    <out>/human_vs_dsv32/prompt_<id>.txt
    <out>/glm52_vs_dsv32/prompt_<id>.txt
    <out>/manifest.csv
    <out>/build_report.txt

Both timelines are rendered as two columns under an "event | time" header,
one row per line,
in original file order. All model metadata (uid4, bounds, known, context) is
dropped. Event text is passed through verbatim so exact-text matching still
works for cross-run comparison.

The structured summary is optional and driven by the template. If the template
contains a fourth placeholder (STRUCTURED_SUMMARY, or one of the aliases in
SUMMARY_PLACEHOLDERS) the matching file from --summaries is inserted verbatim
and cases without one are skipped. If it does not, summaries are ignored and
the build is note-only.

Nothing is written until every case has been parsed successfully.
"""

import argparse
import csv
import gzip
import os
import re
import sys
from collections import Counter

PLACEHOLDERS = ("DISCHARGE_NOTE", "TIMELINE_A", "TIMELINE_B")

# Optional fourth placeholder. The first one found in the template wins.
SUMMARY_PLACEHOLDERS = (
    "STRUCTURED_EVIDENCE",
    "STRUCTURED_SUMMARY",
    "TABULAR_EHR_SUMMARY",
    "TABULAR_SUMMARY",
    "STRUCTURED_DATA",
    "SUMMARY",
)

# Template placeholder styles tried, in order. All three must use the same style.
PLACEHOLDER_FORMS = ("{{%s}}", "{%s}", "[[%s]]", "<%s>", "__%s__", "%%%s%%")

NOTES_FOLDER = "i2m4_n40_notes"
SUMMARY_FOLDER = "summary"

# name -> (folder, reader). Add a timeline set by adding one line here.
SOURCES = {
    "human":    ("manual_final_n40_2col", "manual"),
    "glm52":    ("glm52_n40_timelines",   "model"),
    "dsv32":    ("dsv32_n40_timelines",   "model"),
    "glm52uni": ("glm52_n40_unimodal",    "model"),
    "dsv32uni": ("dsv32_n40_unimodal",    "model"),
}

# The full round robin over the five sources above. Five sources give
# 4 + 3 + 2 + 1 = 10 unordered pairs, not 15; a source is never paired with
# itself.
ALL_PAIRS = [
    ("human_vs_glm52",       "human",    "glm52"),
    ("human_vs_dsv32",       "human",    "dsv32"),
    ("human_vs_glm52uni",    "human",    "glm52uni"),
    ("human_vs_dsv32uni",    "human",    "dsv32uni"),
    ("glm52_vs_dsv32",       "glm52",    "dsv32"),
    ("glm52_vs_glm52uni",    "glm52",    "glm52uni"),
    ("glm52_vs_dsv32uni",    "glm52",    "dsv32uni"),
    ("dsv32_vs_glm52uni",    "dsv32",    "glm52uni"),
    ("dsv32_vs_dsv32uni",    "dsv32",    "dsv32uni"),
    ("glm52uni_vs_dsv32uni", "glm52uni", "dsv32uni"),
]

# The three already run and shipped. Rebuilding them reproduces the exact bytes
# Sayantan judged, so they are excluded from the default rather than deleted.
DONE = {"human_vs_glm52", "human_vs_dsv32", "glm52_vs_dsv32"}

PRESETS = {
    "all":       ALL_PAIRS,
    "done":      [p for p in ALL_PAIRS if p[0] in DONE],
    "remaining": [p for p in ALL_PAIRS if p[0] not in DONE],
}

FOLDERS = {"notes": NOTES_FOLDER, "summary": SUMMARY_FOLDER}
FOLDERS.update({name: folder for name, (folder, _) in SOURCES.items()})


# ---------------------------------------------------------------- ids

def case_id(filename):
    """Map any filename shape in the bundle to a bare numeric case id.

    Handles:
        10000001.txt
        10000002-DS-11.txt
        2023-03-07_12-53-02_annotations_145785_yes_structured.bsv
        2020-01-01_00-00-00_annotations_xxx_100001.csv
        10000003-DS-4_timelines_timeline_1.bsv.gz
        10000001_extracted.bsv.gz
        timeline_10000001_summary.txt
    """
    s = filename
    if s.endswith(".gz"):
        s = s[:-3]
    s = re.sub(r"\.(txt|csv|bsv)$", "", s)
    s = re.sub(r"_timelines_timeline_\d+$", "", s)
    s = re.sub(r"_extracted$", "", s)
    m = re.fullmatch(r"timeline_(\d+)_summary", s)
    if m:
        return m.group(1)
    m = re.search(r"annotations_(?:jcw_)?(\d+)", s)
    if m:
        return m.group(1)
    return s.split("-DS-")[0]


def index_folder(root, folder, exts, warnings):
    """id -> path, for the top level of folder only (subfolders are ignored)."""
    path = os.path.join(root, folder)
    if not os.path.isdir(path):
        sys.exit("missing folder: %s" % path)
    out = {}
    for fn in sorted(os.listdir(path)):
        if fn.startswith(".") or not fn.lower().endswith(exts):
            continue
        cid = case_id(fn)
        if cid in out:
            warnings.append(
                "two files map to case %s in %s: %s and %s (kept the first)"
                % (cid, folder, os.path.basename(out[cid]), fn)
            )
            continue
        out[cid] = os.path.join(path, fn)
    return out


# ---------------------------------------------------------------- readers

def read_note(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read().strip("\n")


def read_manual(path, stats):
    """Manual annotation, .csv (event,time header) or .bsv (no header)."""
    rows = []
    if path.lower().endswith(".csv"):
        with open(path, "r", newline="", encoding="utf-8", errors="replace") as fh:
            raw = [r for r in csv.reader(fh) if r and any(c.strip() for c in r)]
        if raw and raw[0][0].strip().lower() == "event":
            raw = raw[1:]
        for r in raw:
            event = r[0].strip()
            time = r[1].strip() if len(r) > 1 else ""
            rows.append((event, time))
    else:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if not line.strip():
                    continue
                parts = line.rstrip("\n").split("|")
                event = parts[0].strip()
                time = parts[1].strip() if len(parts) > 1 else ""
                rows.append((event, time))
    kept = []
    for event, time in rows:
        if not time:
            stats["manual_missing_time"] += 1
            continue
        kept.append((event, time))
    return kept


def read_model(path, stats):
    """Gzipped model timeline. Six columns (uid4|mention|time|bounds|known|context)
    or four (uid4|mention|time|bounds). A header row may or may not be present.
    Mention and time are always fields 1 and 2."""
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
        lines = [l for l in fh.read().splitlines() if l.strip()]
    rows = []
    heading = True
    for i, line in enumerate(lines):
        parts = line.split("|")
        first = parts[0].strip().lower()
        if heading and first in ("uid", "uid4"):
            stats["header_rows_skipped"] += 1
            continue  # header. The unimodal exports repeat it twice.
        heading = False
        if len(parts) < 3:
            stats["model_short_rows"] += 1
            stats["model_short_examples"].append(
                "%s line %d: %r" % (os.path.basename(path), i + 1, line[:90])
            )
            continue
        event = parts[1].strip()
        time = parts[2].strip()
        if not time:
            stats["model_missing_time"] += 1
            continue
        rows.append((event, time))
    return rows


def read_summary(path, stats, cid):
    """Structured summary, verbatim. Also checks the declared event-type count
    against the number of bullets actually present, which is how the 500-cap
    truncation showed up last time."""
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read().strip("\n")
    declared = shown = None
    m = re.search(r"event types:\s*(\d+)", text)
    if m:
        declared = int(m.group(1))
        shown = len(re.findall(r"^- ", text, flags=re.M))
        if shown < declared:
            stats["summary_truncated"] += 1
            stats["summary_trunc_examples"].append(
                "%s: header declares %d event types, %d bullets present, %d withheld"
                % (cid, declared, shown, declared - shown)
            )
    if not text.startswith("[TABULAR_EHR_SUMMARY_START]"):
        stats["summary_no_start_marker"] += 1
    if "[TABULAR_EHR_SUMMARY_END]" not in text:
        stats["summary_no_end_marker"] += 1
    return text, declared, shown


def render(rows, stats, label, header=True):
    lines = ["event | time"] if header else []
    for event, _ in rows:
        if "|" in event:
            stats["pipe_in_event"] += 1
            stats["pipe_examples"].append("%s: %r" % (label, event[:70]))
    lines.extend("%s | %s" % (e, t) for e, t in rows)
    return "\n".join(lines)


# ---------------------------------------------------------------- template

def load_template(path):
    if not os.path.isfile(path):
        sys.exit(
            "template not found: %s\n"
            "Point --template at your 2-column judge prompt. It needs three "
            "placeholders: %s" % (path, ", ".join(PLACEHOLDERS))
        )
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    for form in PLACEHOLDER_FORMS:
        tokens = [form % p for p in PLACEHOLDERS]
        if all(t in text for t in tokens):
            mapping = dict(zip(PLACEHOLDERS, tokens))
            for name in SUMMARY_PLACEHOLDERS:
                token = form % name
                if token in text:
                    mapping["SUMMARY"] = token
                    break
            return text, mapping
    found = [p for p in PLACEHOLDERS if p in text]
    sys.exit(
        "could not find all three placeholders in %s in a single style.\n"
        "Names seen in the file: %s\n"
        "Accepted styles: %s"
        % (path, found or "none", ", ".join(f % "NAME" for f in PLACEHOLDER_FORMS))
    )


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="bundle root (default: .)")
    ap.add_argument("--template", default="judge_template.txt")
    ap.add_argument("--out", default="round_robin_prompts")
    ap.add_argument("--manual-format", choices=("csv", "bsv"), default="csv")
    ap.add_argument("--no-timeline-header", action="store_true",
                    help="omit the 'event | time' header line from each "
                         "timeline block (the structured prompt says the "
                         "timelines carry a header, so it is on by default)")
    ap.add_argument("--summaries", default=FOLDERS["summary"],
                    help="structured summary folder, relative to --root "
                         "(default: %s). Only used if the template has a "
                         "structured placeholder." % FOLDERS["summary"])
    ap.add_argument(
        "--pairings", default="remaining",
        help="a preset (%s) or a comma-separated list of pairing names. "
             "Presets and names combine, e.g. --pairings done,glm52uni_vs_dsv32uni. "
             "Default is the seven pairings that have not been run."
             % ", ".join(PRESETS),
    )
    ap.add_argument("--list-pairings", action="store_true",
                    help="print every pairing this bundle can build, with case counts, "
                         "and write nothing")
    args = ap.parse_args()

    template, tokens = load_template(args.template)

    warnings = []
    stats = Counter()
    stats["model_short_examples"] = []
    stats["pipe_examples"] = []
    stats["summary_trunc_examples"] = []

    notes = index_folder(args.root, FOLDERS["notes"], (".txt",), warnings)
    manual_ext = (".csv",) if args.manual_format == "csv" else (".bsv",)

    use_summary = "SUMMARY" in tokens
    summaries = {}
    if use_summary:
        summary_files = index_folder(args.root, args.summaries, (".txt",), warnings)
        for cid, path in summary_files.items():
            summaries[cid] = read_summary(path, stats, cid)

    timelines = {}
    for name, (folder, kind) in sorted(SOURCES.items()):
        if not os.path.isdir(os.path.join(args.root, folder)):
            warnings.append("no folder %s, so source %s is unavailable" % (folder, name))
            timelines[name] = {}
            continue
        ext = manual_ext if kind == "manual" else (".gz",)
        files = index_folder(args.root, folder, ext, warnings)
        reader = read_manual if kind == "manual" else read_model
        timelines[name] = {cid: reader(path, stats) for cid, path in files.items()}

    if args.list_pairings:
        base = set(notes) & (set(summaries) if use_summary else set(notes))
        print("%-24s %-10s %-10s %s" % ("pairing", "A", "B", "cases"))
        for name, a, b in PRESETS["all"]:
            n = len(base & set(timelines.get(a, {})) & set(timelines.get(b, {})))
            print("%-24s %-10s %-10s %d" % (name, a, b, n))
        return

    wanted, seen_names = [], set()
    for token in args.pairings.split(","):
        token = token.strip()
        if not token:
            continue
        entries = PRESETS.get(token)
        if entries is None:
            entries = [p for p in PRESETS["all"] if p[0] == token]
            if not entries:
                sys.exit("unknown pairing or preset: %s\nknown presets: %s\nknown pairings: %s"
                         % (token, ", ".join(PRESETS),
                            ", ".join(p[0] for p in PRESETS["all"])))
        for entry in entries:
            if entry[0] not in seen_names:
                seen_names.add(entry[0])
                wanted.append(entry)
    if not wanted:
        sys.exit("no pairing matched --pairings %s" % args.pairings)
    missing_src = {s for _, a, b in wanted for s in (a, b) if s not in timelines or not timelines[s]}
    if missing_src:
        sys.exit("no timelines loaded for: %s. Check the folder names in SOURCES."
                 % ", ".join(sorted(missing_src)))

    all_ids = sorted(set(notes) | set().union(*[set(t) for t in timelines.values()] or [set()]))
    built, skipped, identical = [], [], []

    for dirname, a_src, b_src in wanted:
        for cid in all_ids:
            missing = []
            if cid not in notes:
                missing.append("note")
            if cid not in timelines[a_src]:
                missing.append(a_src)
            if cid not in timelines[b_src]:
                missing.append(b_src)
            if use_summary and cid not in summaries:
                missing.append("summary")
            if missing:
                skipped.append((dirname, cid, "no " + ", ".join(missing)))
                continue
            a_rows = timelines[a_src][cid]
            b_rows = timelines[b_src][cid]
            hdr = not args.no_timeline_header
            a_text = render(a_rows, stats, "%s %s A" % (dirname, cid), hdr)
            b_text = render(b_rows, stats, "%s %s B" % (dirname, cid), hdr)
            if a_text == b_text:
                identical.append((dirname, cid))
            note = read_note(notes[cid])
            prompt = template
            prompt = prompt.replace(tokens["DISCHARGE_NOTE"], note)
            prompt = prompt.replace(tokens["TIMELINE_A"], a_text)
            prompt = prompt.replace(tokens["TIMELINE_B"], b_text)
            s_text, s_declared, s_shown = ("", "", "")
            if use_summary:
                s_text, s_declared, s_shown = summaries[cid]
                prompt = prompt.replace(tokens["SUMMARY"], s_text)
            built.append(
                dict(
                    pairing=dirname,
                    case_id=cid,
                    a_source=a_src,
                    b_source=b_src,
                    a_rows=len(a_rows),
                    b_rows=len(b_rows),
                    note_chars=len(note),
                    summary_chars=len(s_text),
                    summary_types_declared=s_declared if s_declared is not None else "",
                    summary_types_shown=s_shown if s_shown is not None else "",
                    prompt_chars=len(prompt),
                    est_tokens=round(len(prompt) / 4),
                    text=prompt,
                )
            )

    if not built:
        sys.exit("nothing to build; check --root and folder names")

    out_root = os.path.join(args.root, args.out)
    for dirname, _, _ in wanted:
        os.makedirs(os.path.join(out_root, dirname), exist_ok=True)
    for rec in built:
        dest = os.path.join(out_root, rec["pairing"], "prompt_%s.txt" % rec["case_id"])
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(rec["text"])

    cols = ["pairing", "case_id", "a_source", "b_source", "a_rows", "b_rows",
            "note_chars", "summary_chars", "summary_types_declared",
            "summary_types_shown", "prompt_chars", "est_tokens"]
    with open(os.path.join(out_root, "manifest.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for rec in built:
            w.writerow({c: rec[c] for c in cols})

    # ---------------------------------------------------------- report
    lines = []
    lines.append("template: %s (placeholder style %s)"
                 % (args.template, tokens["TIMELINE_A"]))
    lines.append("manual source: .%s" % args.manual_format)
    lines.append("timeline header line: %s"
                 % ("omitted" if args.no_timeline_header else "'event | time'"))
    lines.append("structured summary: %s"
                 % ("%s, placeholder %s" % (args.summaries, tokens["SUMMARY"])
                    if use_summary else
                    "not used (no structured placeholder in the template)"))
    lines.append("")
    lines.append("prompts written: %d" % len(built))
    for dirname, _, _ in wanted:
        n = sum(1 for r in built if r["pairing"] == dirname)
        lines.append("  %-16s %d" % (dirname, n))
    heaviest = max(built, key=lambda r: r["prompt_chars"])
    lines.append("")
    lines.append("heaviest prompt: %s %s, %d chars, ~%d tokens at chars/4"
                 % (heaviest["pairing"], heaviest["case_id"],
                    heaviest["prompt_chars"], heaviest["est_tokens"]))
    lines.append("total input tokens across all prompts: ~%d"
                 % sum(r["est_tokens"] for r in built))

    if skipped:
        lines.append("")
        lines.append("skipped %d case/pairing combinations:" % len(skipped))
        for dirname, cid, why in skipped:
            lines.append("  %-16s %-10s %s" % (dirname, cid, why))
    if identical:
        lines.append("")
        lines.append("WARNING: A and B rendered identically (self-comparison):")
        for dirname, cid in identical:
            lines.append("  %s %s" % (dirname, cid))
    if stats["summary_truncated"]:
        lines.append("")
        lines.append("WARNING: %d summaries show fewer bullets than their header "
                     "declares, so event types were dropped by the cap:"
                     % stats["summary_truncated"])
        for ex in stats["summary_trunc_examples"]:
            lines.append("  " + ex)
    if stats["summary_no_start_marker"] or stats["summary_no_end_marker"]:
        lines.append("")
        lines.append("summaries missing a marker: start %d, end %d"
                     % (stats["summary_no_start_marker"],
                        stats["summary_no_end_marker"]))
    if stats["header_rows_skipped"]:
        lines.append("")
        lines.append("header rows skipped across the timeline files read: %d. The unimodal "
                     "exports repeat the uid4 header twice, so every leading header row is "
                     "dropped rather than only the first."
                     % stats["header_rows_skipped"])
    if stats["model_short_rows"]:
        lines.append("")
        lines.append("dropped %d model rows with fewer than 3 fields:"
                     % stats["model_short_rows"])
        for ex in stats["model_short_examples"]:
            lines.append("  " + ex)
    if stats["model_missing_time"] or stats["manual_missing_time"]:
        lines.append("")
        lines.append("dropped rows with an empty time: model %d, manual %d"
                     % (stats["model_missing_time"], stats["manual_missing_time"]))
    if stats["pipe_in_event"]:
        lines.append("")
        lines.append("WARNING: %d event strings contain a pipe, so those prompt "
                     "lines have more than two columns (text left verbatim):"
                     % stats["pipe_in_event"])
        for ex in stats["pipe_examples"][:10]:
            lines.append("  " + ex)
    if warnings:
        lines.append("")
        lines.append("other warnings:")
        for w in warnings:
            lines.append("  " + w)

    report = "\n".join(lines) + "\n"
    with open(os.path.join(out_root, "build_report.txt"), "w", encoding="utf-8") as fh:
        fh.write(report)
    print(report, end="")
    print("wrote %s/" % out_root)


if __name__ == "__main__":
    main()

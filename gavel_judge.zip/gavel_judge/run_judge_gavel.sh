#!/bin/bash
#SBATCH --job-name=gavel_judge_gguf
#SBATCH --time=4-00:00:00
#SBATCH --mem=128g
#SBATCH --partition=gpu
#SBATCH --qos=gpunlm2025.2
#SBATCH --gres=gpu:a100:4
#SBATCH --output=slurm_%j.out
#SBATCH --error=slurm_%j.err

# This script lives inside the round robin prompt folder and finds the pairing
# folders next to itself. Submit it from that folder:
#     cd round_robin_prompts_MIMIC && sbatch run_judge_gavel.sh
#
# Slurm logs land in the submission folder as slurm_<jobid>.out/.err. They used
# to be written to sbatch_output/ and sbatch_error/, which Slurm opens before
# this script runs, so the job died at launch if those folders were absent.

set -euo pipefail

module load CUDA/12.8.1 gcc
eval "$(conda shell.bash hook)"
conda activate "${GAVEL_CONDA_ENV:?set GAVEL_CONDA_ENV to your conda environment}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="${SCRIPT_DIR}/run_judge_gavel.py"
LLAMA_UTILS="${SCRIPT_DIR}/llm_server_utils.sh"

export LLAMA_SERVER="${LLAMA_SERVER:?set LLAMA_SERVER to your llama.cpp llama-server binary}"
export LLAMA_LOG_DIR="${SCRIPT_DIR}/sbatch_logs"
# 4 A100s are requested above. The original exposed only device 0; expose all
# four, or drop --gres to gpu:a100:1.
export CUDA_DEVICES="0,1,2,3"
export LLAMA_TIMEOUT=1200

# ---- site specific: set these in the environment before submitting ----
#   GAVEL_CONDA_ENV  conda environment with python3
#   LLAMA_SERVER     path to the llama.cpp llama-server binary
#   MODEL_PATH       the .gguf being judged with
#   MODEL_ALIAS      alias passed to the server, defaults to "judge"
# The #SBATCH --partition/--qos/--gres lines above are also cluster specific.
export MODEL_PATH="${MODEL_PATH:?set MODEL_PATH to the .gguf you are running}"
export MODEL_ALIAS="${MODEL_ALIAS:-judge}"
export PORT=8001

# ---- token budget, read by both llm_server_utils.sh and run_judge_gavel.py ----
# Sized from the last run's run_log.csv rather than guessed.
#   prompt tokens observed:      max 129,554   median 51,227
#   completion tokens observed:  max 184,267   median 30,647   (reasoning counts here)
#   prompt+completion observed:  max 214,808
# chars/4 underestimated the real prompt by more than half; the measured ratio was
# 2.06 to 3.01 chars per token. This bundle's heaviest prompt is 333,777 chars, so
# ~162K tokens at the worst observed ratio.
#   162K prompt + 262K output = 424K, so ctx is set to 512K.
# The last run capped output at 35,000 and truncated 74 of 112 first attempts, then
# walked up through 80K, 100K, 120K and 200K; 200,000 still truncated 6. Starting
# at 262,144 should clear every case on the first pass.
export LLAMA_CTX_SIZE=524288
export LLAMA_MAX_TOKENS=262144

# ---- output. Prompts are read from the pairing folders beside this script ----
export OUTPUT_DIR="${SCRIPT_DIR}/judge_outputs"

export NO_PROXY="localhost,127.0.0.1,::1"
export no_proxy="$NO_PROXY"
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib:${LD_LIBRARY_PATH:-}"

mkdir -p "$LLAMA_LOG_DIR" "$OUTPUT_DIR"

source "$LLAMA_UTILS"

cleanup() {
    if [[ -n "${LLAMA_SERVER_PID:-}" ]]; then
        kill_server "$LLAMA_SERVER_PID" "$PORT"
    fi
}
trap cleanup EXIT

# Discover pairing folders: any subfolder of this one holding prompt_*.txt.
pairings=()
for d in "${SCRIPT_DIR}"/*/; do
    name="$(basename "$d")"
    [[ "$name" == __* || "$name" == .* ]] && continue
    compgen -G "${d}prompt_*.txt" > /dev/null || continue
    pairings+=("$name")
done

if [[ ${#pairings[@]} -eq 0 ]]; then
    echo "No pairing folders with prompt_*.txt found in ${SCRIPT_DIR}"
    exit 1
fi
echo "Pairings: ${pairings[*]}"

start_server "$MODEL_PATH" "$MODEL_ALIAS" "$PORT"

total=0
failures=0
consecutive=0

for pairing in "${pairings[@]}"; do
    pdir="${SCRIPT_DIR}/${pairing}"
    mkdir -p "${OUTPUT_DIR}/${pairing}"

    for fname in "${pdir}"/prompt_*.txt; do
        base="$(basename "$fname" .txt)"
        case_id="${base#prompt_}"
        out_file="${OUTPUT_DIR}/${pairing}/${case_id}.json"
        total=$((total + 1))

        echo "[${total}] ${pairing} ${case_id}"

        # A failed call must not end the run. set -e would abort the whole job on
        # the first HTTP error or timeout, leaving every later prompt unrun.
        if ! python "$PYTHON_SCRIPT" \
            --summary_file "$fname" \
            --llm_endpoint "http://127.0.0.1:${PORT}" \
            --model_basename "$MODEL_ALIAS" \
            --log_folder "$OUTPUT_DIR" \
            --output_file "$out_file" \
            --max_tokens "$LLAMA_MAX_TOKENS" \
            --ctx_size "$LLAMA_CTX_SIZE" \
            --debug \
            --omit_tags think; then
            echo "FAILED ${pairing} ${case_id}" >&2
            echo "${pairing}/${case_id}" >> "${OUTPUT_DIR}/failed.txt"
            failures=$((failures + 1))
            consecutive=$((consecutive + 1))
            if [[ $consecutive -ge 5 ]]; then
                echo "Five consecutive failures, the server is probably down. Stopping." >&2
                exit 1
            fi
        else
            consecutive=0
        fi
    done
done

echo
echo "Prompts seen:  ${total}"
echo "JSON written:  $(find "$OUTPUT_DIR" -name '*.json' | wc -l)"
echo "Unparsed:      $(find "$OUTPUT_DIR" -name '*.raw.txt' | wc -l)"
echo "Call failures: ${failures}"
if [[ $failures -gt 0 ]]; then
    echo "Failed cases are listed in ${OUTPUT_DIR}/failed.txt"
fi
echo "Rerun this script to retry anything without a .json."

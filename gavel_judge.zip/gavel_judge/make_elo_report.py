#!/usr/bin/env python3
"""
make_elo_report.py

Builds a self-contained GAVEL report from round robin judge outputs.

Drop this in the judge_outputs folder and run it:

    cd judge_outputs
    python3 make_elo_report.py

It finds every <pairing>/<case>.json below itself and writes gavel_report.html
with four sections:

  1. Weights          the seven error categories and what each is worth
  2. Leaderboard      Bradley-Terry rating per extractor, with intervals
  3. Discrepancies    counts charged against each extractor, per matchup
  4. Paired tests     head to head on the same-model pairs, bootstrapped

Section 4 exists because sections 2 and 3 cannot answer it. A leaderboard
interval is an extractor's uncertainty against the whole field, so two bars can
overlap while the direct comparison between those two is decisive. Section 4
resamples the head to head evidence itself.

Pairing folders must be named <a>_vs_<b>. Extractor names come from the folder
names. Standard library only.
"""

import argparse
import collections
import html
import json
import math
import os
import random
import re
import sys

CSS = r"""
.data tr.band td{border-top:1px solid var(--rule)}
:root{
  --paper:#FAFAF7; --panel:#FFFFFF; --ink:#141E26; --muted:#5C6B73;
  --rule:#DCDFD8; --rule-strong:#B9BEB4; --for:#17635F; --against:#8E3B5E; --warn:#A8842C;
}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{
  margin:0; background:var(--paper); color:var(--ink);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  font-size:15px; line-height:1.55;
}
.wrap{max-width:1040px; margin:0 auto; padding:0 24px 96px}
code,.mono,table.data,.derive dd{font-family:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace}

header.masthead{padding:56px 0 24px; border-bottom:2px solid var(--ink)}
.eyebrow{font-size:12px; letter-spacing:.16em; text-transform:uppercase; color:var(--muted); margin:0 0 10px}
h1{
  font-family:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;
  font-size:42px; line-height:1.05; font-weight:600; letter-spacing:-.015em; margin:0 0 12px;
}
.standfirst{font-size:17px; color:var(--muted); max-width:62ch; margin:0}
.facts{display:flex; flex-wrap:wrap; gap:28px; margin:24px 0 0; padding:0; list-style:none}
.facts div{min-width:92px}
.facts dt{font-size:11px; letter-spacing:.13em; text-transform:uppercase; color:var(--muted)}
.facts dd{margin:2px 0 0; font-size:23px; font-variant-numeric:tabular-nums}

section.panel{margin:52px 0 0}
section.panel > h2{
  font-family:"Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;
  font-size:27px; font-weight:600; letter-spacing:-.01em; margin:0 0 4px;
}
section.panel > p.lede{margin:0 0 18px; color:var(--muted); max-width:68ch}
h3.sub{font-size:14px; letter-spacing:.06em; text-transform:uppercase; color:var(--muted);
  margin:34px 0 10px; padding-bottom:6px; border-bottom:1px solid var(--rule)}

.derive{margin:0 0 18px; padding:12px 16px; background:var(--panel);
  border:1px solid var(--rule); border-left:3px solid var(--for); font-size:12.5px}
.derive dl{display:grid; grid-template-columns:88px 1fr; gap:5px 14px; margin:0}
.derive dt{color:var(--muted); letter-spacing:.1em; text-transform:uppercase; font-size:10.5px; padding-top:2px}
.derive dd{margin:0; font-size:12.5px; line-height:1.5}

table.data{width:100%; border-collapse:collapse; font-size:12.5px; font-variant-numeric:tabular-nums}
table.data caption{text-align:left; font-size:12.5px; color:var(--muted); padding:0 0 8px}
table.data th,table.data td{padding:6px 9px; border-bottom:1px solid var(--rule); text-align:right; white-space:nowrap}
table.data th:first-child,table.data td:first-child{text-align:left}
table.data thead th{border-bottom:1px solid var(--rule-strong); color:var(--muted);
  font-weight:600; font-size:11px; letter-spacing:.05em; text-transform:uppercase}
table.data tbody tr:hover{background:#F1F3EE}
table.data tfoot td{border-top:1px solid var(--rule-strong); border-bottom:0; color:var(--muted)}
.lead{font-weight:600}
.pos{color:var(--for)} .neg{color:var(--against)} .flat{color:var(--muted)} .zero{color:#C3C8BE}
.scroller{overflow-x:auto; -webkit-overflow-scrolling:touch}

.bench{display:grid; grid-template-columns:minmax(270px,.85fr) minmax(340px,1.15fr); gap:28px; align-items:start}
.dials{margin:0; padding:0; border:0; min-width:0}
.dial{display:grid; grid-template-columns:1fr auto; gap:2px 10px; align-items:center;
  padding:7px 0; border-bottom:1px solid var(--rule)}
.dial:last-of-type{border-bottom:0}
.dial label{font-size:12.5px}
.dial output{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:12.5px;
  font-variant-numeric:tabular-nums; min-width:34px; text-align:right}
.dial input[type=range]{grid-column:1 / -1; width:100%; margin:3px 0 0; accent-color:var(--for); height:18px}
.dial .base{font-size:11px; color:var(--muted); grid-column:1 / -1}
.dial.changed label{font-weight:600}
.dial.changed .base{color:var(--for)}
.dial.off label{color:var(--muted); text-decoration:line-through}
.controls{display:flex; flex-wrap:wrap; gap:8px; margin:18px 0 0; align-items:center}
.controls button{font:inherit; font-size:12.5px; padding:7px 14px; cursor:pointer;
  background:var(--ink); color:#fff; border:1px solid var(--ink)}
.controls button.ghost{background:var(--panel); color:var(--ink); border-color:var(--rule-strong)}
.controls button:focus-visible{outline:2px solid var(--for); outline-offset:2px}
.status{font-size:12px; color:var(--muted); margin:10px 0 0}
.livebox{border:1px solid var(--rule); background:var(--panel); padding:16px 18px; min-width:0}
.livebox h4{margin:0 0 4px; font-size:11px; letter-spacing:.1em; text-transform:uppercase;
  color:var(--muted); font-weight:600}
.livebox .hint{font-size:11.5px; color:var(--muted); margin:0 0 12px}
.livebox table.data td,.livebox table.data th{padding:5px 8px}
.bar{display:inline-block; height:9px; background:var(--for); opacity:.28; vertical-align:middle}
.warnrow{color:var(--warn); text-align:left}
.note{font-size:12.5px; color:var(--muted); margin:12px 0 0; max-width:72ch}
.legend{display:flex; flex-wrap:wrap; gap:14px; margin:12px 0 0; font-size:12px; color:var(--muted)}
.legend span{display:inline-flex; align-items:center; gap:6px}
.legend i{width:11px; height:11px; display:inline-block}

figure.chart{margin:0 0 10px; padding:6px 0 0}
figure.chart figcaption{font-size:12.5px; color:var(--muted); margin-top:4px}
svg .grid{stroke:var(--rule); stroke-width:1}
svg .ci{stroke:var(--rule-strong); stroke-width:2}
svg .cicap{stroke:var(--rule-strong); stroke-width:2}
svg .dot{fill:var(--for)}
svg text{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
svg .rowlabel{font-size:13px; fill:var(--ink); font-weight:600}
svg .tick,svg .axis{font-size:11px; fill:var(--muted)}
svg .value{font-size:13px; fill:var(--ink)}
svg .valuesub{font-size:11px; fill:var(--muted)}
footer.colophon{margin:64px 0 0; padding:22px 0 0; border-top:2px solid var(--ink);
  font-size:12.5px; color:var(--muted)}

@media (max-width:860px){.bench{grid-template-columns:1fr}}
@media (max-width:720px){
  h1{font-size:31px}
  .wrap{padding:0 16px 64px}
  .derive dl{grid-template-columns:1fr; gap:2px}
  .derive dt{padding-top:8px}
  table.data{font-size:11.5px}
}
@media (prefers-reduced-motion:reduce){*{transition:none!important; animation:none!important}}
@media print{body{background:#fff} .controls{display:none}}"""

JS_TAIL = r"""</div><script>
// The page holds one row per game with the count of each error category charged to
// each side. Moving a dial rescores every game and refits Bradley-Terry here, using
// the same iterative scaling as the Python. Nothing is fetched, nothing approximated.
(function(){
  var data = window.GAVEL;
  if (!data) { return; }

  var models = data.models;
  var TOL = 1e-11, MAX_ROUNDS = 2000, CATS = data.categories.length;

  function shares(weights){
    // points go to the side the judge sided WITH, so a category charged to B pays A
    var out = [];
    for (var i = 0; i < data.games.length; i++){
      var game = data.games[i];
      var pointsA = 0, pointsB = 0;
      for (var c = 0; c < CATS; c++){
        pointsA += weights[c] * game.b[c];
        pointsB += weights[c] * game.a[c];
      }
      var total = pointsA + pointsB;
      // no decisive finding under these weights is a draw, not a dropped game
      out.push([game.x, game.y, total > 0 ? pointsA / total : 0.5, game.c]);
    }
    return out;
  }

  function fit(pairs){
    var n = models.length, i, j;
    var strength = new Float64Array(n).fill(1);
    var wins = new Float64Array(n);
    var played = [];
    for (i = 0; i < n; i++){ played.push(new Float64Array(n)); }
    for (i = 0; i < pairs.length; i++){
      var a = pairs[i][0], b = pairs[i][1], share = pairs[i][2];
      wins[a] += share; wins[b] += 1 - share;
      played[a][b] += 1; played[b][a] += 1;
    }
    var updated = new Float64Array(n);
    for (var round = 0; round < MAX_ROUNDS; round++){
      for (i = 0; i < n; i++){
        var denominator = 0;
        for (j = 0; j < n; j++){
          if (j !== i && played[i][j]){ denominator += played[i][j] / (strength[i] + strength[j]); }
        }
        updated[i] = (denominator > 0 && wins[i] > 0) ? wins[i] / denominator : strength[i];
      }
      var logSum = 0;
      for (i = 0; i < n; i++){ logSum += Math.log(updated[i]); }
      var centre = Math.exp(logSum / n);
      var moved = 0;
      for (i = 0; i < n; i++){
        updated[i] /= centre;
        moved = Math.max(moved, Math.abs(updated[i] - strength[i]));
        strength[i] = updated[i];
      }
      if (moved < TOL) { break; }
    }
    var scale = 400 / Math.LN10, meanLog = 0;
    for (i = 0; i < n; i++){ meanLog += Math.log(strength[i]); }
    meanLog /= n;
    var elo = new Float64Array(n);
    for (i = 0; i < n; i++){ elo[i] = data.anchor + scale * (Math.log(strength[i]) - meanLog); }
    return elo;
  }

  function meanShares(pairs){
    var n = models.length;
    var sum = new Float64Array(n), count = new Float64Array(n);
    for (var i = 0; i < pairs.length; i++){
      sum[pairs[i][0]] += pairs[i][2]; count[pairs[i][0]] += 1;
      sum[pairs[i][1]] += 1 - pairs[i][2]; count[pairs[i][1]] += 1;
    }
    var out = [];
    for (var m = 0; m < n; m++){ out.push(count[m] ? sum[m] / count[m] : 0); }
    return out;
  }

  // seeded, so one set of dials always gives the same interval
  function rng(seed){
    return function(){
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function intervals(pairs){
    var byCase = {};
    for (var i = 0; i < pairs.length; i++){
      (byCase[pairs[i][3]] = byCase[pairs[i][3]] || []).push(pairs[i]);
    }
    var cases = Object.keys(byCase);
    var random = rng(data.seed);
    var draws = [];
    for (var m = 0; m < models.length; m++){ draws.push([]); }
    for (var round = 0; round < data.liveRounds; round++){
      var sample = [];
      for (var k = 0; k < cases.length; k++){
        var chosen = byCase[cases[Math.floor(random() * cases.length)]];
        for (var g = 0; g < chosen.length; g++){ sample.push(chosen[g]); }
      }
      var elo = fit(sample);
      for (m = 0; m < models.length; m++){ draws[m].push(elo[m]); }
    }
    var out = [];
    for (m = 0; m < models.length; m++){
      draws[m].sort(function(p, q){ return p - q; });
      out.push([draws[m][Math.floor(0.025 * draws[m].length)],
                draws[m][Math.floor(0.975 * draws[m].length)]]);
    }
    return out;
  }

  var dials = Array.prototype.slice.call(document.querySelectorAll('.dial input[type=range]'));
  var body = document.getElementById('live-body');
  var status = document.getElementById('live-status');
  var orderNote = document.getElementById('live-order');
  var pending = null;

  function atBaseWeights(weights){
    for (var i = 0; i < weights.length; i++){
      if (Math.abs(weights[i] - data.weights[i]) > 1e-9) { return false; }
    }
    return true;
  }

  function render(withIntervals){
    var weights = dials.map(function(dial){ return parseFloat(dial.value); });
    dials.forEach(function(dial, index){
      var row = dial.closest('.dial');
      row.querySelector('output').textContent = weights[index].toFixed(1);
      row.classList.toggle('changed', Math.abs(weights[index] - data.weights[index]) > 1e-9);
      row.classList.toggle('off', weights[index] === 0);
    });

    var pairs = shares(weights);
    var allZero = weights.every(function(value){ return value === 0; });

    // at the set weights show the figures the page was built with, at the full
    // resample count, rather than a second and slightly different estimate
    var base = atBaseWeights(weights);
    var elo = base ? data.baseElo : fit(pairs);
    var share = base ? data.baseShare : meanShares(pairs);
    var band = base ? data.baseBand : (withIntervals ? intervals(pairs) : null);

    var order = models.map(function(name, index){ return index; });
    order.sort(function(p, q){ return elo[q] - elo[p]; });

    var lo = Infinity, hi = -Infinity;
    order.forEach(function(index){
      lo = Math.min(lo, elo[index]); hi = Math.max(hi, elo[index]);
    });

    body.innerHTML = order.map(function(index, position){
      var move = data.baseOrder.indexOf(index) - position;
      var moved = move === 0
        ? '<span class="flat">&ndash;</span>'
        : '<span class="' + (move > 0 ? 'pos' : 'neg') + '">'
          + (move > 0 ? '&uarr;' : '&darr;') + Math.abs(move) + '</span>';
      var delta = elo[index] - data.baseElo[index];
      var width = hi > lo ? 4 + 96 * (elo[index] - lo) / (hi - lo) : 50;
      return '<tr>'
        + '<td><span class="lead">' + models[index] + '</span></td>'
        + '<td>' + elo[index].toFixed(0)
        + ' <span class="bar" style="width:' + width.toFixed(1) + 'px"></span></td>'
        + '<td>' + (band ? band[index][0].toFixed(0) + ' to ' + band[index][1].toFixed(0)
                         : '<span class="flat">&hellip;</span>') + '</td>'
        + '<td>' + (Math.abs(delta) < 0.5 ? '<span class="flat">0</span>'
            : '<span class="' + (delta > 0 ? 'pos' : 'neg') + '">'
              + (delta > 0 ? '+' : '') + delta.toFixed(0) + '</span>') + '</td>'
        + '<td>' + (100 * share[index]).toFixed(1) + '%</td>'
        + '<td>' + moved + '</td></tr>';
    }).join('');

    var spread = 0;
    for (var s = 0; s < models.length; s++){ spread = Math.max(spread, Math.abs(elo[s] - 1500)); }
    var names = order.map(function(index){ return models[index]; });
    var unchanged = names.join(' ')
      === data.baseOrder.map(function(i){ return models[i]; }).join(' ');
    if (spread < 0.5){
      orderNote.innerHTML = 'Every extractor sits at the same rating, so there is no order '
        + 'to read. The listing below is alphabetical, not a ranking.';
    } else {
      orderNote.innerHTML = unchanged
        ? 'Same order as the set weights.'
        : 'Order now <code>' + names.join(' &gt; ') + '</code>.';
    }
    var drawn = 0;
    for (var d = 0; d < pairs.length; d++){ if (pairs[d][2] === 0.5) { drawn += 1; } }
    status.textContent = allZero
      ? 'Every weight is zero, so every game is a draw and nothing separates the extractors.'
      : (pairs.length + ' games, ' + drawn + ' drawn'
         + (base ? ', at the set weights' : (band ? '' : ', recomputing intervals')));
  }

  function schedule(){
    render(false);
    if (pending) { clearTimeout(pending); }
    pending = setTimeout(function(){ render(true); }, 220);
  }

  dials.forEach(function(dial){ dial.addEventListener('input', schedule); });
  document.getElementById('live-reset').addEventListener('click', function(){
    dials.forEach(function(dial, index){ dial.value = data.weights[index]; });
    render(true);
  });
  document.getElementById('live-flat').addEventListener('click', function(){
    dials.forEach(function(dial){ dial.value = 1; });
    render(true);
  });

  render(true);
})();
</script></body></html>"""


CATEGORIES = [
    ("overannotated", 3.0,
     "A_ONLY or B_ONLY where the judge ruled against the timeline holding the event"),
    ("false duplicate", 2.0,
     "DUPLICATE where the judge ruled against the duplicating side"),
    ("wrong time", 2.0, "TIMING"),
    ("wrong value", 2.0, "VALUE"),
    ("missed positive", 1.0, "A_ONLY or B_ONLY upheld, polarity present"),
    ("missed negative", 0.5, "A_ONLY or B_ONLY upheld, polarity absent"),
    ("missed recurrence", 0.5, "DUPLICATE where the judge upheld the duplicating side"),
]
CAT_KEYS = [c[0].replace(" ", "_") for c in CATEGORIES]
NCAT = len(CATEGORIES)
SWATCHES = ["#8E3B5E", "#B4653A", "#17635F", "#2F7C9A", "#5B6E52", "#8A8F73", "#A8842C"]
DECISIVE = ("A", "B")

# Section 4 runs on pairs of extractors that differ in one controlled way. A pair
# is picked up automatically when one name is the other plus a suffix, so glm52
# against glm52uni qualifies and glm52 against dsv32 does not.
VARIANT_SUFFIXES = ("uni", "_uni", "unimodal", "_unimodal")

# The annotation-batch split is study data, not code, so it is not stored here.
# Pass --annotation-batch with a file listing the case reports annotated in the
# second batch, one per line, ids or filenames. Without it, section 5 is skipped.
ASSISTED_IDS = set()


def load_annotation_batch(path):
    """Case ids for the later annotation batch. Accepts bare ids or filenames;
    only the leading id is used, so a note filename works as-is."""
    ids = set()
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            for token in line.split():
                token = token.strip()
                if token and not token.startswith("#"):
                    ids.add(token.split("-DS-")[0])
    if not ids:
        sys.exit(f"{path} lists no case ids")
    return ids

# The only extractor whose conditions differ between the two batches. Every model
# ran identically on all 40 case reports.
ASSIST_SUBJECT = "human"


def discover(root):
    jobs = []
    for name in sorted(os.listdir(root)):
        folder = os.path.join(root, name)
        if not os.path.isdir(folder) or name.startswith((".", "__")) or "_vs_" not in name:
            continue
        a, b = name.split("_vs_", 1)
        for fn in sorted(os.listdir(folder)):
            if fn.endswith(".json"):
                jobs.append((name, a, b, fn[:-5], os.path.join(folder, fn)))
    return jobs


def charge(finding):
    """Category and the side it is charged against, or None when nobody pays.
    A verdict of A means B was wrong, so it is charged against B."""
    verdict = finding.get("verdict")
    if verdict not in DECISIVE:
        return None
    kind = finding.get("type")
    loser = "b" if verdict == "A" else "a"
    if kind == "TIMING":
        return CAT_KEYS.index("wrong_time"), loser
    if kind == "VALUE":
        return CAT_KEYS.index("wrong_value"), loser
    if kind in ("A_ONLY", "B_ONLY"):
        holder = "a" if kind == "A_ONLY" else "b"
        if loser == holder:
            return CAT_KEYS.index("overannotated"), holder
        absent = finding.get("polarity") == "absent"
        return CAT_KEYS.index("missed_negative" if absent else "missed_positive"), loser
    if kind == "DUPLICATE":
        holder = "a" if finding.get("a_event") is not None else "b"
        if loser == holder:
            return CAT_KEYS.index("false_duplicate"), holder
        return CAT_KEYS.index("missed_recurrence"), loser
    return None


def shares(games, weights):
    """(x, y, share_to_x, case) per game. Points go to the side the judge sided
    with, so a category charged to B pays A."""
    out = []
    for g in games:
        pa = sum(weights[c] * g["b"][c] for c in range(NCAT))
        pb = sum(weights[c] * g["a"][c] for c in range(NCAT))
        total = pa + pb
        out.append((g["x"], g["y"], pa / total if total > 0 else 0.5, g["c"]))
    return out


def fit(pairs, n_models, anchor=1500.0, tol=1e-11, max_rounds=2000):
    strength = [1.0] * n_models
    wins = [0.0] * n_models
    played = [[0.0] * n_models for _ in range(n_models)]
    for a, b, share, _ in pairs:
        wins[a] += share
        wins[b] += 1.0 - share
        played[a][b] += 1
        played[b][a] += 1
    for _ in range(max_rounds):
        updated = [0.0] * n_models
        for i in range(n_models):
            denom = sum(played[i][j] / (strength[i] + strength[j])
                        for j in range(n_models) if j != i and played[i][j])
            updated[i] = wins[i] / denom if denom > 0 and wins[i] > 0 else strength[i]
        centre = math.exp(sum(math.log(u) for u in updated) / n_models)
        moved = 0.0
        for i in range(n_models):
            updated[i] /= centre
            moved = max(moved, abs(updated[i] - strength[i]))
            strength[i] = updated[i]
        if moved < tol:
            break
    scale = 400 / math.log(10)
    mean_log = sum(math.log(s) for s in strength) / n_models
    return [anchor + scale * (math.log(s) - mean_log) for s in strength]


def mean_shares(pairs, n_models):
    total = [0.0] * n_models
    count = [0] * n_models
    for a, b, share, _ in pairs:
        total[a] += share
        count[a] += 1
        total[b] += 1 - share
        count[b] += 1
    return [total[m] / count[m] if count[m] else 0.0 for m in range(n_models)]


def case_resamples(cases, rounds, rng):
    """Reused so every bootstrapped figure on the page rests on the same draws."""
    return [[rng.choice(cases) for _ in cases] for _ in range(rounds)]


def bootstrap_ratings(pairs, n_models, draws):
    by_case = collections.defaultdict(list)
    for p in pairs:
        by_case[p[3]].append(p)
    per_model = [[] for _ in range(n_models)]
    for draw in draws:
        sample = []
        for case in draw:
            sample.extend(by_case[case])
        elo = fit(sample, n_models)
        for m in range(n_models):
            per_model[m].append(elo[m])
    bands = []
    for m in range(n_models):
        per_model[m].sort()
        bands.append([per_model[m][int(0.025 * len(per_model[m]))],
                      per_model[m][int(0.975 * len(per_model[m]))]])
    return bands, per_model


def subgroup(games, keep, weights, n_models, rounds, seed):
    """Refit on one subset of case reports, and count the weighted points charged
    against each extractor per matchup in that subset."""
    sub = [g for g in games if g["c"] in keep]
    if not sub:
        return None
    pairs = shares(sub, weights)
    elo = fit(pairs, n_models)
    cases = sorted({g["c"] for g in sub})
    charged = [[0.0] * NCAT for _ in range(n_models)]
    played = [0] * n_models
    for g in sub:
        played[g["x"]] += 1
        played[g["y"]] += 1
        for c in range(NCAT):
            charged[g["x"]][c] += weights[c] * g["a"][c]
            charged[g["y"]][c] += weights[c] * g["b"][c]
    rate = [[charged[i][c] / played[i] if played[i] else 0.0 for c in range(NCAT)]
            for i in range(n_models)]
    return dict(elo=elo, rate=rate, games=len(sub), cases=len(cases), ids=cases,
                decisive=sum(sum(g["a"]) + sum(g["b"]) for g in sub))


def variant_pairs(models):
    """Find (base, variant) pairs where one name is the other plus a suffix."""
    found = []
    for base in models:
        for other in models:
            if other == base:
                continue
            for suffix in VARIANT_SUFFIXES:
                if other == base + suffix:
                    found.append((base, other))
                    break
    return found


def paired_test(games, models, base, variant, draws, weights):
    """Bootstrap the head to head evidence for one pair, and the gap between
    their ratings from the same resamples. The rating gap is paired: both are
    refitted on each resampled corpus, so the shared noise cancels instead of
    being counted twice the way two marginal intervals do."""
    bi, vi = models.index(base), models.index(variant)
    direct = [g for g in games
              if {g["x"], g["y"]} == {bi, vi}]
    if not direct:
        return None
    by_case = collections.defaultdict(list)
    for g in direct:
        by_case[g["c"]].append(g)

    def share_of(gs):
        """Weighted points, the same currency the leaderboard is fitted on, so
        this section answers the same question sections 1 and 2 do. A finding
        charged against the other side is a point to base."""
        won = lost = 0.0
        for g in gs:
            mine = g["b"] if g["x"] == bi else g["a"]
            theirs = g["a"] if g["x"] == bi else g["b"]
            won += sum(weights[c] * mine[c] for c in range(NCAT))
            lost += sum(weights[c] * theirs[c] for c in range(NCAT))
        return won, lost

    won, lost = share_of(direct)
    observed = 100 * won / (won + lost) if won + lost else 50.0
    empty = sum(1 for g in direct if not any(g["a"]) and not any(g["b"]))

    wins_case = losses_case = tied_case = 0
    for g in direct:
        w, l = share_of([g])
        if w == 0 and l == 0:
            continue          # empty, counted separately
        if w > l:
            wins_case += 1
        elif l > w:
            losses_case += 1
        else:
            tied_case += 1

    cases = sorted(by_case)
    rng = random.Random(hash((base, variant)) & 0xFFFF)
    dist = []
    for _ in range(len(draws)):
        sample = []
        for _ in cases:
            sample.extend(by_case[rng.choice(cases)])
        w, l = share_of(sample)
        if w + l:
            dist.append(100 * w / (w + l))
    dist.sort()
    lo = dist[int(0.025 * len(dist))]
    hi = dist[int(0.975 * len(dist))]
    p_null = 2 * min(sum(1 for d in dist if d <= 50) / len(dist),
                     sum(1 for d in dist if d >= 50) / len(dist))
    return dict(base=base, variant=variant, cases=len(cases), empty=empty,
                findings=int(round(won + lost)),
                observed=observed, lo=lo, hi=hi, p=min(1.0, p_null),
                record=(wins_case, losses_case, tied_case))



def esc(s):
    return html.escape(str(s), quote=True)


def svg_chart(models, elo, band, order):
    """One row per extractor, rating with its interval. Share lives in the table
    below, so it is left off here."""
    lo = min(b[0] for b in band)
    hi = max(b[1] for b in band)
    pad = max(8.0, (hi - lo) * 0.10)
    lo, hi = lo - pad, hi + pad
    left, right = 130.0, 618.0
    top, gap = 62.0, 52.0
    height = top + gap * max(0, len(order) - 1) + 62

    def x(v):
        return left + (right - left) * (v - lo) / (hi - lo) if hi > lo else (left + right) / 2

    rows = []
    step = 50 if (hi - lo) > 150 else 25
    tick = int(math.ceil(lo / step) * step)
    while tick <= hi:
        rows.append(f'<line class="grid" x1="{x(tick):.1f}" y1="30" '
                    f'x2="{x(tick):.1f}" y2="{height-52:.1f}"/>')
        rows.append(f'<text class="tick" x="{x(tick):.1f}" y="{height-30:.1f}" '
                    f'text-anchor="middle">{tick}</text>')
        tick += step
    rows.append('<text class="axis" x="748" y="26" text-anchor="end">rating</text>')
    for slot, idx in enumerate(order):
        y = top + slot * gap
        x0, x1, xc = x(band[idx][0]), x(band[idx][1]), x(elo[idx])
        rows.append(f'<text class="rowlabel" x="104" y="{y+4:.1f}" '
                    f'text-anchor="end">{esc(models[idx])}</text>')
        rows.append(f'<line class="ci" x1="{x0:.1f}" y1="{y:.1f}" x2="{x1:.1f}" y2="{y:.1f}"/>')
        rows.append(f'<line class="cicap" x1="{x0:.1f}" y1="{y-6:.1f}" '
                    f'x2="{x0:.1f}" y2="{y+6:.1f}"/>')
        rows.append(f'<line class="cicap" x1="{x1:.1f}" y1="{y-6:.1f}" '
                    f'x2="{x1:.1f}" y2="{y+6:.1f}"/>')
        rows.append(f'<circle class="dot" cx="{xc:.1f}" cy="{y:.1f}" r="6"/>')
        rows.append(f'<text class="value" x="748" y="{y+4:.1f}" '
                    f'text-anchor="end">{elo[idx]:.0f}</text>')
    return (f'<svg viewBox="0 0 760 {height:.0f}" width="100%" role="img" '
            f'aria-label="Rating with 95 percent interval per extractor" '
            f'preserveAspectRatio="xMidYMid meet">\n' + "\n".join(rows) + "\n</svg>")


def build_html(ctx):
    m = ctx
    models, games, elo, band, share, order = (m["models"], m["games"], m["elo"],
                                              m["band"], m["share"], m["order"])
    n = len(models)
    cases = sorted({g["c"] for g in games})
    findings, decisive = m["findings"], m["decisive"]
    weights = m["weights"]
    dec_pct = round(100 * decisive / findings) if findings else 0
    drawn = sum(1 for _, _, s, _ in shares(games, weights) if s == 0.5)
    no_dec = sum(1 for g in games if not any(g["a"]) and not any(g["b"]))

    facts = [("extractors", n), ("case reports", len(cases)), ("games", len(games)),
             ("findings", f"{findings:,}"), ("decisive", f"{dec_pct}%")]
    facts_html = "\n".join(f"<div><dt>{esc(k)}</dt><dd>{esc(v)}</dd></div>" for k, v in facts)

    dials = []
    for i, (name, base, _) in enumerate(CATEGORIES):
        dials.append(
            f"<div class='dial'><label for='w{i}'>{esc(name)}</label>"
            f"<output for='w{i}'>{weights[i]:.1f}</output>"
            f"<input type='range' id='w{i}' min='0' max='6' step='0.1' value='{weights[i]:.1f}' "
            f"aria-label='{esc(name)} weight'><span class='base'>set to {base:.1f}</span></div>")

    map_rows = []
    grand, total_played = m["grand"], m["total_played"]
    for i, (name, base, desc) in enumerate(CATEGORIES):
        per = grand[i] / total_played if total_played else 0
        map_rows.append(
            f"<tr><td><span class='lead'>{esc(name)}</span></td><td>{base:.1f}</td>"
            f"<td style='text-align:left'>{esc(desc)}</td><td>{per:.2f}</td>"
            f"<td class='flat'>{grand[i]}</td></tr>")

    lo_e, hi_e = min(elo), max(elo)
    lead_rows = []
    for idx in order:
        width = 4 + 96 * (elo[idx] - lo_e) / (hi_e - lo_e) if hi_e > lo_e else 50
        lead_rows.append(
            f"<tr><td><span class='lead'>{esc(models[idx])}</span></td>"
            f"<td>{elo[idx]:.0f} <span class='bar' style='width:{width:.1f}px'></span></td>"
            f"<td>{band[idx][0]:.0f} to {band[idx][1]:.0f}</td>"
            f"<td><span class='flat'>0</span></td>"
            f"<td>{100*share[idx]:.1f}%</td>"
            f"<td><span class='flat'>&ndash;</span></td></tr>")

    charged, played = m["charged"], m["played"]

    disc_rows = []
    for idx in sorted(range(n), key=lambda i: models[i]):
        cells = []
        row_total = 0
        for c in range(NCAT):
            v = charged[idx][c]
            row_total += v
            per = v / played[idx] if played[idx] else 0
            cells.append(f"<td title='{v} findings over {played[idx]} matchups'>{per:.2f}</td>")
        per_tot = row_total / played[idx] if played[idx] else 0
        cells.append(f"<td title='{row_total} findings over {played[idx]} matchups'>"
                     f"<strong>{per_tot:.2f}</strong></td>")
        disc_rows.append(
            f"<tr><td><span class='lead'>{esc(models[idx])}</span></td>" + "".join(cells) +
            f"<td class='flat'>{played[idx]}</td></tr>")
    gtot = sum(grand)
    foot_cells = "".join(
        f"<td title='{grand[c]} findings over {total_played} matchups'>"
        f"{grand[c]/total_played if total_played else 0:.2f}</td>" for c in range(NCAT))
    foot_cells += (f"<td title='{gtot} findings over {total_played} matchups'>"
                   f"<strong>{gtot/total_played if total_played else 0:.2f}</strong></td>")
    foot = (f"<tr><td><span class='lead'>average extractor</span></td>{foot_cells}"
            f"<td class='flat'>{total_played//n if n else 0}</td></tr>")

    pair_rows = []
    for t in m["paired"]:
        clear = t["lo"] > 50 or t["hi"] < 50
        verdict = ("<span class='pos'>separated</span>" if clear
                   else "<span class='flat'>not separated</span>")
        w, l, d = t["record"]
        pair_rows.append(
            f"<tr><td><span class='lead'>{esc(t['base'])}</span> vs {esc(t['variant'])}</td>"
            f"<td class='flat'>{t['cases']}</td>"
            f"<td class='flat'>{t['empty']}</td>"
            f"<td class='flat'>{t['findings']:,}</td>"
            f"<td><strong>{t['observed']:.1f}%</strong></td>"
            f"<td>{t['lo']:.1f} to {t['hi']:.1f}</td>"
            f"<td class='flat'>{w}&ndash;{l}&ndash;{d}</td>"
            f"<td>{verdict}</td></tr>")
    if not pair_rows:
        pair_rows.append("<tr><td colspan='8' class='flat'>No same-model variant pairs "
                         "found in this corpus.</td></tr>")

    R = m["rounds"]
    batches = m.get("batches")
    batch_section = ""
    if batches and batches["unassisted"] and batches["assisted"]:
        u, a = batches["unassisted"], batches["assisted"]
        subj = batches["subject"]
        rows = []
        for idx in sorted(range(n), key=lambda i: -a["elo"][i]):
            mark = " <span class='pos'>&larr;</span>" if idx == subj else ""
            for slot, (label, half) in enumerate((("first %d" % u["cases"], u),
                                                  ("last %d" % a["cases"], a))):
                cells = "".join(f"<td>{half['rate'][idx][c]:.2f}</td>" for c in range(NCAT))
                first = (f"<td rowspan='2'><span class='lead'>{esc(models[idx])}</span>{mark}</td>"
                         if slot == 0 else "")
                cls = " class='band'" if slot == 0 else ""
                rows.append(
                    f"<tr{cls}>{first}<td class='flat'>{label}</td>{cells}"
                    f"<td><strong>{sum(half['rate'][idx]):.2f}</strong></td>"
                    f"<td>{half['elo'][idx]:.0f}</td></tr>")
        subject_name = esc(models[subj]) if subj is not None else "the human"
        batch_section = f"""
<section class='panel' id='batches'><h2>5. Before and after LLM-assisted annotation</h2>
<p class='lede'>The human annotated the first {u['cases']} case reports unaided and the last {a['cases']} with LLM assistance. The models ran identically on all {u['cases']+a['cases']}, so {subject_name} is the only row where the two halves differ by design.</p>
<div class='scroller'><table class='data'>
<caption>Penalised points charged against each extractor per matchup, split by error category, on the same weights as the leaderboard. Lower is better. The rating is the ordinary fit run on that half alone.</caption>
<thead><tr><th scope='col'>extractor</th><th scope='col'>half</th>{"".join(f"<th scope='col'>{esc(c[0])}</th>" for c in CATEGORIES)}<th scope='col'>total</th><th scope='col'>rating</th></tr></thead><tbody>
{chr(10).join(rows)}
</tbody></table></div>
<p class='note'>Each half is fitted and centred on its own, so ratings compare down a column, not across. A rating can rise while the penalty total also rises, which means that extractor got worse more slowly than the rest.</p>
</section>"""

    legend = "".join(f'<span><i style="background:{SWATCHES[i]}"></i>'
                     f'{esc(CATEGORIES[i][0])}</span>' for i in range(NCAT))
    schedule = ", ".join(f"{p.replace('_vs_', ' vs ')} {sum(1 for g in games if g['pairing']==p)}"
                         for p in sorted({g["pairing"] for g in games}))
    skip_note = (" Excluded by hand at build time: " + esc(", ".join(m["skipped"])) + "."
                 if m["skipped"] else "")

    payload = json.dumps({
        "models": models, "categories": CAT_KEYS, "weights": weights,
        "baseElo": elo, "baseShare": share, "baseBand": band, "baseOrder": order,
        "anchor": 1500, "seed": m["seed"], "liveRounds": m["live_rounds"],
        "games": [{"x": g["x"], "y": g["y"], "c": g["c"], "a": g["a"], "b": g["b"]}
                  for g in games],
    }, separators=(",", ":"))

    return f"""<!doctype html><html lang='en'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>GAVEL round robin</title>
<style>
{CSS}
</style>
</head><body><div class='wrap'>
<header class='masthead'>
<p class='eyebrow'>GAVEL &middot; extractor round robin</p>
<h1>Which timeline extractor is right more often</h1>
<p class='standfirst'>A frozen judge read every pair of extracted timelines against the discharge note and structured EHR evidence they came from, and ruled on each disagreement. Four sections: what an error is worth, the resulting ranking, the raw counts behind it, and a direct test of the pairs that differ in one controlled way.</p>
<dl class='facts'>
{facts_html}
</dl></header>

<section class='panel' id='weights'><h2>1. Weights</h2>
<p class='lede'>Every decisive finding is charged against one extractor and slotted into one of seven categories. A weight says what that category costs. These are our judgement, so they are yours to move, and everything in section 2 refits as you do.</p>
<div class='bench'>
<div><fieldset class='dials'>
{chr(10).join(dials)}
</fieldset>
<div class='controls'><button type='button' id='live-reset'>Reset to set weights</button><button type='button' class='ghost' id='live-flat'>All equal</button></div>
<p class='status' id='live-status'></p></div>
<div class='livebox'><h4>Rating under the current weights</h4>
<div class='scroller'><table class='data'><thead><tr><th scope='col'>extractor</th><th scope='col'>rating</th><th scope='col'>95% interval</th><th scope='col'>vs set</th><th scope='col'>mean share</th><th scope='col'>rank</th></tr></thead><tbody id='live-body'>
{chr(10).join(lead_rows)}
</tbody></table></div>
<p class='note' id='live-order'>Same order as the set weights.</p></div>
</div>
<table class='data'><thead><tr><th scope='col'>category</th><th scope='col'>set weight</th><th scope='col'>which findings map here</th><th scope='col'>per matchup, per extractor</th><th scope='col'>raw</th></tr></thead><tbody>
{chr(10).join(map_rows)}
</tbody></table>
<p class='note'>The last two columns are unweighted counts and do not move with the dials. Weights affect the rating only.</p>
</section>

<section class='panel' id='rating'><h2>2. Leaderboard</h2>
<p class='lede'>Each game is one case report judged between two extractors. The weighted points each side earns become a share of that case, and Bradley-Terry finds the strengths that best explain every share at once.</p>
<div class="derive"><dl><dt>input</dt><dd>{len(games)} games over {len(cases)} case reports, {findings:,} findings, {decisive:,} of them decisive. The schedule is uneven: {esc(schedule)}.</dd><dt>excluded</dt><dd>UNCLEAR, NEITHER and BOTH award no points ({findings-decisive:,} findings, {100-dec_pct}%). A game where that leaves both sides on zero is a 50/50 draw rather than a dropped game, since the judge read both timelines and could not separate them. At the set weights {drawn} game{"" if drawn == 1 else "s"} {"is" if drawn == 1 else "are"} drawn, {no_dec} with no decisive finding at all.{skip_note}</dd><dt>formula</dt><dd>share<sub>A</sub> = points<sub>A</sub> / (points<sub>A</sub> + points<sub>B</sub>) per game. Bradley-Terry by iterative scaling, then rating = 1500 + (400/ln10)(ln&nbsp;s &minus; mean ln&nbsp;s). Intervals are {R} resamples of the case reports; move a dial and the page refits over {m["live_rounds"]}.</dd><dt>read as</dt><dd>Only differences carry meaning; 1500 is an arbitrary centre. <strong>Two overlapping bars are not a null result.</strong> Each bar is that extractor's uncertainty against the whole field, and two of them share most of their noise. For a direct comparison of two extractors, section 4.</dd></dl></div>
<figure class='chart'>{svg_chart(models, elo, band, order)}
<figcaption>Dot is the fitted rating, bar the 95% interval from {R} resamples of the case reports. Fixed at the set weights; the table in section 1 follows the dials.</figcaption></figure>
<noscript><p class='note'>The dials in section 1 need JavaScript. The figure above is the fit at the set weights, computed in Python.</p></noscript>
</section>

<section class='panel' id='discrepancies'><h2>3. Discrepancies against, per matchup</h2>
<p class='lede'>Counts, not points, so nothing here moves with the dials. A finding lands once, against whichever extractor the judge ruled was wrong, divided by the games that extractor actually played.</p>
<div class="derive"><dl><dt>input</dt><dd>the {decisive:,} decisive findings across {len(games)} games and {len(cases)} case reports</dd><dt>formula</dt><dd>a verdict of A means B erred, so the finding counts against B. Divided by games played, which differs by extractor because the schedule is uneven.</dd><dt>precision</dt><dd>these are raw counts at 40 case reports, so small differences between cells are not meaningful. Section 4 is where a difference gets tested.</dd><dt>read as</dt><dd>one cell is errors of that kind charged in a single matchup: one extractor, one opponent, one case report. The last row also divides by extractors, so it is an average extractor rather than a sum.</dd></dl></div>
<div class='scroller'><table class='data'>
<caption>Findings charged against each extractor per matchup. Hover a figure for the raw count.</caption>
<thead><tr><th scope='col'>extractor</th>{"".join(f"<th scope='col'>{esc(c[0])}</th>" for c in CATEGORIES)}<th scope='col'>total</th><th scope='col'>games</th></tr></thead><tbody>
{chr(10).join(disc_rows)}
</tbody><tfoot>{foot}</tfoot>
</table></div>
<div class='legend'>{legend}</div>
</section>

<section class='panel' id='paired'><h2>4. Same extractor, one change</h2>
<p class='lede'>These pairs differ in exactly one way, so the comparison is controlled in a way nothing else on this page is. Both members judged the same case reports against the same note and the same structured evidence.</p>
<div class="derive"><dl><dt>why this is not section 2</dt><dd>A leaderboard interval measures one extractor against the whole field, so two of them can overlap heavily while the direct comparison between those two is decisive. This section throws away the rest of the corpus and uses only the games where these two actually met.</dd><dt>share</dt><dd>weighted points won by the first named extractor, as a percentage of points in those games, using the same weights and charging rule as the leaderboard. 50% is no difference.</dd><dt>interval</dt><dd>{R} resamples of the case reports in those games. An interval that clears 50% means this evidence separates the two; one that spans 50% means it does not.</dd><dt>empty</dt><dd>games where the judge reached no decisive verdict at all, usually because the two timelines are identical. They are scored as draws and carry no information, so an edge with many of them is weaker than its case count suggests.</dd><dt>note</dt><dd>computed at the set weights. Moving a dial refits section 2 but not this; rerun with <code>--weights</code> for a different scheme.</dd></dl></div>
<div class='scroller'><table class='data'>
<thead><tr><th scope='col'>comparison</th><th scope='col'>cases</th><th scope='col'>of those, empty</th><th scope='col'>points</th><th scope='col'>share</th><th scope='col'>95% interval</th><th scope='col'>won&ndash;lost&ndash;tied</th><th scope='col'>verdict</th></tr></thead><tbody>
{chr(10).join(pair_rows)}
</tbody></table></div>
<p class='note'>Won&ndash;lost&ndash;tied counts case reports, and excludes the empty ones, so the three numbers plus the empty column add back to the case count. A tie is a case where both sides were charged the same number of points.</p>
</section>

{batch_section}
<footer class='colophon'>
{n} extractors &middot; {len(cases)} case reports &middot; {len(games)} games &middot; {findings:,} findings, {decisive:,} decisive &middot; ratings centred at 1500 &middot; {R} resamples, {m["live_rounds"]} in the page &middot; seed {m["seed"]}
</footer>
<script>window.GAVEL={payload};</script>
</div>{JS_TAIL}"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="folder holding the <a>_vs_<b> subfolders")
    ap.add_argument("--out", default="gavel_report.html")
    ap.add_argument("--rounds", type=int, default=2000, help="bootstrap resamples")
    ap.add_argument("--live-rounds", type=int, default=400,
                    help="resamples the page runs when a dial moves")
    ap.add_argument("--seed", type=int, default=20260904)
    ap.add_argument("--annotation-batch", default=None,
                    help="file listing the case reports in the later annotation "
                         "batch, one per line. Section 5 is skipped without it.")
    ap.add_argument("--drop", default="",
                    help="comma separated pairing/case to exclude, e.g. "
                         "a_vs_b/12345678. Empty by default.")
    ap.add_argument("--weights", default="",
                    help="comma separated override for the %d starting weights" % NCAT)
    args = ap.parse_args()

    drop = set()
    for item in args.drop.split(","):
        item = item.strip()
        if "/" in item:
            p, c = item.rsplit("/", 1)
            drop.add((p, c))

    weights = [c[1] for c in CATEGORIES]
    if args.weights:
        parts = [float(x) for x in args.weights.split(",")]
        if len(parts) != NCAT:
            sys.exit(f"--weights needs {NCAT} numbers, got {len(parts)}")
        weights = parts

    jobs = discover(args.root)
    if not jobs:
        sys.exit("no <a>_vs_<b> folders with .json files under %s"
                 % os.path.abspath(args.root))

    names = []
    for _, a, b, _, _ in jobs:
        for x in (a, b):
            if x not in names:
                names.append(x)
    models = sorted(names)
    index = {m: i for i, m in enumerate(models)}

    games, findings, decisive, skipped = [], 0, 0, []
    for pairing, a_name, b_name, case_id, path in jobs:
        if (pairing, case_id) in drop:
            skipped.append(f"{pairing}/{case_id}")
            continue
        try:
            obj = json.load(open(path, encoding="utf-8"))
        except Exception as exc:
            sys.stderr.write(f"skipping unreadable {path}: {exc}\n")
            continue
        if not isinstance(obj, list):
            sys.stderr.write(f"skipping {path}: not a JSON array\n")
            continue
        a_counts, b_counts = [0] * NCAT, [0] * NCAT
        for f in obj:
            findings += 1
            if not isinstance(f, dict):
                continue
            hit = charge(f)
            if hit is None:
                continue
            cat, side = hit
            decisive += 1
            (a_counts if side == "a" else b_counts)[cat] += 1
        games.append(dict(x=index[a_name], y=index[b_name], c=case_id,
                          a=a_counts, b=b_counts, pairing=pairing))

    n = len(models)
    charged = [[0] * NCAT for _ in range(n)]
    played = [0] * n
    for g in games:
        played[g["x"]] += 1
        played[g["y"]] += 1
        for c in range(NCAT):
            charged[g["x"]][c] += g["a"][c]
            charged[g["y"]][c] += g["b"][c]
    grand = [sum(charged[i][c] for i in range(n)) for c in range(NCAT)]
    total_played = sum(played)

    pairs = shares(games, weights)
    elo = fit(pairs, n)
    share = mean_shares(pairs, n)
    order = sorted(range(n), key=lambda i: -elo[i])

    cases = sorted({g["c"] for g in games})
    rng = random.Random(args.seed)
    draws = case_resamples(cases, args.rounds, rng)
    band, per_model_draws = bootstrap_ratings(pairs, n, draws)

    batch_ids = ASSISTED_IDS
    if args.annotation_batch:
        batch_ids = load_annotation_batch(args.annotation_batch)
    assisted_ids = {g["c"] for g in games if g["c"] in batch_ids}
    unassisted_ids = {g["c"] for g in games} - assisted_ids
    batches = None
    if assisted_ids and unassisted_ids:
        batches = dict(
            subject=models.index(ASSIST_SUBJECT) if ASSIST_SUBJECT in models else None,
            unassisted=subgroup(games, unassisted_ids, weights, n, args.rounds, args.seed),
            assisted=subgroup(games, assisted_ids, weights, n, args.rounds, args.seed + 1),
        )

    paired = []
    for base, variant in variant_pairs(models):
        t = paired_test(games, models, base, variant, draws, weights)
        if t:
            paired.append(t)
    paired.sort(key=lambda t: t["p"])

    page = build_html(dict(models=models, games=games, elo=elo, band=band, share=share,
                           order=order, charged=charged, played=played, grand=grand,
                           total_played=total_played, paired=paired, batches=batches,
                           findings=findings, decisive=decisive, weights=weights,
                           rounds=args.rounds, live_rounds=args.live_rounds,
                           seed=args.seed, skipped=skipped))
    dest = os.path.join(args.root, args.out)
    with open(dest, "w", encoding="utf-8") as fh:
        fh.write(page)

    print(f"{len(games)} games, {n} extractors, {findings:,} findings, {decisive:,} decisive")
    for i in order:
        print(f"  {models[i]:10} {elo[i]:7.0f}  95% [{band[i][0]:.0f}, {band[i][1]:.0f}]"
              f"  share {100*share[i]:.1f}%")
    if paired:
        print("\n  paired comparisons:")
        for t in paired:
            mark = "separated" if (t["lo"] > 50 or t["hi"] < 50) else "not separated"
            print(f"    {t['base']} vs {t['variant']}: {t['observed']:.1f}% "
                  f"[{t['lo']:.1f}, {t['hi']:.1f}]  "
                  f"{t['record'][0]}-{t['record'][1]}-{t['record'][2]}  {mark}")
    if skipped:
        print("  excluded:", ", ".join(skipped))
    print(f"wrote {dest}")


if __name__ == "__main__":
    main()

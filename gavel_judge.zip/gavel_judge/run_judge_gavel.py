#!/usr/bin/env python3
"""Run the GAVEL judge on one prompt file via a llama.cpp server.

Adapted from Sayantan's llamacpp_temporal_qa.py. Difference: each GAVEL prompt
file is already complete (judge instructions + case report + timeline A +
timeline B in one file), so it is sent as a single user message. There is no
separate system-prompt file to load. Everything else (args, skip-done,
think-stripping, JSON-array extraction) follows the original.

n40 round robin changes:
  * --max_tokens and --ctx_size are arguments, defaulting to the LLAMA_MAX_TOKENS
    and LLAMA_CTX_SIZE environment variables. ctx_size is not sent to the server,
    which gets it from its own --ctx-size flag; it is used here only to warn
    before the call when a prompt plus the token cap will not fit.
  * --output_file, because the same case id appears in all three pairings and
    log_folder/<stem>.json collides. 36 of 40 ids are in more than one pairing,
    so the old naming judged 40 prompts and skipped 72.
  * an unparseable reply goes to <stem>.raw.txt, not <stem>.json. Writing prose
    into the .json made the skip-done check treat a failure as finished, and it
    handed the downstream loader a file that is not JSON. With .raw.txt a rerun
    of the sbatch script picks the case back up.
  * one row per prompt appended to run_log.csv: status, findings, tokens,
    seconds. Nothing else reads it; it is for tracking a 112-prompt run.
"""

import argparse
import csv
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


# Fallbacks only. run_judge_gavel.sh exports LLAMA_MAX_TOKENS and LLAMA_CTX_SIZE,
# and llm_server_utils.sh reads the same two for the server. Sized from the
# previous run: prompts reached 129,554 tokens and completions 184,267, and a
# 35,000 cap truncated 74 of 112 first attempts because reasoning tokens count
# against it.
DEFAULT_MAX_TOKENS = int(os.environ.get("LLAMA_MAX_TOKENS", 262144))
DEFAULT_CTX_SIZE = int(os.environ.get("LLAMA_CTX_SIZE", 524288))
# Rough input estimate for the pre-flight check. Measured against the previous
# run's usage figures the real ratio was 2.06 to 3.01 chars per token, so the
# worst observed value is used here to keep the warning conservative.
CHARS_PER_TOKEN = 2.06
# Judge runs greedy for reproducibility. Set the server to --temp 0 as well;
# this value is only the request-level request and the server flag governs sampling.
TEMPERATURE = 0.0
TIMEOUT_SECONDS = 6000


def read_text(path):
    try:
        return Path(path).read_text(encoding="utf-8").replace("\r\n", "\n").strip()
    except UnicodeDecodeError:
        return Path(path).read_text(encoding="unicode_escape").replace("\r\n", "\n").strip()


def chat_completions_url(endpoint):
    endpoint = endpoint.rstrip("/")
    if endpoint.endswith("/v1/chat/completions"):
        return endpoint
    if endpoint.endswith("/v1"):
        return f"{endpoint}/chat/completions"
    return f"{endpoint}/v1/chat/completions"


def build_messages(prompt_text):
    # The whole GAVEL prompt file is one user turn. No system message.
    return [{"role": "user", "content": prompt_text}]


def call_llama_server(endpoint, model_name, messages, max_tokens):
    payload = {
        "model": model_name,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": TEMPERATURE,
        "stream": False,
    }
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        chat_completions_url(endpoint),
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            response_body = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"llama.cpp server returned HTTP {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach llama.cpp server: {exc}") from exc

    data = json.loads(response_body)
    usage = data.get("usage", {}) or {}
    usage["finish_reason"] = data["choices"][0].get("finish_reason", "")
    choice = data["choices"][0]
    if "message" in choice and "content" in choice["message"]:
        return choice["message"]["content"], usage
    if "text" in choice:
        return choice["text"], usage
    raise RuntimeError(f"Unexpected llama.cpp response schema: {response_body[:500]}")


def omit_tagged_text(text, omit_tags):
    cleaned = text
    for tag in omit_tags:
        if not tag:
            continue
        pattern = re.compile(rf"<{re.escape(tag)}>\s*.*?\s*</{re.escape(tag)}>", re.DOTALL)
        cleaned = pattern.sub("", cleaned)
    return cleaned.strip()


def strip_json_fences(text):
    text = text.strip()
    if not text.startswith("```"):
        return text

    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def extract_first_json_array(text):
    text = strip_json_fences(text)
    start = text.find("[")
    if start == -1:
        return text

    depth = 0
    in_string = False
    escape = False

    for idx in range(start, len(text)):
        char = text[idx]

        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue

        if char == '"':
            in_string = True
        elif char == "[":
            depth += 1
        elif char == "]":
            depth -= 1
            if depth == 0:
                return text[start : idx + 1]

    return text


def save_json_output(output_path, model_text, omit_tags):
    """Returns (status, n_findings). A failure writes .raw.txt and leaves the
    .json absent so the next run retries the case."""
    cleaned = omit_tagged_text(model_text, omit_tags)
    json_text = extract_first_json_array(cleaned)

    try:
        parsed = json.loads(json_text)
    except json.JSONDecodeError as exc:
        raw_path = output_path.with_suffix(".raw.txt")
        print(
            f"Warning: could not parse JSON for {output_path.name}; saving raw model "
            f"text to {raw_path.name} and leaving the .json absent so a rerun "
            f"retries it. {exc}",
            file=sys.stderr,
        )
        raw_path.write_text(cleaned + "\n", encoding="utf-8")
        return "unparseable", ""

    output_path.write_text(
        json.dumps(parsed, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return "ok", (len(parsed) if isinstance(parsed, list) else "")


def append_log(log_folder, row):
    path = Path(log_folder) / "run_log.csv"
    new = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        if new:
            writer.writerow(["pairing", "output", "status", "findings",
                             "prompt_tokens", "completion_tokens",
                             "finish_reason", "seconds"])
        writer.writerow(row)


def parse_omit_tags(raw_tags):
    if not raw_tags:
        return []
    return [tag.strip() for tag in raw_tags.split(",") if tag.strip()]


def run(args):
    prompt_file = Path(args.summary_file)
    log_folder = Path(args.log_folder)
    if args.output_file:
        output_path = Path(args.output_file)
    else:
        output_path = log_folder / f"{prompt_file.stem}.json"

    log_folder.mkdir(parents=True, exist_ok=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.exists():
        print(f"Skipping {prompt_file.name}; output already exists: {output_path}")
        return

    prompt_text = read_text(prompt_file)
    messages = build_messages(prompt_text)

    if args.debug:
        print(f"Calling llama.cpp endpoint: {chat_completions_url(args.llm_endpoint)}")
        print(f"Model alias: {args.model_basename}")
        print(f"Output path: {output_path}")
        print(f"max_tokens: {args.max_tokens}  ctx_size: {args.ctx_size}")

    estimated_input = int(len(prompt_text) / CHARS_PER_TOKEN)
    if estimated_input + args.max_tokens > args.ctx_size:
        print(
            f"Warning: {prompt_file.name} is about {estimated_input} input tokens, "
            f"and {estimated_input} + max_tokens {args.max_tokens} exceeds ctx_size "
            f"{args.ctx_size}. Raise LLAMA_CTX_SIZE or lower LLAMA_MAX_TOKENS.",
            file=sys.stderr,
        )

    started = time.time()
    model_text, usage = call_llama_server(
        args.llm_endpoint, args.model_basename, messages, args.max_tokens
    )
    elapsed = time.time() - started
    status, findings = save_json_output(output_path, model_text, parse_omit_tags(args.omit_tags))
    append_log(
        log_folder,
        [output_path.parent.name, output_path.name, status, findings,
         usage.get("prompt_tokens", ""), usage.get("completion_tokens", ""),
         usage.get("finish_reason", ""), round(elapsed, 1)],
    )
    if usage.get("finish_reason") == "length":
        print(
            f"Warning: {output_path.name} stopped on the token cap, so the JSON "
            f"array is probably cut off. Raise LLAMA_MAX_TOKENS, and "
            f"LLAMA_CTX_SIZE with it if needed.",
            file=sys.stderr,
        )
    print(f"Saved output to: {output_path}  ({status}, {findings} findings, {elapsed:.0f}s)")


def get_args():
    parser = argparse.ArgumentParser(
        description="Run the GAVEL judge on one prompt file via a llama.cpp server."
    )
    parser.add_argument("--summary_file", required=True, help="Path to one GAVEL prompt .txt file.")
    parser.add_argument("--llm_endpoint", required=True, help="Base llama.cpp server URL, e.g. http://127.0.0.1:8001.")
    parser.add_argument("--model_basename", required=True, help="Model alias passed to llama.cpp server.")
    parser.add_argument("--log_folder", required=True, help="Run root. run_log.csv is written here; also the default output folder.")
    parser.add_argument("--output_file", default=None, help="Exact .json path to write. Use this when prompt stems repeat across pairings.")
    parser.add_argument("--debug", action="store_true", help="Print endpoint and output details.")
    parser.add_argument("--omit_tags", default="think", help="Comma-separated tags to remove before JSON parsing.")
    parser.add_argument("--max_tokens", type=int, default=DEFAULT_MAX_TOKENS,
                        help="Output token cap sent to the server. Default from LLAMA_MAX_TOKENS, else 262144.")
    parser.add_argument("--ctx_size", type=int, default=DEFAULT_CTX_SIZE,
                        help="Server context window, used only for the pre-flight fit warning. Default from LLAMA_CTX_SIZE, else 524288.")
    return parser.parse_args()


if __name__ == "__main__":
    run(get_args())

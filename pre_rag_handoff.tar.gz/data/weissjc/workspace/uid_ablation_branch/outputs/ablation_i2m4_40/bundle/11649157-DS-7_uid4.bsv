002e|male
0065|No Known Allergies / Adverse Drug Reactions
00d0|Cerebral angiogram for coiling ACOM aneurysm
0101|Right frontal EVD placement
0116|Cerebral angiogram for IA nitro and Verapamil to b/l A2
0197|Right frontal EVD removal
01a8|Trach placement
01e2|PEG placement
02ae|Right chest tube placement
033e|Right chest tube removal
036b|WBC-15.8 elevated
0471|Neuts-83.8 elevated
047a|Lymphs-8.9 low
04b9|PTT-23.2 elevated
04c8|Glucose-190 elevated
052c|UreaN-25 elevated
05dd|Na-132 low
06e5|K-8.5 elevated
0797|ALT-58 elevated
07c9|pO2-63 low
0868|pH-7.32 low
090b|HbA1c-5.9
09b9|cTropnT-0.02 elevated
09eb|Protein-20 elevated
0ab7|endotracheal tube tip 3.6 cm above carina
0ace|opacities at left lung base with partial obscuration of left hemidiaphragm
0be6|small left pleural effusion
0bf6|atelectasis
0c0e|aspiration
0c3b|pneumonia
0c88|mild cardiomegaly
0c9c|pulmonary vascular congestion
0e01|abnormal continuous video-EEG monitoring study
0e1d|diffuse background slowing and disorganization
0ee7|generalized rhythmic delta activity upon stimulation
0f47|moderate diffuse cerebral dysfunction/encephalopathy
0f7f|no pushbutton events
0ffb|no electrographic seizures
102f|no epileptiform discharges
10c5|enlargement of cardiac silhouette
10db|pulmonary vascular congestion
1116|opacification at left base obscuring hemidiaphragm
1135|pleural fluid
1185|volume loss in left lower lobe
11ec|superimposed aspiration/pneumonia
120c|anterior communicating artery aneurysm status post successful coil embolization
1290|interval placement of right frontal approach external ventricular drain
1297|slight increase in layering hematocrit in right posterior ventricle
1335|no significant change in subarachnoid hemorrhage
136b|left atrium mildly dilated
1396|no evidence for atrial septal defect
13c9|inferior vena cava dilated
1497|mild symmetric left ventricular hypertrophy
14ee|normal cavity size
14f9|left ventricular systolic function normal
1520|left ventricular ejection fraction >=60%
1529|left ventricular cardiac index low normal
169f|no resting left ventricular outflow tract gradient
16b9|normal left ventricular filling pressure
1819|mildly dilated right ventricular cavity
1878|mild global free wall hypokinesis
1886|TAPSE depressed
18a0|no evidence for aortic arch coarctation
18db|no aortic valve stenosis
1a8c|no aortic regurgitation
1ae8|trivial mitral regurgitation
1b3d|physiologic tricuspid regurgitation
1c2f|mild pulmonary artery systolic hypertension
1c44|no pericardial effusion
1c65|mild symmetric left ventricular hypertrophy with normal cavity size and global systolic function
1cc7|mild pulmonary artery systolic hypertension
1d20|mild right ventricular cavity dilation with free wall hypokinesis
1db9|no valvular pathology or pathologic flow identified
1dd7|extensive subarachnoid hemorrhage status post coiling of anterior communicating artery aneurysm
1dea|interval development of oligemia in left parietal lobe
1e33|left MCA infarction
1e7b|attenuation of distal left MCA branches suggestive of vasospasm
1e90|stable position of right external ventricular drain
1e9f|abnormal continuous video-EEG monitoring study
1ed8|diffuse background slowing
1ee3|generalized rhythmic delta activity
1ef3|moderate diffuse cerebral dysfunction/encephalopathy
1ef5|no pushbutton events
1f82|no electrographic seizures
2048|no epileptiform discharges
2100|improvement in degree of encephalopathy
213e|extensive subarachnoid hemorrhage status post coiling of anterior communicating artery aneurysm
21db|left MCA territorial infarction
2248|interval progression of right ACA territorial oligemia consistent with infarction
22bf|possible early left uncal herniation
22cf|possible hypoattenuation within bilateral occipital lobes
2300|evolving infarct in PCA territories bilaterally
2438|evolving hypoattenuation in left more than right cerebellar hemisphere
24b5|developing infarction
2500|stable position of right external ventricular drain
259e|no evidence of deep venous thrombosis in right or left lower extremity veins
26c2|visualization of right peroneal veins was limited
26c8|diffuse subarachnoid hemorrhage
26f1|evolving left MCA infarct
2701|right greater than left ACA infarct
2747|left cerebellar hemisphere infarct
291e|mild hypoattenuation of both occipital lobes
291f|infarcts
2930|similar extent sulcal effacement and possible early right uncal herniation
294a|at least moderate vasospasm of proximal anterior cerebral arteries more severe on right
2a67|mild vasospasm of left M2 segments
2ab1|mild vasospasm of proximal bilateral posterior cerebral arteries is new
2ad0|diffuse subarachnoid hemorrhage
2b10|evolving left MCA infarct
2b22|right greater than left ACA infarct
2b60|left cerebellar hemisphere infarct
2bea|unchanged minimal leftward midline shift anteriorly with small subfalcine herniation
2c44|effacement of suprasellar cisterns
2c4e|crowding of bilateral perimesencephalic cistern
2c8f|mass effect along bilateral cerebral peduncles
2d58|interval minimal change of previously identified vasospasm involving intracranial vasculature
2de5|treatment of anterior communicating artery aneurysm
2e09|severe bilateral A2 vasospasm improved following injection of verapamil and nitroglycerin
2e3f|abnormal continuous video-EEG monitoring study
2fa0|diffuse background slowing and disorganization
2fd0|moderate to severe encephalopathy
310b|reactivity seen in background with stimulation
3122|one pushbutton event for unclear reasons without evidence of electrographic seizure
31f6|no focal abnormalities
3252|no epileptiform discharges
332b|no electrographic seizures
3407|no significant change
342b|no thrombus/mass seen in body of left atrium
34d1|no evidence for atrial septal defect
353d|normal cavity size
3554|left ventricular systolic function normal
359c|left ventricular ejection fraction >=65%
35a7|mildly dilated right ventricular cavity
360a|TAPSE normal
3649|no aortic valve stenosis
367e|no aortic regurgitation
36a3|estimated pulmonary artery systolic pressure is high normal
3746|normal left ventricular wall thickness, cavity size and regional/global biventricular systolic function
378c|no valvular pathology or pathologic flow identified
37e2|right ventricular cavity dilation
37f1|high normal pulmonary artery systolic pressure
3820|antibiotic prophylaxis NOT recommended
389d|abnormal continuous video-EEG monitoring study
38ad|diffuse background slowing and disorganization
38e9|moderate to severe encephalopathy
3989|reactivity seen in background with stimulation
3a74|no pushbutton events
3b00|no focal abnormalities
3b47|no epileptiform discharges
3c0c|no electrographic seizures
3c4f|no significant change
3cb9|evolving diffuse subarachnoid hemorrhage with no significant interval change in vasospasm involving bilateral ACA, MCA and left PCA
3cc1|no new hemorrhage or infarction identified
3ccf|evolution of large left MCA territory infarction
3d1d|right ACA territory infarction
3de8|small left ACA territory infarction
3e1b|stable edema with effacement of left hemispheric sulci and left lateral ventricle
3e3d|stable position of right frontal extraventricular drain and anterior communicating artery aneurysm embolization coil
3e4e|patent circle of Willis without evidence of occlusion or additional aneurysm
402f|mild paranasal sinus disease
405f|partially visualized endotracheal and enteric tube
40f4|interval improvement in vasospasm involving middle cerebral and left posterior cerebral arteries
4116|persistent vasospasm of anterior cerebral arteries bilaterally
4162|redemonstration of evolving diffuse subarachnoid hemorrhage
4219|evolution of large left MCA territory infarction
43e4|right ACA territory infarction
4445|small left ACA territory infarction
44c3|improving edema with improved effacement of left lateral ventricle and sulci of left cerebral convexity
44f9|stable position of right frontal external ventricular drain and anterior communicating artery aneurysm coiling
4568|paranasal sinus disease
458c|fluid partially opacifying mastoid air cells bilaterally
45c7|partially visualized endotracheal and enteric tube
45f2|redemonstration of evolving subarachnoid hemorrhage and infarctions of left MCA, right ACA and left ACA territories
4697|improving edema with improved effacement of left lateral ventricle and sulci of left cerebral convexity
46f1|no new infarctions or hemorrhage
46f3|stable position of right frontal external ventricular drain and anterior communicating artery aneurysm coils
470a|paranasal sinus disease
4724|redemonstration of fluid partially opacifying mastoid air cells bilaterally
472e|no evidence of deep venous thrombosis in right or left lower extremity veins
4742|small right pneumothorax
483c|bilateral dependent upper and lower lobe pulmonary consolidations concerning for aspiration pneumonia superimposed upon atelectasis
4853|small associated pleural effusions
491a|no focal source of infection in abdomen or pelvis
4929|no drainable fluid collection
4965|small amount of free gas within urinary bladder
4a0d|mild muscular edema and overlying subcutaneous fat stranding in upper left lateral abdominal wall
4a11|contusions
4a95|no discrete fluid collection
4ac2|gallstones
4c2c|small right pneumothorax
4e2e|bilateral dependent upper and lower lobe pulmonary consolidations concerning for aspiration pneumonia superimposed upon atelectasis
4e38|small associated pleural effusions
4ec6|no focal source of infection in abdomen or pelvis
4f3e|no drainable fluid collection
4f6b|small amount of free gas within urinary bladder
4ff7|mild muscular edema and overlying subcutaneous fat stranding in upper left lateral abdominal wall
5203|contusions
5218|no discrete fluid collection
523d|gallstones
52ad|evolution of left MCA and right ACA territory infarcts both demonstrating hemorrhagic transformation
5345|4.8 cm intraparenchymal hematoma in location of right ACA territory infarct increased in size
534f|linear intrinsic T1 hyperintensity along cortex of left posterior frontal, parietal and superior aspect of left temporal lobes
53fc|cortical laminar necrosis
543f|stable extensive subarachnoid hemorrhage within sulci adjacent to falx bilaterally and in right occipital lobe sulci
5456|stable interventricular hemorrhage
5462|linear susceptibility in keeping with blood products along tract of previously sited right external ventricular drain
5481|moderate paranasal sinus mucosal thickening
5572|interval removal of right frontal approach ventriculostomy catheter
5589|evolution of right ACA territory and left MCA territory infarcts both demonstrating hemorrhagic transformation
55a7|multifocal small volume subarachnoid hemorrhage appears decreased from previous head CT
5622|no new acute large territory infarction
5646|negative HSV1 and HSV2
5675|multiple pulmonary emboli
5751|occlusive embolus left upper lobe probably new
57ea|largest occluding right descending pulmonary artery distal to middle lobe artery takeoff probably present on ___
582f|slowly resolving large pulmonary infarction lingula
590c|multifocal pneumonia new in right middle lobe increasing right lower lobe
595b|mild pulmonary edema
5a9f|no acute inflammatory changes in abdomen or pelvis
5ace|cholelithiasis without evidence of acute cholecystitis
5af6|pulmonary embolism
5af8|limited study
5b13|grossly stable left MCA and right ACA territory evolving hemorrhagic infarctions
5b3d|no definite evidence of new large vascular territory infarction, acute intracranial hemorrhage, or midline shift
5b7a|grossly stable multifocal subarachnoid hemorrhage
5c09|nonocclusive thrombus in left basilic vein
5c25|no deep vein thrombosis demonstrated in bilateral upper extremities
5c28|No evidence of deep venous thrombosis in the visualized right or left lower extremity veins
5c47|left atrial volume index is normal
5cca|normal left ventricular wall thickness
5d69|normal cavity size
5e0b|suboptimal image quality to assess regional left ventricular function
5e60|left ventricular systolic function is normal
5e6e|biplane left ventricular ejection fraction is 64%
5e78|no resting left ventricular outflow tract gradient
5ed2|Mildly dilated right ventricular cavity
5f4f|mild global free wall hypokinesis
5f66|aortic sinus diameter is normal for gender
5f6b|normal ascending aorta diameter for gender
5f72|aortic arch diameter is normal
5fb0|normal descending aorta diameter
6034|aortic valve leaflets (3) appear structurally normal
6058|no aortic valve stenosis
60aa|no aortic regurgitation
60da|mitral valve leaflets appear structurally normal
60f8|no mitral valve prolapse
61af|mild [1+] mitral regurgitation
628a|pulmonic valve leaflets are normal
62c0|tricuspid valve leaflets appear structurally normal
62fb|mild [1+] tricuspid regurgitation
6304|estimated pulmonary artery systolic pressure is borderline elevated
632d|no pericardial effusion
6379|Poor image quality
63de|Mildly dilated, hypokinetic right ventricle
64c6|no obvious change
64c8|study is limited by bandages along the midline of the abdomen
64f6|Patent hepatic vasculature
6537|Echogenic liver consistent with steatosis
6552|Cholelithiasis
65f9|Small right pleural effusion
65fa|Consolidations in the bilateral lower lobes and right middle lobe appear more confluent compared to CT of the chest
6632|compatible with evolving pneumonia
67cd|No new consolidation
67e0|Small bilateral pleural effusions, right greater than left, slightly increased from prior
68e8|Known bilateral pulmonary emboli are not assessed in the absence of intravenous contrast
699d|POLYMORPHONUCLEAR LEUKOCYTES on Mini-BAL Gram stain
69f0|NO MICROORGANISMS SEEN on Mini-BAL Gram stain
6ac0|NO GROWTH on Mini-BAL respiratory culture
6af2|NO POLYMORPHONUCLEAR LEUKOCYTES SEEN on CSF Gram stain
6b32|NO MICROORGANISMS SEEN on CSF Gram stain
6b93|NO GROWTH on CSF fluid culture
6b95|greater than 25 PMNs on sputum Gram stain
6ca5|less than 10 epithelial cells per 100X field on sputum Gram stain
6d47|GRAM NEGATIVE RODS on sputum Gram stain
6dc6|SPARSE GROWTH Commensal Respiratory Flora on sputum culture
6e96|No MRSA isolated on nasal swab
6eeb|POLYMORPHONUCLEAR LEUKOCYTES on BAL Gram stain
6fbc|NO MICROORGANISMS SEEN on BAL Gram stain
6fc9|NO GROWTH on BAL respiratory culture
6fe0|greater than 25 PMNs on endotracheal sputum Gram stain
709f|less than 10 epithelial cells per 100X field on endotracheal sputum Gram stain
7139|NO MICROORGANISMS SEEN on endotracheal sputum Gram stain
7192|SPARSE GROWTH Commensal Respiratory Flora on endotracheal sputum culture
71d9|2+ POLYMORPHONUCLEAR LEUKOCYTES on CSF Gram stain
7251|NO MICROORGANISMS SEEN on CSF Gram stain
72ce|NO GROWTH on CSF fluid culture
72db|POLYMORPHONUCLEAR LEUKOCYTES on Mini-BAL Gram stain
72f4|NO MICROORGANISMS SEEN on Mini-BAL Gram stain
730a|3000 CFU/mL Commensal Respiratory Flora on Mini-BAL culture
731f|NO POLYMORPHONUCLEAR LEUKOCYTES SEEN on CSF Gram stain
7418|NO MICROORGANISMS SEEN on CSF Gram stain
742c|NO GROWTH on CSF fluid culture
7491|extensive contamination with upper respiratory secretions on sputum Gram stain
7517|Test cancelled by laboratory
7525|2+ POLYMORPHONUCLEAR LEUKOCYTES on Mini-BAL Gram stain
7537|NO MICROORGANISMS SEEN on Mini-BAL Gram stain
755f|NO GROWTH on Mini-BAL respiratory culture
7688|No MRSA isolated on nasal swab
7698|NO FUNGUS ISOLATED on nasal swab fungal culture
76da|NO OVA AND PARASITES SEEN on stool exam
7748|NO VIBRIO FOUND on stool culture
7786|NO YERSINIA FOUND on stool culture
7838|No E. coli O157:H7 found on stool culture
787b|No MRSA isolated on nasal swab
788e|CRYPTOCOCCAL ANTIGEN NOT DETECTED in CSF
7895|No MRSA isolated on nasal swab
78ca|No Enterovirus isolated in CSF
79ab|extensive contamination with upper respiratory secretions on expectorated sputum Gram stain
7a67|TEST CANCELLED on expectorated sputum culture
7aee|Urinalysis had insufficient pyuria
7afc|No growth to date on blood culture
7b37|No growth to date on PICC line blood culture
7b40|WBC 11.6
7b87|RBC 3.45
7ba5|Hgb 9.6
7c61|Hct 32.1
7c6e|MCV 93
7c8e|MCH 27.8
7c98|MCHC 29.9
7d54|RDW 13.4
7d59|RDWSD 45.3
7e46|PTT 35.9
7e52|Glucose 136
7e61|UreaN 23
7ebf|Creat 0.5
7ee7|Na 139
7eea|K 4.7
7eff|Cl 98
7f77|HCO3 28
7f97|AnGap 13
7fb4|ALT 50
7fd8|AST 19
801d|AlkPhos 104
801e|TotBili 0.3
80d0|Mg 1.
821c|year old
8266|male
827b|HTN
832a|DLD
835b|T2DM
8388|hypotension
838d|transferred from OSH
83c1|SAH
8447|4mm ACOM aneurysm
84c3|admitted to the Neuro ICU
8552|ACOM coiling
8564|EVD placement
85b2|EVD removal
85ee|neurogenic fevers
86ab|multiple episodes of HAP/VAP
86ca|treated with broad spectrum abxs
86ff|severe vasospasms
874f|multiple CVAs
87b5|bilateral MCA
8853|R ACA
8ae5|hemorrhagic conversion
8bec|monitored in the neuro ICU
8d3f|transferred to the medicine floor
8d6b|ongoing fevers
8e12|found to have a bilateral PE
8e32|started on IV heparin
8e46|transitioned to oral agents
8e93|hemoptysis with loading dose of apixaban
8eb0|discharged with therapeutic lovenox
8f0b|transition to maintenance apixaban
8f59|discharged to a long term care facility
8f7a|will switch from Enoxaparin 110 mg SC Q12H for 2 week course to Apixaban 5 mg PO/NG BID
8f8a|start apixaban 5mg BID
8f8f|Systolic blood pressure must strictly remain under 160 mmHg
8ffc|continue to uptitrate home valsartan
902e|monitor vitals more closely
903c|repeat CBC/BMP/LFTs in 1 week
9063|Discharged on lantus and SSI for glycemic control
90b2|titrate insulin outpatient
90d8|seen for follow up by his PCP
910f|vascular medicine follow up
9131|neurology follow up
918e|neurosurgery follow up
9228|Consider fibroscan to further evaluate steatosis
9268|Consider fibroscan to further evaluate cholelithiasis
9282|history of carotid stenosis
92bd|previously on ASA
9314|previously on Plavix
932d|determine need to restart antiplatelet therapy
9382|discharged on systemic anticoagulation
93c0|Multiple CVAs
93ce|Ongoing impaired neurologic function with trach/peg dependency
93f6|Diffuse SAH noted at OSH CTA
9428|ACOM coiling
9447|EVD placement
9464|drain removal
949a|NCHCT demonstrated improvement in size of the SAH
9590|CTA showed R ACA and L MCA territory infarcts from severe vasospasm
95cb|hemorrhagic conversion noted during this hospitalization
967d|stable/improved on repeat head CT
968a|Trach/PEG were placed
98c0|blood pressure was maintained below systolic 160 mmHg
98f9|neuro status was monitored
99ae|alert
9a72|answer simple questions by mouthing yes/no or shaking his head
9b2a|upper strength was still ___
9b49|lower strength was still ___
9b74|occasional tremors
9b84|areflexic on the R side
9bc5|1+ L brachorad
9be6|0 biceps
9c25|1+ patellar
9d38|ex-wife and legal guardian
9dd3|discussed over the phone
9e14|never discussed code status specifically
9e92|not want to keep living if he remained completely dependent on others without being able to do things for himself
9ed3|did not think so
9ef5|chance of some neurologic recovery
9f8e|gone ahead with trach/peg tube placements
9fac|continuing all medical care
a068|Family meeting was held again
a06d|optimistic about his recovery
a085|full code
a0df|Tracheostomy
a104|Secretions
a117|Pulmonary edema, resolved
a17a|VAP
a1ed|intubated at OSH for AMS
a23a|ventilator dependent
a275|difficult to wean
a2ef|new bilateral pleural effusions
a317|pulmonary edema on serial CXRs
a33e|actively diuresed
a3aa|chest tube placed
a47f|chest tube removed
a505|tracheostomy
a531|more tachypneic
a585|copious secretions
a5be|decreased lung volumes
a5e8|worsening consolidation on L side
a6f8|concerning for possible aspiration event
a792|consolidations more confluent, c/w evolving pneumonia
a833|increased pleural effusions
a865|actively diuresed again
a8ad|treated with a 7 day course of cefepime for VAP
a8d3|maintained on albuterol nebulizers q4H
a8d5|acetylcysteine nebulizers q4H
a8fb|suctioned as needed
a910|Found iso ongoing fevers of unknown origin
a96a|CTA showed b/l PE
aa04|trop 0.02
aa3c|TTE showing mild RH strain
ab1d|Provoked iso prolonged hospitalization and surgical interventions
ab8e|Upper and lower extremity dopplers were negative for DVT
ab9f|started on IV heparin
acbe|on IV heparin
acff|repeat NCHCT done once therapeutic
ad14|stable multifocal SAH
ad3a|L MCA/R ACA infarcts
ad4c|switched to apixaban
adc9|received loading dose
aea9|new hemoptysis
aeb2|high dose aspirin was held
af5f|MASCOT was consulted
afbf|recommended loading with lovenox for 2 weeks instead before continuing him on maintenance apixaban 5mg BID
b016|noted to have leukocytosis
b14f|fever starting on ___
b171|started on vancomycin
b2b2|started on cefepime
b322|treated with several courses of antibiotics between ___ and ___ including vancomycin, cefepime, meropenem, flagyl for ongoing fevers
b337|intermittent rigoring
b39a|intermittent fevers
b409|ICP elevation
b40e|treated with buspirone
b465|treated with bromocriptine
b546|fevers persisted
b633|transferred to the medicine floor for work up of fevers of unknown origin
b7a0|extensive infectious work up
b840|treated for VAP as above as well as for a bilateral PE
b8a6|leukocytosis that stably fluctuated around WBC ___
b8c0|Uptitrated valsartan to 160mg QD for goal SBP<160
b936|held home amlodipine
b98c|held home spironolactone
ba56|PEG placed ___ for ongoing AMS
bab6|Nutrition was consulted
bbdb|started on tube feeds
bc18|free water flushes were increased as needed when he was felt to be intravascularly dry
bc26|uptrending ALT/AST during the hospitalization
bd01|RUQUS with patent portal vasculature
bd12|steatosis
be7f|cholelithiasis
bef8|brief hypotensive episode played a role in his transaminitis
bf2b|no med changes made to explain the initial rise
c038|LFTs were monitored and stably downtrended
c052|work-up included TTE which was unremarkable
c05f|negative trop
c07a|TSH was 0.8
c123|Did not require rate control
c142|anticoagulated as above
c164|Flexiseal initially placed
c1c4|Flexiseal discontinued ___
c1e4|All stool studies negative
c275|Received fiber packets TID
c2fe|Occasionally became constipated and bowel regimen was titrated as necessary
c319|Received prednisone burst (___) for presumed COPD exacerbation
c4ba|received nebulizers as above
c586|Initially on high dose Aspirin d/c as above after AG initiation
c591|Held home Plavix
c5ad|Restarted ASA 81mg at discharge
c5de|Held tramadol indefinitely given seizure history
c5fb|Continued home citalopram
c687|Continued home allopurinol
c6ff|Held home metformin
c750|continued on ISS and daily lantus
c7a8|Continued home simvastatin
c828|continued home LT4 50mcg qdaily
c922|Held home protonix
c943|switched to lansoprazole for TFs
caa7|full code confirmed
cac1|Allopurinol ___ mg PO DAILY
cae5|Citalopram 10 mg PO DAILY
cb1f|MetFORMIN (Glucophage) 500 mg PO BID
cb43|Simvastatin 40 mg PO QPM
cbc4|Clopidogrel 75 mg PO DAILY
cbc8|Aspirin 81 mg PO DAILY
cda5|Levothyroxine Sodium 50 mcg PO DAILY
cea6|Pantoprazole 40 mg PO Q24H
ceb1|olmesartan 40 mg oral DAILY
cef9|TraMADol 50 mg PO Q6H:PRN Pain - Moderate
cfd9|Centrum Silver (multivitamins-min-FA-lycopen-lutein;mv-min-folic acid-lutein) 0.4-300-250 mg-mcg-mcg oral DAILY
cfed|amLODIPine 10 mg PO DAILY
d008|Spironolactone 12.5 mg PO DAILY
d019|Valsartan 320 mg PO DAILY
d063|Viagra (sildenafil) 100 mg oral DAILY:PRN ED
d080|Mildronate 500mg DAILY
d114|Aspirin 81 mg PO DAILY
d199|Bisacodyl ___AILY:PRN Constipation - Second Line
d1e0|Enoxaparin (Treatment) 110 mg SC Q12H Duration: 2 Weeks stop after ___, start apixaban on ___ instead
d201|Glargine 22 Units BedtimeInsulin SC Sliding Scale using REG Insulin
d342|Lansoprazole Oral Disintegrating Tab 30 mg PO DAILY
d3e7|Multivitamins W/minerals 15 mL PO DAILY
d42d|Polyethylene Glycol 17 g PO DAILY:PRN Constipation - Third Line
d4e9|Senna 8.6 mg PO BID:PRN Constipation - First Line
d5a4|Valsartan 160 mg PO DAILY
d617|Allopurinol ___ mg PO DAILY
d68f|Citalopram 10 mg PO DAILY
d6da|Levothyroxine Sodium 50 mcg PO DAILY
d6e9|MetFORMIN (Glucophage) 500 mg PO BID
d7d3|Simvastatin 40 mg PO QPM
d855|Subarachnoid hemorrhage anterior communicating artery aneurysm
d881|Bilateral middle cerebral artery and anterior cerebral artery infarcts with hemorrhagic conversion
d8b1|pulmonary embolism
d8b5|ventilator associated pneumonia
d8be|respiratory failure
d919|Confused - sometimes
da59|Alert and interactive
daa4|Bedbound
daec|cerebral angiogram to coil the aneurysm
dafe|external ventricular drain placed
db09|external ventricular drain removed
db4d|seizure while admitted
db51|completed a one week course of Keppra
db55|completed a three week course of Nimodipine
db6f|cleared to resume Aspirin
db94|suffered multiple strokes
dbad|suffered seizures
dc41|underwent multiple procedures with neurosurgery to treat your strokes
dc5a|placed a breathing tube to help you breathe
dc7f|feeding tube in your abdomen for food and medications
dca8|treated you with antibiotics for infections you had including pneumonia
dd36|treated you with blood thinners for blood clots you suffered in your lungs

002b|No Known Allergies / Adverse Drug Reactions
01ab|None
047c|___ year old
071c|female
0810|history of cerebral palsy
0813|mental retardation
08c4|non verbal at baseline
0923|fell down some stairs
09ac|striking the back of her head
0abb|brought to an outside hospital
0d7f|received Zofran
0ddd|received 1 gram fosphenytoin
0de0|received Reglan
0e07|Head CT was performed
0f41|skull fracture
0f78|temporal contusions
10a1|transferred to this hospital
10e1|presents to the ED
112b|no one to relay the events of the fall
11b8|brother was called at home
1212|non verbal with minimal eye contact
136e|minimal interaction with strangers
1450|uses gestures at times to communicate
14c1|lives in a town house with three other residents with 24 hour supervision
1707|attends a day school
18d0|ambulates around her home independently
18f8|cerebral palsy
1b60|mental retardation
1c7c|temperature 98.7
1d82|blood pressure 144/82
1f33|heart rate 84
20cf|respiratory rate 16
219f|oxygen saturation 100%
21c1|flicker eye opening to noxious
21d0|GCS 8
24c7|Laceration occiput
25fb|No raccoon sign
277e|No Battle Sign
291a|No otorrhea
2a7a|No tympanum abnormality
2bb4|pt unable to perform
2c4d|hard cervical collar
2cea|Warm and well-perfused
2d00|no commands
314f|non verbal
32f2|no eye opening
34c6|baseline MR and cerebral palsy with inability to communicate
35ff|patient is non verbal
3630|Pupils equally round and reactive to light, 4.5 to 3mm bilaterally
36f2|patient is unable to cooperate with exam
3882|patient does not cooperate with exam
38ef|Normal bulk and tone bilaterally
38f7|No abnormal movements
3c8f|no tremors
3e0a|Bilateral upper extremities spontaneous movement
3e5b|bilateral lower extremities bends knees spontaneously
3e5e|NO Commands
3f18|pt does not cooperate with exam
41c7|pt does not cooperate with exam
4200|downgoing bilaterally
44b0|pt does not cooperate
44f1|Eyes open to voice
4524|Will follow commands intermittently
4615|Moves all ext with good strength
477f|Left frontal and right parietal subarachnoid hemorrhage - small and stable
481e|small left subdural hematoma
48c7|Contusions left frontal lobe/left temporal lobe with surrounding edema
491f|Midline shift 3mm to the right - unchanged
494e|Non-displaced fracture involving the greater wing of the sphenoid on the right extending posteriorly into the right parietal bone
4ad2|RBC
4cbe|Hgb 12.5 low
4d42|Hct 36.8
4d69|Plt Ct 231
4f10|PT 12.1
4fd2|PTT 20.7 abnormal
5023|INR 1.0
5042|Glucose 160 high
50a1|UreaN 12
517a|Creat 0.7
542e|Na 137
557c|K 3.8
5653|Cl 102
5751|HCO3 20 low
59c6|AnGap 19
5a9c|No acute fracture or dislocation
5b99|linear radiopaque structure measuring approximately 6 mm projecting over the soft tissue superior to the right greater trochanter
5c48|No significant interval change in multicompartmental hemorrhage
5c74|no evidence of expansion of the small right frontoparietal epidural hematoma
5d65|single view does not show the linear opacification suggested on the previous study
5d79|prior finding presumably represented an artifact
5ded|No evidence of ligamentous injury
5f20|Normal alignment
6010|Global spinal canal narrowing from C3 through C6 due to congenitally short pedicles
6032|degenerative disease most notable at C3-C4 and C4-C5
6203|moderate spinal canal narrowing with spinal cord deformity
6272|spinal cord signal remains normal
6520|Moderate neural foraminal narrowing at several levels
6535|Non displaced R clavicular fracture
65a6|admitted to neurosurgery into the ICU
6824|repeat CT head on ___
6a01|evolution of SDH with slight increase in edema
6a32|repeat CT head was performed on ___
6ab0|stable evolution of left frontal and temporal contusions
6b87|developed episodes of questionable simple partial seizures of her right face
6c06|therapeutic dilantin level
6db3|keppra was initiated
6ed6|Neuromed was consulted
710b|24 hour EEG
7146|hold keppra
7149|require a cervical hard collar during her admission
7162|cervical MRI was ordered
71f0|cancelled due to foreign body in the right hip
74a1|repeat pelvis xray demonstrated no hardware only artifact
74c7|cleared for MRI imaging of the cervical spine
74e0|did not demonstrate ligamentous injury
7600|demonstrate some congenital anatomical variants which were insignificant
7670|collar was removed
7740|tolerating a soft/ground diet
778a|more alert in the afternoon
77ad|transferred to the floor
7922|one episode of self-limiting epistaxis
7b38|doing well with her altered diet
7bc4|clavicle imaging with no further displacement
7caa|Orthopedics was called
7e16|sling as needed for comfort
7fac|follow up with orthopedics in one week
8011|required rehab
8052|Dilantin was discontinued
80fa|EEG showed no active seizure activity
82aa|remain on Keppra 1000mg BID for treatment of her seizures while in the hospital
82bb|Desogen 1 tab po qd
82f4|Levoxyl 50 mcg 1 tab po qd
8327|lexapro 10 mg 1 tab po qd
835d|multivitamin
87b2|MiraLax
8920|acetaminophen 325 mg Tablet PO Q6H as needed for pain headache
89dd|senna 8.6 mg Tablet PO BID
8bd7|docusate sodium 100 mg Capsule PO BID
8cc2|heparin (porcine) 5,000 unit/mL Solution Injection TID
8d84|escitalopram 10 mg Tablet PO DAILY
8e58|multivitamin Tablet PO DAILY
8f4e|levetiracetam 500 mg Tablet PO BID
9052|famotidine 20 mg Tablet PO BID
9079|levothyroxine 25 mcg Tablet PO DAILY
9157|acetaminophen-codeine 300-30 mg Tablet PO Q4H as needed for headache/pain
9170|Seizure
9255|Cerebral Palsy
925c|Mental Retardation
9273|Aphasia
92bf|Skull Fracture / non displaced
9415|Subdural hematoma
9437|Intraparenchymal hemorrhage
9478|Subarachnoid hemorrhage
9595|subgaleal hematoma
9783|tachycardia
9859|hypertension
986f|Right clavicle fracture
9a7f|Confused - always
9d4d|Lethargic but arousable
9e0d|Ambulatory - requires assistance or aid (walker or cane)
9e7e|discharged on Keppra (Levetiracetam) for 3 months to prevent seizures

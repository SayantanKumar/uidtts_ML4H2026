0050|female
006b|no known allergies
009e|no adverse drug reactions
00c2|femur fracture
00cf|L distal femur procedure
00ea|cardiac resuscitation
0234|cardiac arrest
03d4|woman
0416|CAD
04ca|CHF
0521|depression with psychosis
0558|presented from assisted living facility
0591|left leg pain
06d5|normal state of health
0863|left knee pain
08a4|fell
09d0|unwitnessed fall
09d8|knee pain
0b48|sent to outside hospital for evaluation
0cad|XRay performed
0d11|closed fracture of the femur
0d17|basic labs sent
0d33|baseline anemia
0e0a|transferred to tertiary center
0e88|T 99.5
0ef5|P 74
102e|BP 108/52
105f|R 18
10f3|O2 92% on RA
10f5|hip XRay in ED
112f|unremarkable hip XRay
11a4|Ortho consulted
1236|go to OR tomorrow
1242|EKG performed
1290|LBBB
12d8|given one dose of Morphine
134c|hypoxia
141d|anemia
1509|admitted to medicine
15c4|T 99.0
1634|P 67
1668|BP 120/53
16a3|R 21
16be|O2 98% on 2L
16e5|AAOx1
17c6|unable to give history
1826|left knee pain
1832|denies chest pain
19cc|denies shortness of breath
1a58|denies abdominal pain
1a8b|does not want pain medications
1a94|denies fever
1c49|denies headache
1c7b|denies cough
1d0e|denies shortness of breath
1d8f|denied chest pain
1f50|denied chest tightness
1f6d|denied palpitations
1f78|denied nausea
1fcf|denied vomiting
203e|denied diarrhea
208b|denied constipation
20f9|denied abdominal pain
2122|anemia
21ff|depression with psychosis
22c6|back pain
235c|osteoarthritis
2375|schizoaffective disorder
23a5|CAD
24fa|CHF
2504|T 98.9
252e|BP 114/85
27f4|P 84
282c|R 12
2882|O2 99% on 2L
28b2|AAO x 1
28cb|NAD
2981|sclera anicteric
29f3|dry mucous membranes
2aee|poor dentition
2bc0|oropharynx clear
2bfc|supple neck
2d75|JVP not elevated
2edb|no LAD
2f29|clear to auscultation bilaterally
2f67|no wheezes
2f95|no rales
301c|no ronchi
3097|regular rate and rhythm
316b|normal S1 + S2
3174|no murmurs
320a|no rubs
3384|no gallops
3398|soft abdomen
3552|non-tender abdomen
3614|non-distended abdomen
3746|bowel sounds present
376b|no rebound tenderness
395e|no guarding
3a12|no organomegaly
3a4e|erythema in left knee
3ae0|effusion in left knee
3b07|2+ bounding DP pulses bilaterally
3b86|___ pulses bilaterally
3b97|no edema
3bd6|oriented x1
3bdb|unable to cooperate with neuro exam
3c02|GLUCOSE-152 elevated
3d47|UREA N-23 elevated
3f71|CREAT-0.9
4132|SODIUM-142
4176|POTASSIUM-3.6
4204|CHLORIDE-109 elevated
431f|TOTAL CO2-26
4362|ANION GAP-11
443e|ALT-182 elevated
44ac|AST-192 elevated
450f|LDH-473 elevated
45c1|CK-328 elevated
4666|ALK PHOS-72
46fc|TOT BILI-0.7
4739|CK-MB-6
4796|cTropnT-0.05 elevated
47ba|CALCIUM-8.4
488f|PHOSPHATE-2.7
4993|MAGNESIUM-1.6
49a1|WBC-7.6
49ac|RBC-3.05 low
4a93|HGB-9.0 low
4aa7|HCT-26.1 low
4b96|MCV-86
4bb3|MCH-29.3
4c19|MCHC-34.3
4cfb|RDW-13.9
4d1b|PLT COUNT-148 low
4e36|PTT-22.8
4f7c|WBC-7.4
501d|RBC-2.80 low
50f9|HGB-8.2 low
510a|HCT-24.4 low
510d|MCV-87
5114|MCH-29.4
511b|MCHC-33.7
51a4|RDW-14.4
52f8|PLT COUNT-144 low
53ef|PTT-29.6
548c|arterial blood gas
54fc|RATES-/12
55e7|O2-100
562d|O2 FLOW-12
5637|PO2-370 elevated
57f9|PCO2-48 elevated
5865|PH-7.28 low
5906|TOTAL CO2-24
5918|BASE XS--4
5a22|AADO2-319
5a90|REQ O2-57
5ac3|intubated
5ad8|vent controlled
5b80|ETT tube
5bb8|GLUCOSE-169 elevated
5c20|LACTATE-2.4 elevated
5cc7|NA+-141
5cf6|K+-3.2 low
5d43|CL--112
5d92|HGB-8.1 low
5dee|calcHCT-24
5e1d|O2 SAT-98
5e1f|CARBOXYHB-2
6022|MET HGB-0
60a0|freeCa-1.08 low
6113|GLUCOSE-129 elevated
61ca|UREA N-30 elevated
61f4|CREAT-0.9
631a|SODIUM-143
6350|POTASSIUM-3.7
6380|CHLORIDE-110 elevated
6407|TOTAL CO2-27
640b|ANION GAP-10
642f|CK-MB-3
64f8|CALCIUM-8.9
652a|PHOSPHATE-2.7
6550|MAGNESIUM-1.9
6565|WBC-6.7
65c4|RBC-2.87 low
65d5|HGB-8.2 low
661a|HCT-24.5 low
6681|MCV-85
6840|MCH-28.5
68a7|MCHC-33.5
68df|RDW-14.3
68e2|PTT-25.5
6956|PLT COUNT-177
69de|urine COLOR-Yellow
6a60|urine APPEAR-Clear
6af3|urine SP
6b98|urine BLOOD-NEG
6d37|urine NITRITE-NEG
6f69|urine PROTEIN-25
6f8b|urine GLUCOSE-NEG
7091|urine KETONE-NEG
7107|urine BILIRUBIN-NEG
7285|urine UROBILNGN-NEG
72e2|urine PH-5.0
72fa|urine LEUK-NEG
73a8|urine BACTERIA-FEW
7495|urine YEAST-NONE
76da|GLUCOSE-131 elevated
7781|UREA N-32 elevated
77c0|CREAT-1.0
77f9|SODIUM-144
78ac|POTASSIUM-3.9
78ce|CHLORIDE-109 elevated
7942|TOTAL CO2-28
7959|ANION GAP-11
7988|estGFR
7a2c|CK-219 elevated
7b19|cTropnT <0.01
7b35|cTropnT <0.01
7b46|PHOSPHATE-3.2
7bd5|MAGNESIUM-2.0
7bdb|WBC-7.1
7bde|RBC-3.12 low
7c0a|HGB-8.8 low
7d43|HCT-26.4 low
7d45|MCV-85
7dba|MCH-28.3
7e39|MCHC-33.4
8024|RDW-14.4
8040|NEUTS-82.3 elevated
8045|LYMPHS-11.7 low
80d1|MONOS-5.3
80e8|EOS-0.3
8114|BASOS-0.4
8124|PLT COUNT-196
813a|PTT-27.2
8158|comminuted fracture of distal femur
8347|posterior displacement of distal fragments
8471|joint effusion on knee films
84b8|comminuted fracture of distal femur on femur films
850d|posterior displacement of distal fragments on femur films
8528|joint effusion on femur films
85c1|no evidence of acute intracranial hemorrhage
862f|no mass effect on CT head
864d|slightly hypodense appearance of caudate nuclei bilaterally
86e6|possible infarction
8711|no evidence of pulmonary embolism
871a|small pericardial effusion on CTA
8927|bibasilar atelectasis on CTA
8b1a|small bilateral pleural effusions on CTA
8beb|emphysematous changes on CTA
8c3d|multiple rib fractures may be related to resuscitation efforts
8c79|subcarnial soft tissue density may be related to hiatal hernia
8da1|comminuted displaced supracondylar fracture of distal left femur
8dbd|fixated with lateral plate and multiple screws
8dd8|marked improvement in positioning of major fragments
8df3|right ventricular dilation with moderate global hypokinesis
8f5d|preserved left ventricular systolic function
8f8f|small circumferential pericardial effusion on TTE
914a|left lower lobe atelectasis improved
9188|small left pleural effusion new or newly apparent
92c1|right lung clear on CXR
92e2|ET tube in standard placement
9329|right jugular line ends in mid SVC
9343|no pneumothorax on CXR
935e|dementia
938a|depression with paranoia
93d8|CAD
9424|CHF
94c7|presented s/p fall at assisted living
94d1|left-sided impacted femoral fracture
94da|PEA arrest after receiving anesthesia in the OR
94e4|hospice care decided as most appropriate
9521|distal supracondylar fracture of femur with angulation and displacement
95e8|went to operating room for ORIF
967e|intubated prior to surgery
96f0|pulseless electrical activity
96f7|code blue was called
9747|return of spontaneous circulation with CPR
97ca|transferred to the MICU
9922|taken back to OR for successful open reduction and internal fixation
9931|maintained on Lovenox for DVT prophylaxis
99d2|pain controlled with fentanyl while intubated
99e9|intubated
9ab5|evaluated by palliative care starting
9b62|pain controlled with fentanyl patch and dilaudid
9c02|weaned down to oxycodone and lidocaine patches on both knees
9d1f|induction of endotracheal anesthesia
9ead|asystole
9f15|cardiopulmonary resuscitation was started
9f6a|return of spontaneous circulation
9fe5|no lab abnormalities to explain her arrest
a052|no PE on CTA
a14c|PEA arrest possibly secondary to fluid shift vs anesthesia
a150|intubated in the setting of pulseless electrical arrest
a1b0|continued on mechanical ventilation
a1f1|agitation
a206|extubated first time
a213|did well for several hours after extubation
a267|required re-intubation for increased secretions and respiratory distress
a281|extubated again
a34c|would not be reintubated
a387|DNR/DNI reversed for OR
a5f4|did well on nasal cannula oxygen
a61c|episodes of tachypnea
a64c|shortness of breath
a67e|responded well to morphine 2.5mg PO
a6e9|required intermittent norepinephrine gtt for MAP < 65
a7b0|versed gtt for sedation
a7f1|volume depletion due to loss of blood into femur fracture
a8a9|history of anemia taking iron daily
aa9b|Hct on admission was 26.4
aace|decreased from baseline of 29
aad6|dilutional anemia
ab12|bled into fracture site
ab98|given 2 units of PRBC on admission
abb4|given 3 more units of PRBC
ac18|drop in hematocrit thought to be likely bleeding into femur fracture
ac4c|Hct stabilized after surgery
aca2|not required further transfusions
accd|history of depression with psychosis taking multiple psychiatric medications
ad22|continued on Olanzapine
afc0|continued on lorazepam
b06c|continued on Abilify
b07e|continued on Mirtazapine
b28f|started on tube feeds while intubated
b3a9|evaluated by speech and swallow after extubation
b42f|failed swallow evaluation
b4e4|can tolerate very small amount of nectar thickened liquids and pureed food
b591|decision was made to allow the patient to eat for comfort
b5d0|Lorazepam 1 mg PO BID on admission
b652|Miralax prn for constipation on admission
b93c|Cholecalciferol 800 U PO daily on admission
b968|Ferrous sulfate 325 mg PO daily on admission
b9a7|ASA 81 mg PO daily on admission
ba28|Abilify 5 mg PO daily on admission
ba8b|Lorazepam 0.5 mg PO q6h prn for anxiety on admission
bab9|Fentanyl 12 mcg/h patch q72h on admission
babb|Mirtazapine 45 mg PO qhs on admission
bcd3|Omeprazole 20 mg PO BID on admission
bd5f|Olanzapine 20 mg PO BID on admission
bd7f|Olanzapine 2.5 mg PO BID on admission
be38|Docusate 100 mg PO BID on admission
bfac|Olanzapine 10 mg PO daily prn for anxiety on admission
bfdd|olanzapine 10 mg at discharge
bfe3|fentanyl 12 mcg/hr patch at discharge
c02e|enoxaparin 30 mg at discharge
c037|oxycodone 5 mg at discharge
c082|lidocaine 5% patch at discharge
c086|morphine 10 mg/5 mL at discharge
c087|acetaminophen 650 mg at discharge
c0b2|lorazepam 0.5 mg at discharge
c0b8|discharged to Extended Care Facility
c0f0|left femur fracture s/p repair at discharge
c0fa|pulseless electrical activity x2 at discharge
c162|respiratory failure at discharge
c213|anemia at discharge
c35b|confused at discharge
c3ef|alert and interactive at discharge
c4b6|out of bed with assistance to chair or wheelchair at discharge
c525|admitted with a left femur fracture
c6be|heart stopped beating
c6c7|cardiac arrest occurred twice
c72c|start heart again
c78d|hooked up to a ventilator
c811|remove the breathing tube
c970|breathe on your own
ca2d|feeding tube placed down your nose
caed|pulled out feeding tube
cb1d|difficulty breathing
cbe7|responded well to morphine
cc09|focus on comfort care
cc7a|focus on symptom management for comfort

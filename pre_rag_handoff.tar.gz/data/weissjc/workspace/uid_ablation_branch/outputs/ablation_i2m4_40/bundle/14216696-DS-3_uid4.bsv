0034|male
007f|No Known Allergies to Drugs
017a|fall off bicycle
0409|none
0425|male
052f|no PMH
055f|no meds
07e0|fell off his bike when it hit the curb
0a25|Does not remember the incident
0adb|poor historian initially in the ED
0c8d|Inebriated with SEtOH 220 in ED
0eb1|HCT shows depressed skull Fx in the right ftl bone extending down through the frontal sinus and supraorbital region
0f9a|Minimal underlying SD blood
10a6|no obvious cerebral contusion at this time
11dc|not revealing for fracture at this time
11f6|CT of facial bones pending
1245|plastics eval pending
1275|none
1292|BP 137/77
153c|HR 91
167a|R 22
1715|97% RA O2Sats
17dc|Hard C-collar in place
1804|WD/WN
184c|comfortable
1911|NAD
1950|Pupils 3-->2 and equal
1ab5|EOMs full/conjugate
1c01|no nystagmus
1c61|Supple
1d4c|CTA bilaterally
1db1|RRR
1e39|S1/S2
1e89|Soft
21ea|NT
2546|BS+
25dd|Warm and well-perfused
2945|Lac at R plantar foot
296f|Severalcontusions and abrasions
2a5d|R frontal region contusions and abrasions
2a75|right eyelid ecchymosis
2a9b|Awake and alert
2b72|cooperative with exam
2c15|normalaffect
2daf|Oriented to person, place, and date
2dd4|___ objects at 5 minutes
2e43|Speech fluent with good comprehension and repetition
2ec3|Naming intact
3081|No dysarthria
322e|no paraphasic errors
3428|Not tested
34b5|Pupils equally round and reactive to light
34e3|tomm bilaterally
35e3|Visual fields are full to confrontation
37ed|Extraocular movements intact bilaterally withoutnystagmus
383a|Facial strength and sensation intact and symmetric
38e8|swollen R eye
3929|Hearing intact to voice
3a4b|equal to finger rub bilaterally
3b52|Palatal elevation symmetrical
3b5d|Sternocleidomastoid and trapezius normal bilaterally
3df2|Tongue midline without fasciculations
3e90|Normal bulk and tone bilaterally
4121|No abnormal movements
416b|no tremors
4242|Strength full power ___ throughout
43fc|No pronator drift
44ac|Intact to light touch, propioception, pinprick andvibration bilaterally
44bf|Toes downgoing on left
45d6|normal on finger-nose-finger with no dysmetria ortremor
4619|heel to shin not tested due to injuries
4738|awake
475a|alert
47c8|oriented x3
4887|Pupils 4-3mm
4b37|EOMI
4b52|R orbital ecchymosis
4df7|left forehead abrasion with DSG- C/D/I
4f1d|hard collar on
529c|no pronator drift
5412|MAE's symmetrically with full strengths
5440|following all commands
548f|Right foot dressing c/d/i
54bc|no mass effect or shift
5557|depressed skull fracture
5987|sEtOH 221
59b9|UA normal
5bf4|admitted to the ICU
5c10|monitored closely
5c1d|remained neurologically intact
60d1|Repeat CT was stable
61d6|cleared for transfer to the floor
6336|seen in consultation by Plastic surgery
646a|recommended antibiotic prophylaxis
665b|Diet and activity were advanced
680c|Pain was adequately controlled
6822|voiding without difficulty
6ac0|remained neuro intact
6ba9|cleared for discharge home
6e4a|none
6e6b|Phenytoin Sodium Extended 100 mg Capsule Sig: One (1) Capsule PO TID (3 times a day) for 7 days
712e|Oxycodone-Acetaminophen ___ mg Tablet Sig: ___ Tablets PO Q4H (every 4 hours) as needed for Pain
713d|Amoxicillin 500 mg Capsule Sig: One (1) Capsule PO three times a day for 6 days
7182|Docusate Sodium 100 mg Capsule Sig: One (1) Capsule PO BID (2 times a day)
71af|Home
7250|head trauma - depressed skull fracture
756c|Right foot laceration
765a|Left forehead abrasion
784a|Clear and coherent
786d|Alert and interactive
7880|Ambulatory - Independent
78ae|no nose blowing
78b7|no straws
7977|sneeze with mouth open
798c|Augmentin per Plastics
7a33|wear your cervical collar at all times until cleared by Dr. ___
7a55|Dilantin to prevent seizures
7c8f|pain medication as prescribed
8207|Do not drive while on narcotics

00f9|female
016b|no known allergies to drugs
029c|dyspnea on exertion
02eb|no major surgical or invasive procedures
02ef|female
0434|hypertension
04de|mitral regurgitation
04f2|atrial fibrillation on coumadin
052c|vulvar squamous cell carcinoma
056b|24 hours of shortness of breath on exertion
05f2|never had symptoms before
067d|noted symptoms yesterday evening
0687|has had symptoms throughout the day today
0725|denies chest pain
07cd|denies cough
07de|denies nausea vomiting
0830|denies abdominal pain
087b|denies change in bowel movements
0945|admits to lightheadedness
0c5a|normal oral intake the last couple days
0d83|occasional blood loss spotting from vulvar tumor
0da8|not increased blood loss amount recently
0e87|denied blood loss per rectum
0f4e|feels much better after lasix
0ffd|temperature 98.6
125f|heart rate 68
12c8|blood pressure 129/82
1428|oxygen saturation 100% on 4L
14bb|BNP 833
15ce|CXR showed small right pleural effusion
160c|EKG showed more prominent right bundle branch block
16d3|EKG showed atrial fibrillation
1717|EKG showed slight ST depressions in V2/V3
1806|received aspirin 325mg x 1
182f|CTA performed to rule out pulmonary embolism
18ed|CTA negative for pulmonary embolism
1936|CTA showed mild congestive heart failure
1a90|CTA showed new right pleural effusion
1bc9|hematocrit 26
1ca2|transfused 1 unit PRBC
1d17|received 20mg IV lasix for CHF
1d26|put out 1500cc urine output
1d5f|atrial fibrillation on anticoagulation
1ede|hypertension
1f3a|hypercholesterolemia
1fd6|irritable bowel syndrome
2050|spinal stenosis
2054|anemia chronic anemia of unknown origin
2589|current baseline hematocrit
25e2|MCV mid
2647|colonoscopy showed polyp in ascending colon
26d6|colonoscopy showed polyp in sigmoid colon
2814|EGD revealed gastritis
2933|EGD revealed angioectasias in the fundus
2a33|EGD and push enteroscopy normal
2a41|capsule endoscopy active bleeding in the stomach
2ab1|EGD normal
2bc0|patient does not tolerate oral iron
2bcb|gastritis
2d3a|basal cell carcinoma
2d5f|dementia
2dd3|father with pernicious anemia
2e62|mother with arthritis
2fb0|no known family history of cancer
2fb5|no known family history of hypertension
308d|temperature 97.5
3183|blood pressure 142/40
3205|heart rate 87
32dc|respiratory rate 18
3350|oxygen saturation 97% on room air
3352|awake
33f0|alert
34a3|no acute distress
3580|pleasant
36bd|normocephalic atraumatic
36dd|pupils equal round reactive to light
378b|extraocular movements intact
392a|no scleral icterus
39dc|mucous membranes moist
39e6|neck supple
3a73|mild crackles at bases
3b0f|irregularly irregular heart rhythm
3b20|normoactive bowel sounds
3bcf|abdomen soft
3c51|non-distended non-tender
3deb|1+ edema bilaterally
3e46|dorsalis pedis pulses bilateral
4022|WBC 5.6
404b|RBC 3.26
406c|hemoglobin 8.0
406d|hematocrit 26.3
413d|MCV 81
41f1|MCH 24.7
4208|MCHC 30.5
4343|RDW 14.2
4374|WBC 4.9
4468|RBC 3.52
449c|hemoglobin 8.8
452f|hematocrit 28.3
45da|MCV 80
4747|MCH 25.1
475e|MCHC 31.2
479e|RDW 16.2
47a3|neutrophils 73.4
482e|lymphocytes 16.1
4864|monocytes 7.6
4a97|eosinophils 2.7
4b91|basophils 0.3
4be0|PTT 34.5
4c4d|glucose 87
4c71|BUN 16
4e79|creatinine 0.7
4f0e|sodium 141
4f19|potassium 4.3
5059|chloride 103
514e|bicarbonate 31
51a2|anion gap 11
51be|CK CPK 610
5601|CK CPK 616
5614|CK CPK 644
585e|CK CPK 554
5a03|CK-MB 5
5bc9|proBNP 833
5d03|troponin T 0.01
5dfa|CK-MB 5
5e08|troponin T 0.02
5e9a|CK-MB 5
60a6|troponin T less than 0.01
6199|calcium 9.3
61d5|phosphorus 3.4
6215|magnesium 2.2
629e|no pulmonary embolism
62f9|mild congestive heart failure with small right pleural effusion
6500|marked cardiomegaly
6541|small noncalcified pulmonary nodules unchanged
6692|new small left pleural effusion
6730|no acute cardiopulmonary disease
6741|atrial fibrillation with moderate ventricular response
69bb|right bundle-branch block
6b70|non-specific inferolateral ST-T wave changes
6bcf|right bundle-branch block is new
6bd2|left atrium markedly dilated
6ca6|right atrium markedly dilated
6cb9|mild symmetric left ventricular hypertrophy
6d6a|normal cavity size
6d84|normal regional global systolic function LVEF greater than 55%
6e78|Grade III IV severe LV diastolic dysfunction
7009|right ventricular chamber size normal
7041|right ventricular free wall motion normal
70f4|ascending aorta mildly dilated
7137|aortic valve leaflets mildly thickened
7161|aortic stenosis not present
726a|no aortic regurgitation
728e|mitral valve leaflets mildly thickened
72d4|mild to moderate mitral regurgitation
7467|restrictive filling abnormality with elevated left atrial pressure
74ed|moderate tricuspid regurgitation
76b9|moderate pulmonary artery systolic hypertension
76dd|trivial physiologic pericardial effusion
792e|findings similar to prior study
79f9|atrial fibrillation
7ba0|anemia
7cf2|hypertension
7cfc|hypercholesterolemia
7d1a|presented with one day of dyspnea on exertion
7d7f|back at baseline
7e55|diastolic heart failure
7eec|ECG atrial fibrillation
7fa1|new right bundle branch block
80ca|ruled out for MI with serial biomarkers
821c|CTA in ED showed no pulmonary embolism
8384|CTA small right pleural effusion
847b|CTA mild CHF
84ef|atrial fibrillation with rapid ventricular rate prior to arrival
8552|treated with IV lasix
8562|treated with PO lasix
8668|HR treated with metoprolol
8708|BP treated with metoprolol
88b0|metoprolol
8a9d|get stress echo while inpatient
8b42|not able to complete exercise portion of stress echo
8c3b|get surface echo instead
8ced|no wall motion abnormalities on echo
8da6|dilated atria on echo
8dd0|increased atrial pressures on echo
8dfb|diastolic failure on echo
8e34|acute symptoms related to transient pulmonary edema
8e64|rapid ventricular rate
8ee7|severe diastolic failure
8eef|medical regimen optimized
8fa4|metoprolol changed to Toprol XL
913f|tolerating lasix
9163|encouraged to eat bananas and orange juice
91fe|need repeat serum chemistries early next week
9446|anemia contributing to shortness of breath
9592|transfused one unit PRBC in ED
95c0|tolerated PRBC transfusion well
9664|hematocrit remained relatively stable
9745|continued on warfarin for atrial fibrillation
97f6|possibility not compliant with warfarin prior to admission
9861|restart warfarin on admission
9892|rate well controlled
98ac|continued on amlodipine for hypertension
99f8|continued on lisinopril for hypertension
9a37|full code during admission
9a91|discharged to home with services
9ab3|simvastatin 40 daily on admission
9b57|colace 100mg BID on admission
9b92|paroxetine 20 mg QD on admission
9d24|metoprolol 75mg TID on admission
9dbc|warfarin 2 mg QHS on admission
9df6|lisinopril 20 mg QD on admission
a017|omeprazole QD on admission
a112|amlodipine 5mg daily on admission
a11a|paroxetine 20 mg at discharge
a1a9|lisinopril 20 mg at discharge
a1f1|omeprazole 20 mg at discharge
a211|amlodipine 5 mg at discharge
a376|colace 100 mg at discharge
a4cd|simvastatin 40 mg at discharge
a68a|furosemide 20 mg at discharge
a74b|metoprolol succinate 100 mg at discharge
a753|warfarin 2 mg at discharge
a9c6|check chem 7 and INR on followup
aaac|home with service at discharge
ab6c|diastolic congestive heart failure discharge diagnosis
ab8d|atrial fibrillation discharge diagnosis
ad28|hypertension discharge diagnosis
ae6d|hyperlipidemia discharge diagnosis
af02|depression discharge diagnosis
afe4|good condition at discharge
b033|ambulating at discharge
b26a|tolerating PO diet at discharge
b2a6|afebrile at discharge
b2b0|admitted with shortness of breath while walking
b3f0|did not have a heart attack
b434|ultrasound of heart
b588|several regurgitant valves leaky
b58d|stiff heart
b5c3|not different than last ultrasound several years ago
b5cc|started on lasix diuretic
b656|electrolytes checked in about one week
b6d3|eat bananas and drink orange juice for potassium
b6d8|metoprolol changed to Toprol XL once daily
b749|experience worsening chest pain
b78c|difficulty breathing
b909|seek immediate medical attention

0034|Admission Date: [**2147-6-12**]
005e|Discharge Date: [**2147-6-22**]
00d1|Date of Birth: [**2072-12-29**]
0117|Sex: M
01b1|No Known Allergies to Drugs
0289|Chest Pain
029b|persantine MIBI cardiac stress test
029e|thoracentesis
0310|Chest Tube
0321|74 yo
0373|M
03d9|lung cancer
0435|DVT
051e|presents with 1 day of substernal chest pain
057b|developed chest pain the night prior to admission
0594|pain was substernal
0681|did not radiate
069d|pain was similar to his prior MI
0964|shortness of breath
09a6|pain resolved with NTG
0a0a|pain resolved with morphine
0a13|given ASA
0a6c|given bblocker
0c2e|denied nausea
0ca3|denied vomitting
0cd1|denied abdominal pain
0d86|denied dysuria
0ead|denied dizziness
0f2f|denied changes in vision/hearing
0f67|Lung cancer
11ab|Non-small cell lung cancer stage IIIA
11d7|status post weekly carboplatin and Taxol chemotherapy
134e|XRT for seven weeks
1536|surgery on [**2147-3-28**]
15f5|CAD
169d|s/p inferior STEMI
1709|stent to L Cx
18a5|CHF
196d|EF 55%
1a46|HTN
1a6c|paroxismal afib
1b3d|CVA
1b73|Left LE DVT
1bd0|on coumadin
1c66|s/p IVC filter
1e16|non-smoker
1eab|occasional etoh
1ec7|no drugs
1f3e|father with CAD
208f|mother with CAD
213c|CAD
2172|VS - 98.0 67 140/63 22 99% on RA
2243|A+Ox3
2244|NAD
2356|EOMI
2406|OP clear
2413|supple
24c4|no LAD
2678|no JVD
27d3|RRR
2860|no murmurs
28ce|R base with poor excursion
29ca|poor breath sounds
2aa1|Clear otherwise
2aea|s/nt/nd
2bca|+BS
2c41|w/wp
2c4d|no edema
2cee|R leg swollen compared to left
2dbb|CK(CPK)-67
2e40|CK-MB-NotDone
2ecd|cTropnT-<0.01
2f23|GLUCOSE-159*
3092|UREA N-17
30ef|CREAT-1.0
31dd|SODIUM-137
31ff|POTASSIUM-3.6
321a|CHLORIDE-100
3230|TOTAL CO2-27
3258|ANION GAP-14
3271|CK(CPK)-76
32c0|cTropnT-<0.01
33b7|CK-MB-NotDone
33c8|WBC-10.4
3405|RBC-4.41*#
3488|HGB-12.8*#
34ff|HCT-38.2*#
357f|MCV-87
3623|MCH-29.0
3731|MCHC-33.5
389a|RDW-15.9*
3941|NEUTS-86.1*
39bf|LYMPHS-5.4*
3a64|MONOS-5.7
3aee|EOS-2.2
3bbd|BASOS-0.6
3bc6|MICROCYT-1+
3cf1|PLT COUNT-372
3d7f|PT-20.4*
3e5e|PTT-28.6
3e94|INR(PT)-2.0*
3efb|COLOR-Yellow
3f7b|APPEAR-Clear
404e|SP-1.013
4057|BLOOD-MOD
40a7|NITRITE-NEG
40b6|PROTEIN-NEG
4143|GLUCOSE-NEG
428e|KETONE-NEG
4316|BILIRUBIN-NEG
4389|UROBILNGN-NEG
43ed|PH-6.0
4403|LEUK-NEG
4414|RBC-[**4-16**]*
4534|WBC-0
4537|BACTERIA-NONE
4631|YEAST-NONE
465f|EPI-<1
469a|Increased right pleural effusion
46b8|partial collapse of the right upper lung
470c|NSR 70
4781|nl axis
47fd|nl int
4820|old TWI III, F
4976|old J pointing V
49c8|heart stable
4b30|pericardium stable
4b48|great vessels stable
4d7c|small amount of pericardial fluid
4db1|No definite axillary lymphadenopathy
4dfb|No definite mediastinal lymphadenopathy
4e2f|No definite hilar lymphadenopathy
4efc|moderate-to large-sized right pleural effusion
4f3d|interval development of moderate amount of high-attenuation fluid within the effusion consistent with hemorrhage
4f85|Patchy consolidation of the right lung is stable
4fa1|Hazy patchy opacities in the left lung field
5004|no frank consolidation
5051|liver within normal limits
5153|gallbladder within normal limits
5290|pancreas within normal limits
52e1|spleen within normal limits
536e|adrenal glands within normal limits
537b|kidneys within normal limits
537e|stomach within normal limits
5485|small bowel loops within normal limits
566b|colonic diverticulosis
5743|no free air
57b6|no free fluid
57c8|No mesenteric lymphadenopathy
57d1|No retroperitoneal lymphadenopathy
59cf|IVC filter is seen
5acd|bladder is unremarkable
5b2a|status post prostatectomy
5b56|rectum is unremarkable
5bc1|no free fluid
5be8|no pelvic lymphadenopathy
5c06|no inguinal lymphadenopathy
5d43|lytic area in L5 vertebral body
5d71|Several subacute or chronic rib fractures on the right
5d8f|Interval development of a moderate amount of hemorrhage within the right pleural effusion
5e03|No acute intra-abdominal abnormalities identified
5e27|New moderate and fixed inferior myocardial wall perfusion defect
5eb0|Mild inferior wall hypokinesis
5efe|Calculated LVEF 42%
5f1d|74 yo
5f2f|M
5f39|lung cancer
6078|DVT
60de|CAD s/p MI
61ac|presents with chest pain
6272|shortness of breath
6348|history of CAD a/p MI
64ec|episode of pain consistent with his anginal equivalent
6564|No changes on EKG
657e|not in pain at time of EKG
66a2|ruled out by enzymes
66dc|stress test revealed an irreversible deficit from his prior known IMI
672b|Continued on asa
679f|Continued on bblocker
67be|Continued on [**Last Name (un) **]
68f1|Continued on statin
6add|Continued on plavix
6bfd|BP meds held while was unstable
6bff|ASA held during hemothorax
6d03|plavix held during hemothorax
700e|CHF
7068|does not seem volume overloaded
71c3|no JVD
71e3|no edema in legs
723f|Last Echo with EF 55%
7505|increased effusion although loculated
7591|Continued on lasix
75c1|Continued on bblocker
78ae|Continued on [**Last Name (un) **]
7917|BP meds held while unstable
791d|Afib
7a2b|In sinus during admission
7a79|anticoag held during hemothorax
7dee|Shortness of Breath/loculated Effusion
7e0a|increasing loculated pleural effusion
7e0b|chronic shortness of breath
7f48|worsened over the past few days
7f5c|No sign of infeciton at this time
816c|Had thoracentesis by interventional pumonology on [**2147-6-14**] revealing almost 2 L of serous exudative fluid
81b1|improved breathing
81d3|Cytology was negative
82a5|Hct dropped
8349|CT revealed hemothorax
845a|All anticoagulation stopped despite the risk of DVT, afib
855a|Risk discussed with family
858b|Thoracics consulted
861a|chest tube placed
8760|Frank blood was taken out
87a6|Patient continued to bleed in and around the tube
87f3|Patient sent to MICU for observation after Hct continued to drop
885e|Patient spontaneously stablized
8988|output of CT became more serous
8a55|Output resent for cytology which was pending at time of discharge
8ac3|output became <100 cc
8d65|tube was removed
8db2|serial CXR that did not demonstrate reaccumulation
8e5a|Hct also remained stable
8e73|DVT
8fbe|therapeutic on heparin
907f|Improving clots on LENI
90c7|CTA neg for PE
9171|Anticoagulaiton held during hemothorax
91b6|Patient restarted on coumadin
92c8|will be discharged on 3mg coumadin qday
954e|Lung Cancer
9632|no evidence of disease
973d|s/p neoadjuvant chemo/XRT
98e7|s/p surgery
99fe|1st cytology negative
9a48|2ng cytology pending
9b80|Lipitor 80mg qday
9b8d|Asa 81mg qday
9bb9|bowel reg
9bc2|percocet prn
9d7d|plavix 75mg qday
9e3e|losartan 25mg qday
9e54|coumadin 3mg qday
9ee0|lasix 20mg qday
9f2c|atenolol 25mg qday
9f31|Atorvastatin 80 mg
9f6d|Aspirin 325 mg
9fc7|Senna 8.6 mg
a212|Bisacodyl 5 mg
a223|Oxycodone 5 mg
a256|Clopidogrel 75 mg
a2c4|Furosemide 20 mg
a2dc|Nitroglycerin 0.3 mg
a421|Atenolol 50 mg
a445|Losartan 50 mg
a461|Benzonatate 100 mg
a485|Acetaminophen 325 mg
a51e|Oxycodone 5 mg
a576|Codeine-Guaifenesin 10-100 mg/5 mL
a64f|Coumadin 3 mg
a6e0|Home With Service
a70d|[**Hospital 119**] Homecare
a7f8|Angina
a809|Pleural Effusion
a87e|SecondaryHTN
a8e7|Non small cell lung cancer
aa02|CAD
aa71|DVT
aab1|h/o afib
ab9f|stable
ae87|eating
aee9|on room air
af4b|take all medications
b155|make all appointments
b2cd|chest pain
b355|shortness of breath
b476|abdominal pain
b4a4|nausea
b5fc|other concerning symptoms
b845|come to the emergency room
b941|changed some of your blood pressure meds
b9ac|atenolol has increased to 50mg a day
baeb|losartan has increased to 50mg a day
bc76|Date/Time:[**2147-7-20**] 9:00
bd08|call Dr. [**Last Name (STitle) **] to also see him again sooner [**8-21**] days
bd57|see Dr. [**Last Name (STitle) 2903**] on monday and have your coumadin level checked

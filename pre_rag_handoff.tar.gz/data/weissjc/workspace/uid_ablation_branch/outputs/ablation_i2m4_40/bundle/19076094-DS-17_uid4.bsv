0040|male
015e|allergy to Protonix
01b7|allergy to Accupril
0228|allergy to Pravachol
028b|allergy to Mevacor
02b8|scheduled ___ procedure
02cc|___ aortic valve replacement
0339|CABG x4
041d|CVA
043b|100% L carotid occlusion
044f|aortic stenosis
0459|symptomatic
0463|shortness of breath after walking 1 block
0563|rest after climbing 1 flight of stairs
05d6|syncopal episode while having IV's started in an upright position
074f|syncopal episode 6 months ago while getting into shower
077d|pneumonia
07c8|denies chest pain
0899|three patent grafts
0929|aortic valve area 0.8cm2
09db|mean gradient 36mmHg
0ae4|heavily calcified aorta prohibitive for conventional surgical AVR
0b52|consented for participation in the ___ TAVI study
0d11|cold-like symptoms of head congestion
0eb6|no fever
1041|___ initiated
11cb|symptoms improving
11ea|fever free
1239|cleared by his PCP
1323|Last dose Plavix ___
1325|___ placement
14bf|transvenous pacing placed through femoral line
1611|valve placed through subclavian access
1615|sedated with fentanyl
1632|sedated with versed
18bf|required Neosynephrine for blood pressure support
18dc|weaned off Neosynephrine
194b|LBBB
1976|paced rhythm
198f|given Vancomycin
1a1a|given cefazolin
1b2c|extubated prior to arrival to the CCU
1bea|mildly sedated
1c0b|appropriately responding to commands
1caa|post op N/V from previous surgeries
1cfe|residual sensory deficit from prior CVA
1d6e|no motor deficits
2287|esophageal stricture
2324|NYHA Class II
2353|Dyslipidemia
23c5|Hypertension
23f8|Coronary artery bypass graft x ___
24a5|Aortic stenosis
24ca|none
259a|___
25e8|Sepsis secondary to aspiration pneumonia
2607|Lumbar radiculopathy with L4-L5 disc herniation
260c|AAA
2643|Carotid stenosis
265f|CVA from left common carotid occlusion
2673|Esophageal stricture s/p multiple dilatations
27fc|Obstructive sleep apnea on CPAP
2822|GERD
2875|Degenerative joint disease
2a79|Pseudomonas bacteremia from UTI
2ada|Anxiety
2c28|Spinal stenosis
2c30|Benign prostatic hypertrophy
2cb0|Neurogenic pseudo-claudication
2eab|Left shoulder surgery
2eef|Back surgery
2f51|Tonsillectomy
32d5|Cataract surgery
3446|TURP
3721|Right elbow surgery
3743|Right knee surgery
37b6|BP 141/43
37ed|HR 61
38ad|RR 18
3c15|O2 sat 96%
3c6c|NAD
3d66|NCAT
4000|anicteric
411b|PERRL
4155|EOMI
4266|no pallor
42c3|no cyanosis of the oral mucosa
4384|Supple
43bf|trachea midline
4415|bilat bruits vs referred murmer
4598|No MRG
4646|No thrills
4974|No S3
498a|No S4
4b08|No chest wall deformities
4b78|scoliosis
4c21|kyphosis
4ced|unlabored
4d5f|no accessory muscle use
4e00|CTAB
500d|Soft
5078|NTND
5267|No HSM
543f|not enlarged by palpation
548d|No abdominial bruits
564a|No c/c/e
569d|No stasis dermatitis
5893|ulcers
59e4|scars
5a29|xanthomas
5c26|WBC 8.0
5c3a|RBC 4.10
5c87|HGB 13.4
5f09|HCT 37.0
632d|MCV 90
635b|MCH 32.7
6511|MCHC 36.3
6514|RDW 12.4
6753|PLT COUNT 165
67cf|PTT 28.0
6a97|GLUCOSE 96
6aa7|UREA N 10
6b4b|CREAT 1.1
6c06|SODIUM 140
6c66|POTASSIUM 3.9
6d74|CHLORIDE 102
6e14|TOTAL CO2 30
6f5b|ANION GAP 12
70b3|ALT 40
714f|AST 33
7172|CK 116
7209|ALK PHOS 80
746c|TOT BILI 0.9
74f2|ALBUMIN 4.2
75b8|BLOOD NEG
7768|NITRITE NEG
7788|PROTEIN 30
77f8|GLUCOSE NEG
7924|KETONE NEG
79a4|BILIRUBIN NEG
79c4|UROBILNGN NEG
79ec|PH 7.0
79ee|LEUK NEG
7b33|CK-MB 2
7b9c|proBNP 173
7bf4|%HbA1c 5.4
7e59|eAG 108
7ee2|Triglyc 100
8109|HDL 34
8161|CHOL/HD 2.4
83ae|LDLcalc 26
866c|CK 303
8678|CK-MB 5
882b|Glucose 103
8a02|UreaN 14
8c4d|Creat 1.0
914a|Na 138
9200|K 3.8
93dc|Cl 104
941c|HCO3 27
94b5|AnGap 11
950e|WBC 7.5
951d|RBC 3.59
951e|Hgb 11.4
9532|Hct 32.8
95e9|MCV 91
960c|MCH 31.7
96c6|MCHC 34.7
9772|RDW 12.5
99e7|LVEF>55%
9a44|Mild to moderate aortic regurgitation
9a59|Moderate mitral regurgitation
9b78|Moderate tricuspid regurgitation
9bf2|no pericardial effusion
9d17|LVEF>55%
9daf|PCWP>18mmHg
9e30|no mitral valve prolapse
9ee0|no pericardial effusion
a041|___ procedure
a1e4|___ procedure
a375|started on plavix
a37b|aspirin continued
a476|expressive aphasia
a527|no residual deficits
a534|no ventricular thrombus
a53e|started on coumadin
a61e|stop plavix
a74b|re-initiate plavix therapy
a7d8|stopped amlodipine
a805|stopped hydrochlorothiazide
a898|transient ischemic attack

026e|M
051c|No Known Allergies to Drugs
0606|painless jaundice
065e|cholangiogram
074f|man
0913|painless jaundice
09c6|fatigue
0adc|diarrhea
0b87|elevated LFTs
0ba6|ERCP
0e47|narrowing at the junction of the left and right hepatic ducts
0f1f|abdominal CT scan
1005|calcified lesion of 18mm on the anterior dome of the right lobe of the liver
129a|atrophic left lobe
12fa|liver biopsy
1393|atypical lymphoid infiltrates
14ad|admitted
14e4|PTC placment
155a|15 lb weight loss
18cb|Hodgkin's disease
1b90|radiation
1c00|recurrence
1c8f|chemotherapy
1c9b|hypothyroidism
1d2b|GERD
1d4a|splenectomy
1dbc|extensive lymphadenectomy
1e0e|L and R inguinal hernia repairs
1e1f|L and R shoulder rotator cuff tear repairs
1eb8|NAD
22f7|RRR
23ad|CTA
23bd|WBC-9.1
2609|RBC-3.22*
2837|HGB-10.3*
2a30|HCT-30.3*
2c4c|MCV-94
2cdf|MCH-32.1*
2e52|MCHC-34.1
2f18|RDW-15.1
2f21|PTT-28.2
32a0|PLT COUNT-644*
32bd|ALT(SGPT)-80*
33bb|AST(SGOT)-52*
364c|ALK PHOS-244*
377e|TOT BILI-1.3
37ae|ALBUMIN-3.5
38e2|HCT-30.2*
3b3f|GLUCOSE-86
3b56|UREA N-23*
3d0b|CREAT-1.0
3d16|SODIUM-139
3deb|POTASSIUM-4.4
3feb|CHLORIDE-103
406f|TOTAL CO2-29
41a0|ANION GAP-11
4232|WBC-9.7
439e|RBC-3.64*
4766|HGB-12.2*
47c0|HCT-34.2*
47ff|MCV-94#
4c4b|MCH-33.4*
4d04|MCHC-35.6*
4da7|RDW-15.1
4dc3|PTC with placement of Right external/internal catheter
4e3d|amylase elevated to 608
4f04|lipase elevated to 1125
5052|nausea
511c|diet was kept to sips only
51e6|drain was capped
5411|amylase and lipase slowly trended back to normal
54cf|diet was advanced slowly
54ed|tolerating a regular diet
5638|abdominal pain
57dd|pain around the drain
580a|no leakage
58c6|labs normalized
592c|signed consent for anesthesia
595c|levothyroxine 150 mcg
5aa8|prilosec 20 QD
5e1f|Omeprazole 20 mg Capsule, Delayed Release(E.C.) Sig: One (1) Capsule, Delayed Release(E.C.) PO DAILY (Daily).
5e91|Levothyroxine 75 mcg Tablet Sig: Two (2) Tablet PO DAILY (Daily).
5fb2|Ursodiol 300 mg Capsule Sig: One (1) Capsule PO BID (2 times a day).Disp:*60 Capsule(s)* Refills:*2*
60ff|Ciprofloxacin 250 mg Tablet Sig: Two (2) Tablet PO Q24H (every 24 hours).Disp:*60 Tablet(s)* Refills:*0*
612a|Oxycodone 5 mg Tablet Sig: ___ Tablets PO every ___ hours as needed.Disp:*30 Tablet(s)* Refills:*0*
685b|Home
6a0a|painless jaundice
6ac6|biliary stricture
6c67|Good
6ec1|Tolerating a regular diet
6f4a|Pain controlled on oral medication
6f97|PTC drain will remain capped
7016|fever >101.5
70d4|increasing abdominal pain
70e3|juandice
71f7|persistent nausea or vomiting
72a6|leakage from the drain site

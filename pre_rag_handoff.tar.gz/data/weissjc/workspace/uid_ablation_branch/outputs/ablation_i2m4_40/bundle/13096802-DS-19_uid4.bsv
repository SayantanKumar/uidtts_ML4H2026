01b3|female
02f3|No Known Allergies
030c|No Adverse Drug Reactions
0327|Right multifocal breast cancer
059e|Right axillary sentinel lymph node biopsy
0621|Right bracketed wire-localized partial mastectomy
0724|female
09c9|presented to Dr. ___ in ___
0a49|recent diagnosis of right multifocal breast cancer
0bb3|noting palpable area in the lateral right breast on self exam in ___
0c4b|saw Dr. ___ in ___
0d70|ordered imaging
0e3f|referred her to Breast Care Services
104e|Bilateral diagnostic mammogram was performed on ___
10b7|demonstrating an area of increased density in the area that correlated with her palpable concern
1218|Right breast ultrasound confirmed the appearance of 3 masses between 8:30 and 9 o'clock within the breast
1340|measuring 2 cm in size
1351|No additional foci or adenopathy were noted by imaging
1480|A core biopsy was obtained from the 8:30 lesion
15ac|consistent with invasive carcinoma with ductal and lobular features
15c5|grade 2
16ba|ER positive
1767|PR positive
1770|HER-2 amplified
1782|One of the 2 masses at 9 o'clock was also biopsied of the labeled 10 o'clock on the pathology report
18a2|consistent with invasive ductal carcinoma grade 2
18c3|DCIS
1911|ER positive
1a43|PR positive
1c3a|HER-2 amplified
1e22|no remarkable past breast history
1f50|denied any associated symptoms
1ff6|coronary artery disease
21bf|recent stent placement
238e|history of MI
2397|developed atrial fibrillation after her stent placement
247e|warfarin
25b4|Plavix
25f8|breast conservation therapy
27bc|presents to undergo wire bracketed partial mastectomy with sentinel lymph node biopsy today
2870|CKD (chronic kidney disease) stage 3
288f|CAD
2970|Hx of MI
29e6|HTN
29fd|Hypercholesterolemia
2a85|gout
2aaf|colonic adenoma
2d92|no known family history of cancer
2ede|temperature 97.9
2fe8|heart rate 60
305d|blood pressure 142/68
33fb|respiratory rate 18
3679|oxygen saturation 96%RA
37f4|alert
388d|pleasant
3a3c|irregularly irregular heart rhythm
3a8a|clear lungs
3b0b|soft abdomen
3d7d|non-tender non-distended abdomen
3e5e|R breast soft
3ee6|mild edema
3f09|no hematoma
407b|warm well perfused extremities
40d6|no ___ edema
40fc|Hct-35.6*
4185|clinical stage I-II right breast cancer
4218|presented to ___ on ___
4608|underwent right axillary sentinel lymph node biopsy
46a5|right bracketed wire-localized partial mastectomy
4798|tolerated the procedure well
48e9|admitted to the ___ surgery service for observation post-operatively
49e5|right breast with mild edema noted
4a01|seroma
4b7b|remained stable
4c95|Postop hematocrit (35.6)
4d38|kept NPO with IVF overnight
4df3|diet was advanced
501c|tolerated well
5175|Patient pain was adequately controlled with oral pain medication
51fa|anticoagulation was resumed on POD 1
527a|follow-up with PCP ___ 2 days for INR level
52ae|doing well
538a|afebrile
53b5|stable vital signs
5451|tolerating a regular diet
54d6|ambulating
5517|voiding without assistance
573c|pain was well controlled
58dd|discharged home
59a9|follow-up with Dr. ___ in clinic
5a1d|Acetaminophen 1000 mg PO TID
5a7b|Aspirin 81 mg PO DAILY
5bc5|Atorvastatin 80 mg PO QPM
5d0e|Clopidogrel 75 mg PO DAILY
5d7c|Hydrochlorothiazide 25 mg PO DAILY
5d89|Lisinopril 10 mg PO DAILY
5f81|Metoprolol Succinate XL 25 mg PO DAILY
6062|Nitroglycerin SL 0.4 mg SL Q5MIN:PRN chest pain
681e|Oxybutynin 5 mg PO TID
69ac|Vitamin D ___ UNIT PO DAILY
69e3|Warfarin 5 mg PO DAILY
6a5f|Acetaminophen 1000 mg PO TID
6c4b|Aspirin 81 mg PO DAILY
6d2a|Atorvastatin 80 mg PO QPM
6ea6|Clopidogrel 75 mg PO DAILY
6f59|Hydrochlorothiazide 25 mg PO DAILY
6f7a|Lisinopril 10 mg PO DAILY
70cf|Metoprolol Succinate XL 25 mg PO DAILY
70d6|Nitroglycerin SL 0.4 mg SL Q5MIN:PRN chest pain
71ca|Oxybutynin 5 mg PO TID
71f7|OxycoDONE (Immediate Release)  ___ mg PO Q4H:PRN pain
7225|Vitamin D ___ UNIT PO DAILY
7324|Warfarin 5 mg PO DAILY16
738a|Home
73b7|Right multifocal breast cancer
7437|Clear and coherent
7466|Alert and interactive
74cf|Ambulatory - Independent
76f4|remove your surgical dressing ___ hours after surgery
7734|leave incision open to air
78cd|shower daily
7c2b|No baths or swimming until instructed to do so by ___
7c55|wear a soft, non-restrictive camisole
7d17|no tight or underwire bras
7d8d|resume your regular diet
80a8|DO NOT lift anything heavier than 5 pounds
833e|engage in strenuous activity until instructed by ___
8511|Resume your regular medications unless instructed otherwise
858f|take any new meds as ordered
8a35|take your prescribed pain medication for moderate to severe pain
8b5f|switch to Tylenol or Extra Strength Tylenol for mild pain as directed on the packaging
8ca9|do not take these meds with additional Tylenol
8e7b|Take prescription pain medications for pain not relieved by tylenol
8ed8|Take Colace, 100 mg by mouth 2 times per day, while taking the prescription pain medication
90b7|use a different over-the-counter stool softener if you wish
91a5|Do not drive or operate heavy machinery while taking any narcotic pain medication
91e4|constipation when taking narcotic pain medications
92b6|continue drinking fluids
93bb|take stool softeners
9564|eat foods that are high in fiber
95ae|fever
95ba|chills
95fc|increased redness
962f|swelling
9688|warmth or tenderness at the surgical site
9689|unusual drainage from the incision(s)
975f|large amount of bleeding from the incision(s)
97d6|Fever greater than 101.5 oF
9881|Severe pain NOT relieved by your medication
9903|vomiting
99c5|cannot keep in fluids or your medications
9b13|shaking chills
9b87|fever greater than 101.5 (F) degrees or 38 (C) degrees
9be9|increased redness, swelling or discharge from incision
9c2e|chest pain
9cea|shortness of breath

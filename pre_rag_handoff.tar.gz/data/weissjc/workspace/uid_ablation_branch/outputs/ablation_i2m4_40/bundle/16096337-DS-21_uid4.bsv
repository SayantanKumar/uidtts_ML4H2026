00e7|M
0153|Allergies: Iodine-Iodine Containing
0166|Allergies: Procainamide
016a|Allergies: Cephalosporins
0171|Shortness of Breath
019c|Endoscopy
01c9|male
0225|ischemic CHF NYHA IV
0284|EF 30%
02b5|BiV ICD
037e|pAFIB on coumadin
03f9|CKD (Cr 1.6-1.8)
0488|hx of LGIB
04b1|angioectasia colonoscopy
0520|down trending Hct from the low ___ 27.5
0641|progressive fatigue
06d6|DOE with any activity
07a0|dyspnea with minimal exertion
0808|short of breath
080c|lasix has been increased
081f|on 160mg BID
08a8|without symptomatic relief
08cf|significant lower extremity edema
096b|on spirolactone
09a9|on metolazone
09c4|weight has been stable at ~205lbs
09d0|orthopnea
0ae4|denied having any chest pain
0b86|denied having any other respiratory symptoms
0c20|darker stools
0c78|started on iron pills
0c80|denied having any blood on stool
0cfe|denied having any black tarry stools
0d58|initial vitals were 98.4 67 107/56 18 99% RA
0dde|appeared comfortable
0e10|ventricular-paced rythm
0e26|bigeminy
0ec7|creatine at 1.8
0eda|trending up for the last ___ months
0f56|proBNP: 765
0f75|Hct at 27.3
0fa9|Guaiac +
1030|pulmonary congestion
107f|admitted for further evaluation
10b7|slightly uncomfortable
1130|increased dyspnea on exertion
1157|Diabetes
11c8|Dyslipidemia
1220|Hypertension
1236|CHF (NYHA class IV, ACC/AHA stage D)
128d|Atrial Fibrillation
129d|CABG: Yes
12da|None
12dc|Cardiac defibrillator in place
12ec|Peripheral vascular disease
1311|Long-term anticoagulation
13ba|Anemia
149f|Obesity
14ad|Sleep apnea
14bd|Osteomyelitis - Ankle/Foot (Acute)
14e2|Restless legs syndrome
157d|Colonic Polyp
15c7|Gout
17e6|Lumbar spinal stenosis
1800|Nephrolithiasis
1814|No family history of early MI
1847|No family history of arrhythmia
184a|No family history of cardiomyopathies
18a7|No family history of sudden cardiac death
18b0|WDWN in NAD
18ff|Oriented x3
19c0|Mood, affect appropriate
1a60|NCAT
1aa0|Sclera anicteric
1add|PERRL
1bad|EOMI
1be7|Conjunctiva were pink
1c2a|no pallor or cyanosis of the oral mucosa
1d9d|No xanthalesma
1df1|Supple with JVP to Jaw
1e54|RR
1eef|+ holysystolic loudest on LUSB
1ef0|___ crackles up to mid lung fields
202e|No chest wall deformities
205c|scoliosis
20b4|kyphosis
20eb|mild increase in wOB
219c|no accessory muscle use
21f8|Soft
2246|NTND
2271|No HSM
2371|No tenderness
23dd|Abd aorta not enlarged by palpation
2453|No abdominial bruits
247d|+3 pitting edema up to thigh
2612|___ hyperpigmentation
2698|+ 1 on ___
26f9|alert
27e4|oriented
28ef|NAD
296c|supple
2987|JVD at 5 sitting on edege of bed
29cc|irreg irreg
2a80|___ systolic murmur at RUSB
2b1e|No crackles
2bbe|No wheezes
2ce4|firm
2d98|NT
2e48|pos BS
2f06|1+ peripheral edema to ___ up calf
2f36|skin is wrinkled near ankles
303b|A/O
3047|none
3094|DP 1+ ___ trace
3193|DP 2+ ___ trace
31ac|intact
329f|GLUCOSE-115*
32ac|LACTATE-2.1*
331a|K+-3.6
3323|GLUCOSE-122*
3330|UREA N-46*
3353|CREAT-1.8*
33fb|SODIUM-138
3450|POTASSIUM-3.7
3519|CHLORIDE-95*
3539|TOTAL CO2-33*
355c|ANION GAP-14
3582|ALT(SGPT)-14
35db|AST(SGOT)-18
35ed|ALK PHOS-179*
3603|TOT BILI-1.0
36c0|LIPASE-34
36cc|cTropnT-0.02*
36d5|proBNP-765
372d|ALBUMIN-3.9
3764|CALCIUM-8.4
388a|PHOSPHATE-2.5*
393f|MAGNESIUM-2.8*
39f7|DIGOXIN-1.5
3b64|WBC-6.6
3cc9|RBC-3.00*
3cd8|HGB-8.6*
3d4d|HCT-27.3*
3ddf|MCV-91
3dfb|MCH-28.8
3dfd|MCHC-31.7
3e07|RDW-19.2*
3e22|NEUTS-79.0*
3e78|LYMPHS-12.4*
3e82|MONOS-6.5
3ea8|EOS-1.4
3edf|BASOS-0.7
3f4d|PLT COUNT-284
3f98|___ PTT-38.5*
3fc9|WBC-7.1
4055|RBC-2.90*
40b8|Hgb-8.3*
428c|Hct-25.9*
42ea|MCV-89
43ce|MCH-28.5
43f1|MCHC-31.9
440a|RDW-19.5*
4450|Plt ___
445f|Glucose-92
4466|UreaN-46*
44c5|Creat-1.8*
44d9|Na-141
4539|K-4.0
4572|Cl-100
45b3|HCO3-33*
46f3|AnGap-12
4850|Demand ventricular paced rhythm
487b|frequent ventricular premature beats
48ea|Q-T interval prolongation
4a5a|No previous tracing available for comparison
4a6b|Ventricular pacing
4a99|wide complex native beats
4aa3|ventricular bigeminal pattern is not seen
4b17|ventricular premature beats persist
4b36|Ill-defined bibasilar opacities
4b9e|possible aspiration
4c24|pneumonia
4c38|Underlying mild interstitial lung disease
4e3d|Intact pacemaker/ICD leads in standard position
4ea6|Stable mild cardiomegaly
4ecd|Possible small effusions
4f24|pleural thickening
4fc0|Probable background COPD
5042|Cardiomegaly
50ab|sternotomy
50f1|ICD device
516d|Bibasilar opacities
51a1|Suspect some background more diffuse interstitial abnormality
52b5|Bilateral pleural thickening
5305|?increased soft tissue density adjacent to right paratracheal region
5320|Fibrotic lung changes with a pattern corresponding to NSIP
5385|Mild-to-moderate mediastinal lymphadenopathy
53cb|partly calcified lymph nodes
5483|previous exposure to granulomatous disease
5507|Status post CABG
550c|left pectoral pacemaker in correct position
5556|No evidence of pulmonary nodules
5578|masses
56c5|Minimal bilateral pleural effusions
57bd|No pericardial effusions
57e9|no osteodestructive lesions
57f5|Markedly elevated left and right heart filling pressures
5823|Severe pulmonary hypertension
5913|Aspiration of thin liquids with moderate residue
5a63|Barium reflux to nasopharynx
5a8e|large osteophyte in C3
5b08|male
5b4e|ischemic CHF NYHA IV
5ba3|EF 30%
5bb7|BiV ICD
5c36|pAFIB on coumadin
5c66|CKD (Cr 1.6-1.8)
5cc9|hx of LGIB
5ce2|angioectasia colonoscopy
5de3|down trending Hct from the low ___ 27.5
5e04|progressive fatigue
5ecd|DOE with any activity
5ed9|admitted for CHF exacerbation
5ee7|hx of 3 vessel disease
5ef3|CABG in ___
5f05|denied having any chest pain on admission
5f1b|ASA continued
5f8c|BB continued
6013|statin continued
6097|started on losartan
60d7|acute kidney injury in setting of diuresis
6139|___ was discontinued
61cf|hx of CHF
61de|EF of 30%
627b|fluid overloaded on exam
640d|not be responding appropriate to home dose of lasix
6439|not be responding appropriate to home dose of spironolactone
6488|not be responding appropriate to home dose of metolazone
6597|treated with IV lasix
6615|treated with metolazone
6693|assessed for further diuresis
6699|BP was often too low
6731|___ lasix was held
673b|transfused w 2 Units of blood
67c6|dropping Hct
67f5|pressures remained low
6818|underwent a R-sided cardiac cath
6899|PCWP of 30
68b9|placed on lasix gtt
68d8|quickly stopped
690f|SBPs were in the ___
69f8|transfered to the CCU
6a7c|augemented diuresis
6acb|dopamine
6b13|lasix gtt
6bc3|brisk diuresis of greater than 5L
6bcb|subjective improvement of symptoms
6c70|dopamine was stopped
6d42|transitioned to torsemide 100mg
6d4b|metolazone 2.5 mg was started
6d65|continued on Torsemide 100mg
6e7c|hypotension with SBP in low ___
6fc0|prevented further increase in diuresis
6fe6|significantly orthostatic
7060|SBP ___
7245|lightheadeness while sitting up
7339|inability to work with ___
734b|several doses of metoprolol were held
737a|hypotension
74d4|worsened volume overload
75e0|uptrending weight
75ec|creatinine
766a|weight was 94kg
7690|Cr. 3.3
76a0|restarted on dopamine
76ac|restarted on lasix gtt
7705|diuresed well
776c|BPs in the ___
7896|diuresed an additional 19L
789a|Dopamine was weaned off
78a1|transferred to the floor
78b1|lasix gtt
790e|Lasix gtt was dced
79d3|started on torsemide 80mg BID
79f5|Torsemide was decreased to 80 mg ___ qdaily
7a40|net negative on qdaily dose
7a8c|dry weight upon discharge was 182 lbs
7a8f|BNP was 1117
7aac|biventricular pacer
7ab5|v paced at this time
7ac6|Hx of A-fib
7cb5|on coumadin at therapeutic range
7e72|On dig
7eb2|on metoprolol
8029|coumadin was held
80b0|Cardiac cath
82a0|it was 2.2
839e|CHADS2 of at least 2
83eb|ASA 81mg was started
8457|concomitant GI bleed
84f8|heparin gtt- bridged to coumadin
8523|uptitrated dose of coumadin
8553|INR was 1.7
86a2|therapeutic
872e|INR Was 2.7
879c|goal INR is 2.0-2.5
87e4|Counadin was held
88d0|consider 1mg alternating wtih 0.5 mg dosing
895f|Anemia
8a02|symptoms of fatigue
8a54|hx of angioectasia to the mid jejunum
8a84|Guaiac positive
8ac9|Hct 3 points lower than baseline
8c1a|taking iron
8cb8|Last colonoscopy
8d01|GI was consulted
8d97|recommended supportive care with blood transfusions
8e52|transfused 1 unit of pRBCs
8ee8|appropriate Hct elevation
8fac|GI was reconsulted
9083|underwent an enteroscopy
92c4|Normal esophagoscopy
9359|Normal stomach
9419|Normal duodenum with bile present
947f|no bleeding identified
9492|not AVM seen
95aa|did not believe he was having a significant GI bleed
95ab|HCT downtrended to nadir of 23.4
9616|transfused 1U PRBC
9640|iron studies were consistent with iron deficiency anemia
9675|startd on iron 325 mg BiD
96c9|hematocrit was 25.9
96d3|transfusion threshold for him was adjusted to > 22
9700|noted to have dysphagia to solid food
9710|obstructive pattern due to large C3 osteophyte
981d|placed on soft liquid diet with protein shakes for nutrition
98e4|without h/o of known restrictive lung disease
9931|extensive fibrotic lung changes with a pattern corresponding to NSIP
9a2e|underlying restrictive lung disease
9a6d|severe pulmonary hypertension
9aa4|progressive DOE
9b15|dysuria
9b55|> 100k E.coli
9b85|completed 7 days of ciprofloxacin 500 mg BID
9c0f|baseline creatinine 1.6-1.8
9c2c|elevated to 2.7
9c92|FeUrea 27
9ca4|pre-renal in setting of intravascular volume depletion
9cb3|poor forward flow in setting of heart failure
9dff|Creatinine improved
9f1f|Transitioned to carvedilol
9f27|changed to low dose metoprolol
a091|creatinine reached a nadir of 1.9
a0be|trended up to 3.3
a123|hypotension
a124|orthostasis
a141|inability to further diurese
a1ba|limited his renal perfusion
a22d|Cr improved to baseline
a3ee|1.8
a492|Continued on Mirapex
a502|Continued on home CPAP machine
a557|Furosemide (LASIX) 80 mg Oral take 2 tablets (160mg) twice a day
a565|Potassium Chloride 20 mEq Oral Tablet, ER 2 tablet ___
a5f4|Metolazone 2.5 mg Oral Tablet
a793|Betamethasone Dipropionate (DIPROSONE) 0.05 % Topical Cream Apply twice ___ to legs
a7a0|Digoxin 125 mcg Oral Tablet TAKE ONE TABLET ___ EVERY EVENING
a7ac|Lorazepam 1 mg Oral Tablet TAKE ___ TO 1 TABLET AT BEDTIME AS NEEDED FOR INSOMNIA
a7ef|Ferumoxytol (FERAHEME) 510 mg/17 mL (30 mg/mL) Intravenous Solution feraheme 510mg conc:30mg/ml=17ml=510mg delivered in syringe
a8f3|Magnesium Oxide 400 mg Oral Tablet TAKE ONE TABLET ___ EVERY EVENING
a8f9|Metoprolol Succinate 25 mg Oral Tablet Sustained Release 24 hr
a939|Lorazepam 1 mg Oral Tablet TAKE 1 TABLET AT BEDTIME AS NEEDED
aa9a|Simvastatin 10 mg Oral Tablet 1 tablet every evening for cholesterol
ab01|Allopurinol ___ mg Oral Tablet TAKE ONE TABLET ___
ab14|Spironolactone 25 mg Oral Tablet take ___ tablet ___
ab37|Ferrous Sulfate 325 mg (65 mg Iron) Oral Tablet 1 tablet qd
ab4e|Warfarin 1 mg Oral Tablet None Entered
ac0a|Omeprazole 20 mg Oral CpDR TAKE 2 CAPSULE ___
ad9c|Fluocinolone 0.025 % TOPICAL CREAM 0.025 % Top Crea apply TWICE ___ to legs as needed
adf3|Docusate Sodium Capsule 100MG ___ takes one bid
afc7|Mirapex tablet 0.125MG ___ (PRAMIPEXOLE DI-HCL)
b0bc|Metolazone 2.5 mg ___
b287|Allopurinol ___ mg ___
b295|Metoprolol Tartrate 12.5 mg ___ BID, hold for SBP<100 and HR<60
b2f5|Digoxin 0.125 mg ___
b2f6|Pantoprazole 40 mg ___ Q12H
b325|Docusate Sodium 100 mg ___ BID
b329|Fluocinolone Acetonide 0.025% Cream 1 Appl TP BID
b32b|Simvastatin 10 mg
b330|Furosemide ___ mg/hr IV DRIP INFUSION
b335|Senna 1 TAB ___ BID:PRN
b33a|Spironolactone 12.5 mg ___
b343|Lorazepam 1 mg ___ HS:PRN anxiety
b390|Pramipexole *NF* 0.625 mg Oral QHS Restless leg syndrome
b3ae|Losartan Potassium 25 mg ___ hold for SBP<100
b466|betamethasone dipropionate 0.05 % Cream Sig: One (1) Appl Topical BID (2 times a day).
b480|metoprolol tartrate 25 mg Tablet Sig: 0.25 Tablet ___ BID (2 times a day): may crush in applesauce.
b4b2|torsemide 20 mg Tablet Sig: Four (4) Tablet ___: can crush in applesauce.
b4b5|spironolactone 25 mg Tablet Sig: 0.5 Tablet ___: can crush in applesauce.
b4d5|ferrous sulfate 300 mg (60 mg iron)/5 mL Liquid Sig: Five (5) cc ___ BID (2 times a day).
b5ee|lorazepam 0.5 mg Tablet Sig: One (1) Tablet ___ Q4H (every 4 hours) as needed for anxiety: please give under tongue or crush in applesauce.
b658|simvastatin 10 mg Tablet Sig: One (1) Tablet ___ (___): crush in applesauce.
b6d5|allopurinol ___ mg Tablet Sig: One (1) Tablet ___ once a day: please crush in applesauce.
b6dd|acetaminophen 650 mg/20.3 mL Solution Sig: Twenty (20) ml ___ Q6H (every 6 hours) as needed for pain.
b723|aspirin 81 mg Tablet, Chewable Sig: One (1) Tablet, Chewable ___: may crush in applesauce.
b8ad|lansoprazole 30 mg Tablet,Rapid Dissolve, ___ Sig: One (1) Tablet,Rapid Dissolve, ___ ___: do not crush, can dissolve in mouth .
b937|pramipexole 0.25 mg Tablet Sig: 0.5 Tablet ___ QHS (once a day (at bedtime)) as needed for Restless leg syndrome: may crush in applesauce.
b9ad|senna 8.8 mg/5 mL Syrup Sig: Five (5) ml ___ BID (2 times a day) as needed for constipation.
b9bb|docusate sodium 50 mg/5 mL Liquid Sig: Five (5) cc ___ BID (2 times a day).
ba00|Heparin Flush (10 units/ml) 2 mL IV PRN line flush PICC, heparin dependent: Flush with 10mL Normal Saline followed by Heparin as above ___ and PRN per lumen.
ba2b|Sodium Chloride 0.9%  Flush 3 mL IV Q8H:PRN line flush Peripheral line: Flush with 3 mL Normal Saline every 8 hours and PRN.
ba3a|Extended Care Facility
bad4|acute on chronic congestive heart failure
baed|ACE held because of renal failure
bb08|Acute Blood Loss anemia
bb6f|interstitial lung disease
bc25|Acute on Chronic Kidney disease
bc4d|Coronary artery disease
bc84|Clear and coherent
bdcc|Alert and interactive
bf23|Ambulatory - requires assistance or aid (walker or cane)
c001|acute exacerbation of your congestive heart failure
c095|admitted to the CCU twice
c11b|intravenous diuretics
c161|medicines to help your heart pump better
c172|discharge and dry weight is 182 pounds
c1c2|continued to have bleeding from the malformations in your intestinal tract
c1f8|take iron supplements
c207|blood count this morning is 26
c2ef|kidneys worsened with the diuresis temporarily
c386|have now recovered
c4b5|bony deformity on your spine
c53f|impinging on your throat
c55b|causing trouble with swallowing
c589|weakness
c59e|give you only shakes to drink
c615|liquid or crushed medicines
c676|Discontinue furosemide
c6ee|Discontinue metolazone
c86f|Discontinue digoxin
c9db|Discontinue magnesium
ca0b|Change metoprolol to tartrate formulation
ca59|Start torsemide 80 mg
ca91|Decrease allopurinol to 100 mg
cb0d|Increase iron to twice
cb8b|change omeprazole to lansoprazole

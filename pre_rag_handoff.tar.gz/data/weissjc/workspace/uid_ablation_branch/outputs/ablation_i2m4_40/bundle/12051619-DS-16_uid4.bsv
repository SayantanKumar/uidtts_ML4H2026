009a|male
01e0|No Known Allergies / Adverse Drug Reactions
03a5|Dyspnea on exertion
0532|Mitral valve replacement
0565|male
05f6|complaining of dyspnea on exertion for approximately one year
06db|echocardiogram in ___ last year
0712|echo that revealed severe mitral regurgitation
07db|cardiac cath on the same day
0ac6|mitral regurgitation
0ac8|40% RCA lesion
0acc|Presents today for admission
0ed9|heparin bridge before MVR in AM
0ef8|Mitral regurgitation
0f08|Atrial fibrillation/flutter (on Pradaxa)
1251|Congestive heart failure
128e|Stroke ___ years ago
144b|Benign Prostatic Hypertrophy
1632|Anemia
163b|Colonoscopy in ___ last week
187d|benign polyps that were clipped
199d|Frequent nose bleeds, some that have required cauterization
1b1d|Bilateral hernia surgery
1ba1|Right arm surgery
1d5a|No premature coronary artery disease
1dfa|Pulse: 75
1e1c|Resp: 16
1e45|O2 sat: 99%
1e76|B/P Right: 116/60
1ef7|B/P Left: 116/83
1efd|Height: 5'8
1f6b|Weight: 212lbs
1f81|Well-developed male in no acute distress
2011|Warm
215a|Dry
2246|Intact
2355|NCAT
2480|PERRLA
2593|EOMI
259d|Supple
277e|Full ROM
2895|no JVD
28e2|Lungs clear bilaterally
28fe|no RRR
2d4f|Irregular
2dae|Murmur
2f00|Soft
304c|non-distended
325f|non-tender
32a9|bowel sounds +
35bf|Warm
36a8|well-perfused
36d1|Edema 1+
380a|None
39aa|Grossly intact
3c92|2+
3d19|2+
3d21|2+
3d58|2+
3ecc|2+
3edd|2+
3f10|2+
3f98|2+
40c3|no carotid bruit
416b|left atrium is markedly dilated
42b8|No spontaneous echo contrast is seen in the left atrial appendage
4467|No thrombus is seen in the left atrial appendage
452b|No atrial septal defect is seen by 2D or color Doppler
467d|left ventricular cavity is severely dilated
46ad|Regional left ventricular wall motion is normal
4797|Overall left ventricular systolic function is low normal (LVEF 50-55%)
47f4|Right ventricular chamber size and free wall motion are normal
4818|ascending aorta is mildly dilated
48c6|aortic valve leaflets (3) are mildly thickened
4ad2|Mild to moderate aortic regurgitation is seen
4bc5|mitral valve leaflets are moderately thickened
4c74|partial anterior mitral leaflet flail
4d96|Severe (4+) mitral regurgitation is seen
4e05|epinephrine infusion at 0.05 ucg/kg/min
4e13|Biventricular appears preserved in the setting of inotropes
508c|well seated, well functioning bioprosthesis in the mitral position
50d0|trace valvular MR
5126|Glucose-107*
52ed|UreaN-32*
56a2|Creat-0.8
56bc|Na-140
58be|K-3.2*
5b3b|Cl-98
5bdf|AnGap-13
5bef|sternotomy for mitral valve repair and CABG
5d67|Residual bilateral pleural effusions are small, right more than left
5da6|improving bibasilar atelectasis
5e84|no pulmonary edema
5eee|No pneumothorax
5f49|Significant cardiomegaly is unchanged since preop exam
5fd2|admitted one day before surgery
60af|started on Heparin due to Atrial Fibrillation history and taking Pradaxa
61a3|normal pre-operative work-up
6445|brought to the Operating Room on ___
6446|underwent a Mitral Valve Replacement
649d|tolerated the procedure well
650c|transferred to the CVICU in stable condition
6630|extubated
66f0|alert and oriented
68ab|breathing comfortably
6993|neurologically intact
6a38|hemodynamically stable
6ac5|weaned from inotropic and vasopressor support
6b50|Beta blocker was initiated
6b62|gently diuresed toward the preoperative weight
6ba6|transferred to the telemetry floor
6d64|Chest tubes and pacing wires were discontinued
7188|evaluated by the physical therapy service
71a8|discharge on POD #5
75a8|needed to walk with a walker
75da|home physical therapy
762d|wound was healing
766a|pain was controlled with oral analgesics
7734|discharged POD #5
7761|coumadin for the next month
779a|DABIGATRAN ETEXILATE [PRADAXA]
7801|Last dose of pradaxa two weeks ago
78a7|DIGOXIN
7913|FUROSEMIDE
7b07|OMEPRAZOLE
7e18|PERINDOPRIL ERBUMINE
7f84|POTASSIUM CHLORIDE
8183|TAMSULOSIN
81b3|Furosemide 20 mg PO DAILY
82af|Omeprazole 20 mg PO DAILY
8346|Potassium Chloride 20 mEq PO DAILY
8359|Tamsulosin 0.4 mg PO HS
84aa|Acetaminophen 650 mg PO Q4H:PRN pain
8617|Aspirin EC 81 mg PO DAILY
86d1|Docusate Sodium 100 mg PO BID
876d|Metoprolol Tartrate 12.5 mg PO BID
8818|Oxycodone-Acetaminophen (5mg-325mg) ___ TAB PO Q4H:PRN pain
8860|Warfarin 5 mg PO DAILY afib take as directed by Dr. ___
88ad|Warfarin 5 mg PO DAILY16 Take as directed by Dr. ___ an INR goal of ___
88ee|Home
891d|Mitral regurgitation s/p Mitral valve repair
8a6c|Atrial fibrillation/flutter (on Pradaxa)
8adf|Congestive heart failure
8b26|Stroke ___ years ago
8b55|Benign Prostatic Hypertrophy
8b5b|Anemia
8c13|Colonoscopy in ___ last week
8c2c|benign polyps that were clipped
8d4a|Frequent nose bleeds, some that have required cauterization
8e19|Bilateral hernia surgery
8edf|Right arm surgery
909e|Alert and oriented x3 nonfocal
93fa|Ambulating with walker
94e9|home physical therapy
95cf|Sternal pain managed with oral analgesics
96d6|Sternal Incision - healing well
98a0|no erythema or drainage
990f|Edema

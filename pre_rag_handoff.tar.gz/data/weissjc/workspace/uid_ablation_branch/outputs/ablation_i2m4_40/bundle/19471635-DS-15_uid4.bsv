00b2|male
00d5|No Known Allergies / Adverse Drug Reactions
00ec|New Leukemia
0122|Bone Marrow Biopsy
0125|Central Line Placement
01ac|___ yr/o
0229|M
0294|CAD (with cardiac stents)
02f1|HTN
02fc|HLD
0324|presented to ___ on ___ with fatigue
0340|shortness of breath
0341|nonproductive cough
034e|syncopal episode
048b|found to have a WBC of 0.7
04d7|ANC of 200
04de|Hct of 30.3
0562|plt count of 51,000
05ce|history of normal blood counts in ___ per ___ records
08d5|admitted for pancytopenia
0a7b|bone marrow biopsy w/ aspirate with cytogenic analysis and flow cytometery done on ___
0a93|Dx of new AML was made
0a9a|transfered to ___ for initiation of therapy
0b90|received 3 days of azithromycin at the OSH for his cough
0c2f|feeling in his normal state of health
0cb7|started working-out more in order to get in shape for a skiing trip to ___ in ___
0cd5|becoming more easily winded than normal with exertion
0e4f|having intermittent burning sensations with exertion while using the treadmil
0ec0|burning sensation was much different than the heavy feeling anginal pain he had in the past
0f11|went to ___ as planned in ___
107d|did not ski due to increasing fatigue
1115|no fevers
12e9|no chills
1351|no easy bleeding
136e|no easy bruising
1442|no blood in his stool
152a|returned from ___ last ___ by way of the ___ ___
15b3|started to develop a cough on his flight back
15ee|cough persisted/worsened in the past week
1613|non-productive
16ed|not associated with chest pain
1729|severe coughing spell
17cd|pass out at his desk
17dd|did not hit his head
192a|woken up within the next minute by co-workers
19ad|intermittent cramping in his hands and feet which happens > 1x/day
1a0d|had mild elevations in his CPK levels
1b3e|stopped his statin a few months ago for this
1b68|CPK supposedly normalized slightly with this
1b6b|cramping persisted
1c2a|occasional lower back pain
1c5b|headaches
1d16|congestion
1d4f|runny nose
1d5e|neck swelling
1d72|wheezing
1f07|orthopnea
1fb5|PND
2022|abd pain
2045|constipation
2072|diarrhea
20b4|nausea
223b|vomiting
225a|dysuria
226e|hematuria
22d3|frequency
2313|___ swelling
23db|anxiety
2540|NKDA
2645|CAD w/ stents
274b|Stents placed ___ years ago in ___ due to anginal symptoms resulting from serious occlusion of one coronary
276f|Stent a sirolimus eluting coronary stent
27f0|on plavix for some time after stent placement
2850|off plavix since ___
28da|Hyperlipidemia
2b3f|used to be on a statin but was stopped due to CPK elevations
2b4c|cholesterol was never that high
2b80|Back surgery
2ba0|for sciatic nerve compression
2bac|Surgery in ___
2bba|heart attack in ___
2bf6|heart attack in ___
2d53|breast CA
2d6f|temperature 98.7
2dd7|BP 120/76
2dd8|HR 71
2e0a|RR 18
2e0d|97% on RA
2fb4|healthy appearing middle aged male in NAD
3017|reddish skin discoloration on bridge of nose, cheeks, and chest
31c5|Mild ant cervical LAD
3239|no post cervical LAD
3291|no thyroid enlargement
3320|posterior and ooropharynx clear
3370|CTAB
3542|RRR
3553|S1
3582|S2
3670|no m/r/g
3673|soft
3695|NT
380a|ND
3881|normoactive BS
38f2|no hepatosplenomegaly
3923|2+ pulses at DP and radial bilat
3a01|no rashes or clubbing
3a74|___ strength all ext
3b11|normal gait
3b28|intact sensation all ext
3c74|no focal muscle waisting
3c9a|A&Ox3
3cca|no cerebellar dysfunction
3dbe|WBC-0.5*
3e59|RBC-3.07*
3e7e|Hgb-11.0*
3e9b|Hct-29.1*
3ec3|MCV-95
3ef8|MCH-35.7*
3f02|MCHC-37.7*
3f32|RDW-15.6*
3f42|Plt Ct-67*
3fde|Neuts-31*
408c|Bands-0
418c|Lymphs-65*
42e6|Monos-2
4333|Other-2*
435e|PTT-20.4*
4360|Glucose-104*
44ba|UreaN-20
4500|Creat-1.0
4532|Na-135
4576|K-4.3
4578|Cl-98
469e|HCO3-27
4702|AnGap-14
4773|ALT-28
478b|AST-30
47ae|LD(LDH)-204
47da|AlkPhos-79
494a|TotBili-1.0
49a6|Albumin-4.7
49e3|Calcium-9.4
4ae5|Phos-3.3
4b23|Mg-2.4
4bce|UricAcd-6.4
4c47|Iron-156
4c99|VitB12-1232*
4cc1|Folate-17.2
4d52|CATHETER TIP-IV culture
4dba|WOUND CULTURE No significant growth
4ddf|DIAGNOSIS: ACUTE PROMYELOCYTIC LEUKEMIA (APL)
4f4e|PML/RARA fusion gene present
5045|Large blast forms with Auer rods on peripheral smear
50e3|Platelet count decreased on smear
5162|Atypical promyelocytes containing several stacked Auer rods
517b|Marrow cellularity >90%
5180|Atypical promyelocytes strongly reactive for CD117, negative for CD34
5297|Abnormal cells express CD33, CD13, CD15, CD117, CD64, CD71
52bf|Abnormal cells negative for CD34, CD14, CD11c, CD41, CD56, Glycophorin A
52ea|Abnormal cells comprise approximately 42% of total gated events
5349|NORMOCELLULAR ERYTHROID-DOMINANT MARROW WITH LEFT-SHIFTED GRANULOPOIESIS AND MARKED MEGAKARYOCYTIC HYPERPLASIA
53f1|MILDLY INCREASED RETICULIN FIBROSIS
53f8|Diagnostic morphologic features of involvement by acute leukemia are not seen
544b|Significant megakaryocytic hyperplasia may represent rebound proliferation
548f|Erythrocytes severely decreased with anisopoikilocytosis
5576|Megakaryocytes markedly increased with micromegakaryocytes
55dd|Ring sideroblasts are not seen
5629|KARYOTYPE: 45,X,-Y[4]/46,XY[16]
563d|4 of 20 cells had a missing Y chromosome as the sole cytogenetic anomaly
5649|FISH evaluation for PML-RARA rearrangement NORMAL
5747|Upper dermal scar, polarizable foreign material, and minimal perivascular inflammation, consistent with site of prior injury
5810|Special stains (Gram, PAS, and AFB) are negative for organisms
5873|No hemorrhage or edema on Head CT
5888|Calcific opacity in the left lower lobe subsegmental bronchus likely represent a broncholith
58d3|Small hypodense lesions in segment ___ and ___ of the left ___ represent cysts
5905|Left atrium is normal in size
5927|Left ventricular wall thickness, cavity size, and global systolic function are normal (LVEF>55%)
595e|Focal wall motion abnormality cannot be fully excluded
59ab|Right ventricular chamber size and free wall motion are normal
5b24|Ascending aorta is mildly dilated
5b80|No pericardial effusion
5bee|Normal biventricular cavity sizes with preserved global biventricular systolic function
5c1b|No joint effusion or evidence of infection
5c70|Separation of the medial humeral epicondyle, and spurring of the coronoid represent previous injury
5d1b|Cortical defect or well-corticated erosion in the proximal ulna
5d60|Partial-thickness triceps tendon tear at olecranon insertion
5d8a|Bone marrow edema of olecranon
5d95|Diffuse edema overlying olecranon, nearly approximating olecranon bursitis
5db7|Biceps tendon is intact
5dd7|Small amount of edema surrounding the biceps tendon
5de8|Medial collateral ligament, common flexor tendon, radial collateral ligament, lateral ulnar collateral ligament and common extensor tendon are intact
5dfb|Moderate joint effusion likely reactive
5e07|Diffuse myositis involving flexor carpi ulnaris, flexor carpi radialis, and anconeus muscle
5e5e|No fracture
5e96|No large fluid collection
5ea6|Diffuse myositis evidenced by edema involving the flexor muscles; etiology unknown
5f09|Moderate elbow joint effusion
6015|Partial triceps tendon tear at the olecranon insertion with adjacent marrow edema
608b|Upper lobe vascular and mild mediastinal engorgement suggestive of cardiac decompensation
6213|No focal findings to suggest pneumonia
6214|New reticulation in the left lower lung can be explained by cardiac failure
6222|Heart size has decreased
6261|Pulmonary vascular congestion and previous minimal edema have resolved
629e|Pleural effusions are tiny if any
62d2|Lungs are clear
63f0|Skin biopsy - No growth on bacterial/fungal cultures
6407|Bursa fluid - No growth
646e|All blood/urine cultures were negative
6530|WBC-2.1*
6574|RBC-2.88*
65d7|Hgb-8.8*
66e9|Hct-25.3*
6837|MCV-88
6841|MCH-30.7
6861|MCHC-34.9
68d7|RDW-14.7
69cb|Plt Ct ___
6a64|WBC-2.8*
6b19|RBC-3.05*
6b5a|Hgb-9.3*
6b6c|Hct-27.9*
6c5d|MCV-91
6cca|MCH-30.5
6cea|MCHC-33.4
6d2e|RDW-14.9
6e22|Plt Ct ___
6e3a|Neuts-59
6f2f|Bands-1
6f54|Lymphs-9*
6f59|Monos-31*
6f7f|Eos-0
70c0|Baso-0
70fe|Neuts-45*
7107|Bands-4
712a|Lymphs-13*
7150|Monos-36*
71f6|Eos-0
72df|Baso-0
72f4|Atyps-1*
73c8|Blasts-1*
7436|PTT-24.1
7440|Glucose-139*
74dd|UreaN-13
750b|Creat-0.8
7535|Na-137
7575|K-4.9
7683|Cl-104
7698|HCO3-30
77cf|AnGap-8
7854|Glucose-139*
7881|UreaN-13
78c8|Creat-1.0
796a|Na-142
79ad|K-5.0
79cf|Cl-106
7a44|HCO3-31
7a52|AnGap-10
7b2d|ALT-38
7bd4|AST-21
7be9|LD(LDH)-155
7c4b|AlkPhos-77
7df3|TotBili-0.3
7e47|ALT-37
7ee7|AST-24
7f3e|LD(LDH)-163
7f4a|AlkPhos-79
7f54|TotBili-0.3
8024|Albumin-3.2*
804c|Calcium-8.0*
8051|Phos-2.8
809c|Mg-2.5
80c7|UricAcd-2.5*
8119|Albumin-3.2*
8124|Calcium-8.3*
823f|Phos-3.2
825a|Mg-2.3
826b|UricAcd-3.5B-glucan negative
82fa|galactomannan negative
83a8|___ yr/o
83ac|M
83d2|Hx CAD
840f|HTN
849b|HLD
84be|presenting as OSH transfer
84f0|pancytopenia
854d|concern for AML
8587|bone marrow Bx from OSH an insufficient specimen for diagnosis
8607|pancytopenia on arrival
862e|marrow bx repeated at ___
866f|findings consistent with APML
86f4|Presenting pancytopenia a good prognostic indicator
88ec|started on allopurinol
8983|received chemo w/u
89ec|CXR
8a19|EKG
8a7b|ECHO
8b6a|Line Placement
8b8c|started on ATRA 50mg BID
8c2c|received Idarubicin on days 2, 4, 6, and 8
8c64|Tolerated chemo well
8c67|side effects due to ATRA
8d6e|pressure headaches with ATRA initiation
8d8c|head CT negative for bleed x 2
8d9a|cyclic fevers
8e6a|chills
8e9f|ATRA syndrome
8ea1|resolved with dexamethasone therapy
8ec5|right arm myositis
8efc|ATRA discontinued
9004|repeat bone marrow biopsy
90d1|no evidence of APML on microscopic examination
917b|cytogenetics were also negative for t(15:17)
9205|Counts recovered
922a|discharged home with follow-up
922e|neutropenic on admission
943c|counts stayed supressed while on and in the weeks following chemotherapy
956a|fever a few days after initiation of chemo
95be|started on cefepime
96d0|fever quickly resolved
96e4|cold sores appeared on the mouth
980d|started on treatment dose of acyclovir
984d|transitioned back to prophylactic dosing
98d3|another fever
9a33|vancomycin was initiated
9b54|Fever did not break
9c4e|area around central line looked red
9cde|became slightly uncomfortable
9d03|CVL was pulled
9d29|tip sent for culture
9e06|culture was negative
9e31|successive blood cultures were negative
9ec9|Micafungin was added to anti-microbial coverage
9ee0|fevers did not defervese
a0cc|concern that ATRA was contributing to fevers and chills
a10b|concern that underlying persisting APML causing these findings
a120|No infectious source was able to be identified
a15a|antibiotics were able to be discontinued prior to discharge
a168|no more fevers
a19b|right elbow pain
a1ea|swelling
a1ed|erythema
a29b|tenderness of the right forearm
a31d|Rheumatology was consulted
a355|tapped the bursa
a3c7|no evidence of crystals or infection
a3e4|MRI was done
a42e|myositis of the forearm
a478|partial tear of the triceps tendon
a4c0|soft tissue swelling concerning for cellulitis
a58f|Orthopedics was consulted
a5ac|thought the joint was not infected based on exam
a5eb|recommended against tapping the joint
a603|ID was consulted
a62d|thought this was less likely infectious
a67f|no resolution
a733|thought this was the etiology of his symptoms
a777|ATRA discontinued
a7a4|antibiotics discontinued
a7d2|started on solumedrol
a82c|started on prednisone
a84b|marked improvement in his symptoms
a8f3|discharged home on prednisone
a98a|burning in chest with exertion recently
a9e7|not similar quality to his angina in the past
ab86|CE neg x 3 at OSH before transfer
ac3e|continued on home dose of metoprolol
acef|changed to short-acting form for better control in the hospital
ad0a|aspirin was stopped
ad36|lisinopril was continued
ada0|stopped after a few days
ae58|running lowish BPs
ae72|ECHO had showed preserved systolic function
aec5|lisinopril not absolutely indicated
af80|discharged back on his home dose of aspirin
af99|Lisinopril 10mg daily on Admission
b004|Metoprolol XL 25mg daily on Admission
b084|ASA 81mg daily on Admission
b117|Received 3 days of azithromycin at OSH
b250|metoprolol succinate 25 mg Tablet Sustained Release 24 hr Sig: One (1) Tablet Sustained Release 24 hr PO once a day.Disp:*30 Tablet Sustained Release 24 hr(s)* Refills:*2*
b289|omeprazole 40 mg Capsule, Delayed Release(E.C.) Sig: One (1) Capsule, Delayed Release(E.C.) PO once a day.Disp:*30 Capsule, Delayed Release(E.C.)(s)* Refills:*2*
b2a3|prednisone 10 mg Tablet Sig: 1.5 Tablets PO twice a day.Disp:*90 Tablet(s)* Refills:*0*
b2f0|acyclovir 400 mg Tablet Sig: One (1) Tablet PO three times a day.Disp:*90 Tablet(s)* Refills:*2*
b38a|aspirin 81 mg Tablet Sig: One (1) Tablet PO once a day.Disp:*30 Tablet(s)* Refills:*2*
b392|Home
b3d5|Acute Promyelocytic Leukemia
b445|Coronary Artery Disease
b53f|Clear and coherent
b644|Alert and interactive
b6a4|Ambulatory - Independent
b73c|admitted to the hospital to initiate treatment for your leukemia
b7c9|initial bone marrow biopsy was done to confirm the type of leukemia
b86f|found to be APML
b98a|started on chemotherapy with ATRA (all-trans retinoic acid) (daily) and idarubicin
ba4e|counts were suppressed
bae0|started on antibiotics when you developed a fever
bb3b|headaches during your admission
bb8a|received CT scans of your head
bd47|not having a bleed
bdad|These scans were normal
be2f|CT scan of your lungs normal
be93|cold sores on your mouth
bf09|treated with an antiviral medication
bf2d|second set of fevers later in your hospitalization
bfc6|respiratory distress that was due to the ATRA
c11b|resolved with steroids
c133|swelling of your right elbow/forearm
c21f|pain of your right elbow/forearm
c235|thought this was due to the ATRA as well
c28b|stopped ATRA
c348|started you on prednisone
c3e1|helped your symptoms
c447|biopsied an area of your skin
c45e|old scar
c48c|repeat bone marrow biopsy
c505|no evidence of the APML in your marrow
c562|counts recovered
c5f0|fevers went away
c65f|discharged home to follow-up with Dr. ___ in clinic regarding your further treatment
c669|prednisone 15mg by mouth twice a day
c682|Acyclovir 400mg by mouth three times daily
c7c5|Aspirin 81mg by mouth daily
c7ff|Lisinopril 10mg by mouth daily stopped

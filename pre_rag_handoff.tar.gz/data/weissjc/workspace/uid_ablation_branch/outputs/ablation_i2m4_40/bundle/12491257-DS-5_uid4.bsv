008a|male
0187|No Known Allergies to Drugs
01c0|lethargy
0242|posterior cervical laminectomy
025c|male
0272|Downs syndrome
0288|chronic hep B
03a7|admitted from group home
0422|increasing lethargy
0434|poor historian
0543|fall
05a7|seen evaluated in ___
090f|discharged
096b|head contusion
0996|slept on the floor of the group home last night
0aec|would not get up off the floor this am
0b4a|fell
0c4f|lethargic prior to fall
0ca2|more lethargic
0d15|not moving much
0ea9|talks very little
0eb7|dysarthric
0ec6|able to ambulate slowly
0f00|No known hx of F/C
10c9|t 97.5
1120|hr 72
117d|bp 99/45
11c3|rr 18
1279|sat 98% ra
1305|difficulty cooperating with the exam
131a|EKG unremarkable
1439|CXR unremarkable
144a|Head CT was neg
162d|sent for MRI/MRI
169f|refused the exam
16c6|increased erythema over R foot
17cd|given ancef 1 gm IV x 1
184c|NS x 2 L
1a21|appears comfortable
1a3c|oriented to self
1a8b|denies any pain
1ceb|denies headache
1d3f|denies CP
1f1c|denies SOB
20ab|denies abd discomfort
23de|resident in his home died
2430|two year anniversary of his mother's death
25a9|grief response
27bc|sad about his friend's death
2803|chronic hep B
282c|on adefovir
291a|no known cirrhosis
2b54|trisomy 21
2d54|rosacea
2eb2|Right eye blindness
3134|retinal detachment
3196|cataract
31ed|eczema
3386|Cholelithiasis
338c|t 98.1
3408|bp 118/68
3576|hr 74
36a3|rr 18
36b9|sat 97% ra
36c0|comfortable
36de|nad
3738|difficult to examine given unable to cooperate
37d8|superficial abrasion on forehead
37df|R cataract
38aa|left pupils reactive
395f|op - clear
3981|supple
3be4|no nuchal rigidity
3cc1|no LAD
3d41|reg
3e7f|nl S1/S2
3ecc|no murmurs appreciated
3ed6|clear bilaterally
3ef2|poor inspiratory effort
3f1c|+ bs
40d9|soft
4139|nt/nd
42c5|no edema
42dc|erythema over R great toe and distal foot
442b|warm
4528|tender to palp
4747|+ scaling over both feet
4835|tinea pedis
4840|folliculitis over abdomen
4858|two 2-3 cm erythematous macular lesions on abdomen
4877|difficult to obtain
4962|aao x 1
4a51|CN could not be assessed
4a5b|unable to cooperate with sensory or strength exams
4b42|grip strength diminished bilaterally
4b90|RUE biceps 1+
4bb1|RLE patella 2+
4c11|LUE biceps ___
4e5e|LLE patella ___
56f2|toes are downgoing bilat
571c|gait could not be assessed
587b|Na 140
5b84|Cl 103
5bad|CO2 26
5e02|Glu 152
5e19|BUN 4.4
5e7e|Cr 1.0
5e9e|Ca 9.2
5f84|Mg 2.6
5fa6|P 3.4
6080|ALT 31
6171|AP 79
62b9|Tbili 0.9
62c6|Alb 4.1
6301|AST 76
6345|LDH 295
6368|Serum ASA EtOH Acetmnphn Benzo Barb Tricyc Negative
63bc|TSH 1.2
64eb|MCV 95
676f|WBC 10.0
6802|Hgb 46.7
6956|N 89.6
6971|Band 0
6a95|L 7.1
6b02|M 2.6
6b2b|E 0.3
6c4c|Bas 0.4
6ca9|urine tox negative
6dbb|urinalysis RBCs otherwise negative
6e10|No fracture or subluxation identified
6ebb|Multilevel degenerative changes involving the cervical spine
6eda|grade 1 anterolisthesis of C4 on C5
6edd|mild-to-moderate canal narrowing at c2-3 c4-5 c6-7
707f|severe narrowing at c3-4
713a|mild-to-moderate neural foraminal narrowing at left C4-5 and right C5-6
721f|No fracture or subluxation
72bc|Multilevel degenerative changes involving the cervical spine as described above
7302|No hemorrhage
730a|Curvilinear radiodense foreign body within the retrolental right globe
73a3|No acute cardiopulmonary process
77f8|minimal degenerative changes and spurring of both hips
789e|joint spaces relatively preserved
78c1|no signs for acute fractures or dislocations
7952|degenerative changes and scoliosis of lower lumbar spine
7a5f|no acute fractures or dislocations
7b35|dystrophic calcifications within medial soft tissues
7c67|minimal spurring of left hip joint
7cd5|joint space preserved
7d6e|no acute fractures or dislocations
7d70|joint space narrowing in lateral compartment
7e81|no joint effusion
803a|vascular calcifications
8050|faint chondrocalcinosis
8115|joint spaces relatively preserved
813a|no signs of acute fracture or dislocations
8344|vascular calcifications
835f|severe degenerative change of first interphalangeal joint of right foot with osteophyte formation and joint space narrowing
836f|degenerative changes of the MTP and first TMT joint
8391|no displaced fracture or dislocation
8481|no area of lysis
84f2|dorsal calcaneal enthesopathy
851c|accessory navicular
857e|mild hallux valgus/metatarsus varus
85e3|moderate degenerative changes of first MTP and IP joints with mild hallux valgus/metatarsus varus deformity
865e|no fracture or dislocation
86c2|no lytic or sclerotic foci
8722|dorsal and plantar calcaneal spurs
877f|Down's syndrome
885c|chronic hep B
8916|presents after 2 days of increasing lethargy
8928|fall on ___
8a01|evaluated at ___ and sent home
8a16|marked pain of lower extremities
8a24|x-rays all negative for fracture
8adc|treated for cellulitis of bilateral feet
8b2c|off antibiotics
8c18|Change in mental status
8db9|onset gradual over last 48 hours
8eba|interactive since his arrival
8f5f|WBC 10.0 w/ left shift
8f84|LFTs unrevealing
9062|Utox/serum tox negative
9262|Head CT was negative
92c2|MRI not tolerated
9449|marked weakness all extremities
946b|Ammonia WNL
96f5|TSH WNL
970c|recent psychological stresses with death of his best friend
97ab|progression of his down's syndrome
998b|remained oriented and interactive
99d0|Lower extremity pain
99f2|full body weakness
9a55|decreased movement at left knee
9a5b|left hip externally rotated
9cd5|normally ambulatory
9dce|slow shuffle
9ec9|X-rays were not revealing
a004|intubated
a092|cervical MRI
a0d8|cervical stenosis
a111|posterior cervical laminectomy with decompression
a163|under general anesthesia
a19c|tolerated this well
a225|return of motor strength post op
a34c|movement of all extremities
a38e|formal motor strength evaluation is difficult to assess
a472|incision is well healed
a4a2|foley placed intraop
a551|1500cc urine
a616|bladder training has begun
a8c3|worked with physical therapy
a91f|placed in a long-term care facility
a9ad|not be able to return to his group home
a9fd|inability to care for himself now
a9ff|lamivudine and hepsera
aa25|no hx of decompensated liver disease/cirrhosis
ab59|Coags WNL
ab7e|ammonia WNL
abf6|scaling over bilateral feet
abfe|erythematous patches on abdomen
ac39|fungal infections
add7|erythema of bilateral feet c/w likely cellulitis
ae68|Redness of lower extremities likely chronic venous stasis
b07b|Vanco originally x2 days then discontinued
b0ef|lamisil cream
b17d|decub ulcer
b1ae|central skin breakdown
b339|Needs daily wound care
b343|evaluated by wound care nurse
b434|adefovir 10 mg daily
b4a9|lamivudine 100 mg daily
b5fb|doxycycline 100 mg 2 x week
b68f|senna bid
b77a|Extended Care Facility
b842|traumatic fall
b8f5|cervical stenosis
b9d0|UTI
b9e6|down syndrome
baab|fair

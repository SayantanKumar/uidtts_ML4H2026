01c1|referred from an outside hospital
028e|increasing shortness of breath
02e0|tires easily with exertion
03a1|Admitted to [**Hospital 4628**] Hospital in [**2184-10-25**]
043c|congestive heart failure
0501|found to have aortic stenosis
0538|Referred to [**Hospital1 188**] for cardiac catheterization to further evaluate her aortic stenosis
053c|Cardiac catheterization done on [**1-10**]
0670|aortic valve area of .38 cm.sq.
0770|mean gradient of 62
0a9a|peak gradient of 85
0e21|Moderate pulmonary hypertension
1014|PA pressure 48/24
10f1|1+ mitral regurgitation
126f|severe aortic stenosis
12ab|LVEDP of 19
12d1|ejection fraction of 43%
1450|referred to Cardiothoracic Surgery for aortic valve replacement
15d2|Aortic stenosis
1610|Diabetes mellitus Type 2
164d|Right hip replacement
1675|Noninsulin dependent diabetes mellitus
169b|Glucovance 5/500 one tablet twice a day
1a43|Univasc 7.5 mg once daily
1ada|lasix 20 mg every other day
1ae9|aspirin 325 mg once daily
1af1|No known drug allergies
1af2|lives alone in [**Location (un) 4628**] with five stairs
1baa|remote tobacco history
1c46|quit in [**Month (only) 359**]
1ce2|No alcohol use
1d65|Heart rate 108 and regular
1df3|blood pressure 145/76
1e72|respiratory rate 20
1fa9|height 5'2\
2009|weight 141 pounds
2047|Healthy-appearing woman
20f8|in no acute distress
2150|No lesions
2155|no rashes
217b|Pupils equal, round and reactive to light
2420|extraocular movements intact
250b|anicteric
27ce|not injected
27f0|Mucous membranes moist
2aa8|Supple
2b47|no lymphadenopathy
2c56|no jugular venous distention
2ebf|no thyromegaly
3063|Clear to auscultation bilaterally
3083|Regular rate and rhythm
3106|S1
31ba|S2
31e2|III/VI blowing murmur
3266|Soft
32e0|nontender
352a|nondistended
35a9|normal active bowel sounds
3713|no hepatosplenomegaly
3847|Warm and well perfused
3913|no cyanosis
3922|no clubbing
3b1b|no edema
3ca8|no varicosities
3e37|Cranial nerves II through XII grossly intact
3e4e|Moves all extremities
3e84|Strength 5/5 in upper and lower extremities
3f15|Sensation intact in all dermatomes
408b|Femoral 2+ bilaterally
40e0|dorsalis pedis 1+ bilaterally
4300|posterior tibial 1+ bilaterally
4606|radial 2+ bilaterally
469c|No carotid bruits were noted
47c4|White count 5.3
4833|hematocrit 43
48df|platelets 200
49cc|Sodium 138
49d5|potassium 4.9
4a45|chloride 102
4e4d|CO2 25
4e61|BUN 24
4f3e|creatinine 0.9
5158|glucose 309
5189|Rate of 91
529e|first degree AV block
53a8|intervals .22, .92, .36
560c|left ventricular hypertrophy
5860|Chest x-ray is pending at the time of physical
59a2|direct admission to the operating room on [**2-15**]
5a03|underwent an aortic valve replacement
5a4a|aortic valve replacement with a #21 mosaic porcine valve
5a95|tolerated the operation well
5b07|transferred from the operating room to the Cardiothoracic Intensive Care Unit
5b9a|did well in the immediate postoperative period
5e19|blood pressure remained somewhat labile
615e|continued on a Neo-Synephrine drip to maintain a systolic blood pressure greater than 110
61dd|slow to awaken after her anesthesia was reversed
640f|attempts to wean from the ventilator
6432|developed a respiratory acidosis
643f|remained on the ventilator throughout the day of postoperative day one
6450|remained hemodynamically stable
656f|Neo-Synephrine drip was weaned to off
66fd|weaned from the ventilator
671c|successfully extubated
679b|chest tubes were discontinued
69a2|transferred from the Cardiothoracic Intensive Care Unit to the floor for continuing postoperative care and cardiac rehabilitation
69b6|did well
6a60|activity level was increased with the assistance of Physical Therapy and the nursing staff
6cdf|remained hemodynamically stable
6da0|respiratory condition remained stable
70c9|deemed stable and ready to be transferred to rehabilitation for continuing postoperative care and physical therapy
70d3|Temperature 98.4
70da|heart rate 78 and sinus rhythm
713e|blood pressure 106/50
72be|respiratory rate 18
72bf|oxygen saturation 97% on room air
72cb|Weight preoperatively was 67 kg
72db|at discharge is 70.9 kg
7347|White count 4.1
7435|hematocrit 23
753b|platelets 144
7611|Sodium 141
7685|potassium 4.3
785c|chloride 108
797a|CO2 25
79c8|BUN 24
7ae4|creatinine 0.8
7b05|glucose 140
7b3f|Alert and oriented x 3
7be5|moves all extremities
7c78|conversant
7e6a|Scattered rhonchi with diminished breath sounds in the bases
81dd|Regular rate and rhythm
81ee|S1
823d|S2
82ab|soft systolic ejection murmur
832d|Sternum is stable
8563|Incision with staples, open to air, clean and dry
860f|Soft
86b0|nontender
8825|nondistended
89e3|normal active bowel sounds
8a4f|Warm and well perfused
8a6c|no cyanosis
8b95|no clubbing
8bf1|no edema
8c68|Ranitidine 150 mg twice a day
8ce1|enteric-coated aspirin 325 mg once daily
8cf0|Glucovance 5/500 one tablet twice a day
8d01|metoprolol 25 mg twice a day
8d05|Furosemide 20 mg once daily for 14 days
8de2|potassium chloride 20 mEq once daily for 14 days
8ee6|Colace 100 mg twice a day
8f50|Niferex 150 mg once daily
8fce|Percocet 5/325 one to two tablets every four hours as needed
90c4|ibuprofen 400 mg every six hours as needed
9290|Aortic stenosis status post aortic valve replacement with a #21 mosaic porcine valve
932d|Diabetes mellitus Type 2
95a6|Right hip replacement
97a0|Stable
9891|follow up with Dr. [**Last Name (STitle) **] in one month
9941|follow up in the [**Hospital 409**] Clinic in two weeks

006f|64-year-old
013e|male
01c2|coronary artery disease
0294|three myocardial infarctions
0579|five vessel coronary artery bypass graft
0614|multiple percutaneous transluminal coronary angioplasties
06fe|catheterization done
0767|stent placed
07c0|increased dyspnea on exertion
0ccd|chest pain
0e87|repeat catheterization
1205|narrowing of the stent
128e|ejection fraction of approximately 20%
133b|No intervention was done
145b|chest pressure radiating to the neck anginal equivalent
15ff|relieved by sublingual nitroglycerin
16a1|presented to the Emergency Department
186e|transferred to the [**Hospital6 256**]
189e|coronary revascularization
1926|Coronary artery disease
1985|Myocardial infarction x3
1ab9|Coronary artery bypass graft
1ae7|Systemic lupus erythematosus in remission
1b50|Coreg 6.25 mg po bid
1c7a|Lasix 25 mg po qd
1d14|Imdur 30 mg po qd
1e1c|K-Dur 10 milliequivalents po qd
2039|Zestril 2.5 mg po bid
2215|Multivitamin
232d|Folate
2351|no known drug allergies
254a|afebrile
255e|stable vital signs
25a8|Regular rate
2718|rhythm
27dd|2 out of 6 systolic ejection murmur heard loudest at the apex
27e5|Clear to auscultation
28d9|Soft
2962|nontender
2a00|nondistended
2a92|No cyanosis
2dc2|No clubbing
2e39|No edema
2e72|Palpable DPs bilaterally
313c|hematocrit was 44
3326|White count was 8
33a6|Potassium was 3.9
36f1|BUN was 18
3840|creatinine was 0.9
396d|troponin was 29.7
3aff|medically managed initially
3b2a|coronary artery bypass grafting x2
3bdd|mitral valve annuloplasty
3bf1|placement of intra-aortic balloon pump
3d5f|transferred to the Intensive Care Unit
3d8d|relatively stable condition
3dce|balloon pump was weaned
3f2c|transferred at 2 units of packed red blood cells
3fc2|wean off the ventilator
4130|atrial fibrillation
427d|controlled
4532|started on amiodarone
4577|converted again to normal sinus rhythm
45d3|extubated
4619|balloon pump had already been removed
491a|transferred to the floor
4f0d|Lopressor
4f9e|amiodarone
4fcb|normal sinus rhythm
5008|do extremely well
5158|Physical therapy was consulted
5395|ambulating extremely well with minimal assistance
5502|afebrile
557e|stable vital signs
558e|Lopressor at 25 mg po bid
5703|amiodarone dose
58b6|left chest tube was discontinued
58db|right chest tube was removed
58fc|afebrile
5a82|stable vital signs
5b99|ambulating to a level 5 with physical therapy
5c55|wishes to be discharged home today
5c61|Stable
5c98|Coronary artery disease
5ec0|Mitral valve regurgitation
60cd|coronary artery bypass graft x2
60f5|mitral valve annuloplasty
6299|Coronary artery disease
6377|Myocardial infarction x3
63b7|Coronary artery bypass graft
644e|Lopressor 25 mg po bid
685b|Amiodarone taper 400 mg po tid x4 days, then [**Hospital1 **] x7 days, qd x7 days, then 200 mg po qd
6883|Lasix 20 mg po qd
6a12|K-Dur 20 milliequivalents po qd
6a4a|Aspirin 81 mg po qd
6b62|Percocet 1 to 2 po q 4 to 6 hours prn
6cf4|Colace 100 mg po bid
6e8b|Percocet
6eda|Protonix 20 mg po qd
6ff4|follow up with Dr. [**Last Name (Prefixes) **] in approximately three weeks
70a9|follow up with his primary care doctor, Dr. [**Last Name (STitle) **], in approximately three weeks

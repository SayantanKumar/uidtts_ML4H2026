008e|allergy to cefazolin
00d7|Anaphylaxis
0185|urethral stricture
01ca|cystoscopy cold knife urethrotomy
01e8|placement of a foley catheter
0269|cystoscopy retrograde pyelogram right
0393|cystoscopy cold knife urethrotomy
03d7|right-sided flank pain
06a7|urethral stricture
091f|possible right ureterocel
0973|cystoscopy
0998|hypotension
0a5a|tachycardia
1079|hypoxia
1163|crampy abdominal pain
1219|CT showed right ureterocele
134c|right atrophic kidney
1441|underwent an elective cystoscopy and urethral stenting
1458|persistent urethral stricture
15d1|given rocuronium for paralysis
164d|ancef prophylactically
167f|tachycardic to the 110s
1714|hypotensive with SBP ___
1a97|o2 sat down to ___
1bad|intubated for airway protection
1c4c|started on epi boluses
1ce0|transitioning to epi gtt @0.15
1d12|given 100mg hydrocortisone
1ea2|albuterol
1fac|BP responded to the epinephrine
2152|monitored in the PACU
2257|transferred the floor intubated
2274|intubated with stable hemodynamics on epi gtt
22be|unobtainable from the patient
23c4|observed in the PACU
24aa|discharged with foley in place
2665|reported feeling well
268c|needing to urinate
270f|denied any pain
27f7|denied SOB
282d|urethral stricture
28e5|trouble urinating
2977|partially aborted
2ab6|atrophic right kidney
2bef|HSV1
2cf6|HSV2
2d2d|Pelvic pain
2e30|Scrotal pain
2e51|intermittent testicular discomfort, right greater than left
2ece|no swelling
3260|denies a trigger for this
32ae|Renal scarring
362d|Herpes simplex
3898|IgG + for HSV-1
3904|IgG + for HSV-2
392a|Right ankle swelling
3961|Overweight
3bb7|History of tobacco use
3e3a|History of chickenpox
3eec|Recurrent fever
3fcb|Hematuria
4063|Rectal bleeding
40da|Bleeding has stopped
4161|EBV infection
42fc|chronic kidney disease
43df|cancer
441d|WDWN
44b8|NAD
4578|AVSS
46af|Abdomen soft
47d5|non-distended
491a|Foley in place
4a01|Bilateral lower extremities w/out edema
4b25|without pitting
4bbc|without pain to deep palpation of calves
4c54|WBC 10.3
4c5e|RBC 5.23
4d10|Hgb 15.0
4dea|Hct 43.4
4e61|MCV 83
5065|MCH 28.7
50b5|MCHC 34.6
5136|RDW 12.9
5299|RDWSD 38.9
53be|WBC 29.4
53d7|RBC 6.19
5441|Hgb 18.1
5460|Hct 51.7
54d1|MCV 84
5564|MCH 29.2
5673|MCHC 35.0
58a0|RDW 13.0
590b|RDWSD 38.9
5a95|Neuts 68.7
5b19|Lymphs 18.4
5c08|Monos 12.4
5d0a|Eos 0.1
5dae|Baso 0.1
5e07|AbsNeut 7.10
5e95|AbsLymp 1.90
6012|AbsMono 1.28
6389|AbsEos 0.01
6505|AbsBaso 0.01
6535|PTT 30.2
65d2|Glucose 80
65fa|UreaN 11
6772|Creat 1.0
6931|Na 138
699a|K 4.2
6a01|Cl 105
6a0e|HCO3 26
6b70|AnGap 11
6b9e|Glucose 337
6ca7|UreaN 11
6e25|Creat 1.2
6e30|Na 135
6ef0|K 3.3
6f07|Cl 103
6f12|HCO3 21
6f34|AnGap 14
6fed|ALT 17
7112|AST 14
7370|AlkPhos 49
7528|TotBili 0.3
7555|Calcium 8.8
769b|Phos 4.1
76ce|Mg 1.4
7724|Calcium 8.3
781d|Phos 3.6
7860|Mg 1.7
7867|pO2 80
7942|pCO2 48
7958|pH 7.38
7b3d|calTCO2 29
7b44|Base XS 1
7cd2|pO2 80
7cdd|pCO2 40
7d09|pH 7.35
80ce|calTCO2 23
80d6|Base XS -3
813b|Lactate 1.0
819a|No MRSA isolated
82d5|taken to the operating room theatre
85fd|right-sided flank pain
8602|urethral stricture
8713|possible right ureterocele
879d|perioperative antibiotic porphylaxis
87bc|underwent cystoscopy
87e9|cold knive urethrotomy
8972|placement of Foley catheter
8b04|apparent anaphylaxis reaction
8ba6|given rocuronium for paralysis
8bf9|ancef prophylactically
8c62|tachycardic to the 110s
8cc2|hypotensive with SBP ___
8cce|o2 sat down to ___
8eb6|intubated for airway protection
8f00|started on epi boluses
8f3a|transitioning to epi gtt @0.15
906e|given 100mg hydrocortisone
90e2|albuterol
923d|BP responded to the epinephrine
9309|monitored in the PACU
937b|transferred the floor intubated
962d|intubated with stable hemodynamics on epi gtt
972d|weaned off
99f0|extubated without incident
9afb|monitored for 24 hours
9c74|no recurrence of his anaphylactic reaction
9dc0|follow-up with allergy as an outpatient
9e48|Foley catheter care and leg bag teaching was provided by nursing
9eef|unremarkable
a055|discharged in stable condition from the MICU
a068|eating well
a08e|ambulating independently
a09b|pain control on oral analgesics
a0a7|follow-up in one week for post-operative evaluation and trial of voiding
a165|discharged with an epipen
a18d|NONE
a253|NKDA
a2e1|Ciprofloxacin HCl 500 mg PO Q12H
a3c3|Docusate Sodium 100 mg PO BID
a419|Senna 8.6 mg PO BID
a468|Bacitracin Ointment 1 Appl TP QID
a5a2|Hydrocodone-Acetaminophen (5mg-325mg) 1 TAB PO Q6H
a5d6|EPINEPHrine (EpiPEN) 0.3 mg IM ONCE
a628|Acetaminophen 650 mg PO Q6H
a7bb|Home
a849|right-sided flank pain
a8bd|urethral stricture
aa46|possible right ureterocele
ae54|anaphylaxis reaction
ae9a|anaesthesia vs antibiotic
af19|Clear and coherent
b027|Alert and interactive
b194|Ambulatory - Independent
b1e2|allergic reaction to either rocuronium or anceph

011d|M
03ba|2.252 kg
0549|35-1/7 week gestation
05e9|born
06fb|Blood type O+
07f0|antibody negative
07ff|rubella immune
0c75|RPR nonreactive
0d59|hepatitis B surface antigen negative
0e2a|group beta Strep positive
0ebd|delivered by repeat cesarean section
101d|emerged with good tone
10a0|emerged with good color
129c|emerged with good cry
1380|Apgars were eight at one minute
13f7|Apgars were nine at five minutes
13fc|admitted to the Neonatal Intensive Care Unit
14dd|treatment of prematurity
165a|Weight 2.252 kg
1928|length 46 cm
1cb0|head circumference 33 cm
1d81|nondysmorphic
1db4|preterm 35 week gestation male
1e0f|Color pink in room air
2006|Anterior fontanel open
207b|Anterior fontanel level
2385|Anterior fontanel soft
24df|Sutures are proximated
2667|Positive red reflex bilaterally
2731|Palate intact
2a73|Mild retractions
2b9b|occasional grunting
2d3b|Breath sounds equal
2ed2|good aeration
357f|Regular rate and rhythm
359c|no murmur
36ea|Pulses +2
37d1|Abdomen is soft
39c1|Abdomen is nontender
3b2b|no masses
3b3b|no hepatosplenomegaly
3bfa|Normal male
3d4a|testes descended
3d4d|Hips stable
3faf|moving all
43ce|Spine intact
43ec|Appropriate tone
43fb|Appropriate reflexes
4510|required some intermittent blow-by oxygen
4544|remained in room air
4753|grunting noted on admission resolved
4906|did not have any episodes of spontaneous apnea
49f1|did not have any episodes of bradycardia
4a97|No murmurs were noted
4ce6|normal heart rates
4eb9|normal blood pressures
4ffd|Enteral feeds were started
50db|advanced to full volume
52c9|required some gavage feeds
5401|has been all po
55ee|taking Enfamil 20 calories/ounce with iron
5659|Discharge weight is 2.37 kg
5721|head circumference 32 cm
580a|length 47 cm
595e|evaluated for sepsis
59d0|complete blood count
5ae1|white blood cell count of 13,800
5d26|17% polys
5d7f|0% bands
6074|white count of 13,000
6378|50% polys
6402|0% bands
64be|blood culture obtained
64f3|no growth at 48 hours
6574|Peak serum bilirubin occurred
6686|total of 10.0/0.3 direct
6730|repeat bilirubin was 8.0/0.3 direct
6894|Hematocrit at birth was 43.8%
6bf9|did not receive any transfusions of blood products
6ea5|maintained normal neurological examination
7068|no concerns at the time of discharge
7155|Audiology hearing screening was performed
71f6|passed in both ears
724c|Good
7520|Home with parents
7533|Adlib po Enfamil with iron
760a|No medications
7760|Car seat position screening was performed successfully
7781|State Newborn Screen was sent
790a|elevated 17-OH
7a13|subsequent sample was done
7ad6|results are pending
7b4f|Hepatitis B vaccine was administered
7ba6|Synagis RSV prophylaxis should be considered
7c35|Influenza immunization should be considered
7c79|Primary pediatrician recommended
7c89|35-1/7 week gestation
7c9d|Twin #2 of twin gestation
7cd9|Transitional respiratory distress
7dfd|Suspicion for sepsis ruled out

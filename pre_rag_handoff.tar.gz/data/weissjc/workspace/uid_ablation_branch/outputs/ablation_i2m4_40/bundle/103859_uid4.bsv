001e|Admission Date
00c1|Discharge Date
010e|Date of Birth
0165|Sex F
0193|Allergies Morphine
0279|Allergies Latex
034b|GIB
04ab|hematemesis
0522|EGD with esophageal varices sclerosis
05e2|42 year old
0679|female
086a|h/o cholangiocarcinoma
08c8|dx in [**2112**]
08f4|s/presection
0a17|recent CT showing met cholangiocarcinoma
0a43|met cholangiocarcinoma in9/[**2115**]
0c0f|fever due to cholangitis on[**11-8**]
0c97|chemo CDDP
0d1c|chemo Gemcitabine
0e97|intermittent nausea
0f02|zofran
0f71|compazine
1074|nausea
10c8|vomitting
13a9|sizable amount ofhemoptysis
1444|clots
1469|low grade fever
14b9|shaking chills
1683|chest pain
171c|SOB
17fb|coughing
1a6e|constipation
1a8b|diarrhea
1af1|tarry stools
1b52|abd pain
1bb1|gaining 30lbs
1be1|ascites
1bed|T98.8
1dd1|P98
1ec9|BP136/68
1f40|R29
1fa8|Sat 98% RA
1fee|NG lavagewhich evantually cleared up
2075|transfused 1U PRBC
2085|zofran
208f|iv protonix
20e5|painless jaundice
21b0|L liver lobe
2381|biliary tree
2384|portalvein
23a9|cholangitis
2438|treated with antimicrobialtherapy
245f|recurrence of the tumor
24a4|occlusion of her portal vein
258b|hepatic artery nearly completely occluded
25be|ascites
2647|started on diuretics
269c|metastaticcholangiocarcinoma with mets to the ovaries
26cd|obstructiveuropathy on the right side
2762|questionable gastricoutlet obstruction
2796|peritoneal carcinomatosis
27c0|cholecystectomy at age 25
27e6|MVA
2816|multiple orthopedic procedures
28c5|Strabismus
2904|nurse
2937|alcohol
295a|drugs
2ae9|tobacco
2b13|single
2bac|no children
2bf5|breast cancer
2c07|stomach cancer
2e02|afebrile
2fa2|96
3014|108/51
3063|O2sat99%RA
30f4|jaundicedskin
3185|sclera icteric
3292|OP clear
336b|EOMI
33b2|PERRL
34c6|Supple
351a|supraclavicular lymphadenopathy
3579|submandibular lymphadenopathy
3680|axillary lymphadenopathy
37de|inguinallymphadenopathy
3a53|Clear to auscultation bilaterally
3a6a|Regular rate
3bb5|s1 s2
3c22|soft
3c92|distended
3cb1|no actual tenderness
3cdc|No CVA tenderness
3d12|No clubbing
3d4a|no cyanosis
3d60|+edema
3d8e|GLUCOSE-112*
3f0e|UREA N-14
401d|CREAT-0.8
406a|SODIUM-133
40bd|POTASSIUM-4.0
4163|CHLORIDE-97
420a|TOTAL CO2-23
4225|ANION GAP-17
4257|ALT(SGPT)-149*
437e|AST(SGOT)-83*
4462|ALK PHOS-663*
4474|AMYLASE-37
44b5|TOT BILI-8.2*
44e6|LIPASE-42
4530|IRON-52
45d4|calTIBC-230*
463d|FERRITIN-197*
46cd|TRF-177*
471a|WBC-3.0*
49c6|RBC-2.25*
4a67|HGB-7.2*
4ab9|HCT-20.9*
4ae5|MCV-93
4b95|MCH-31.8
4bd1|MCHC-34.3
4c3e|RDW-14.7
4c7c|NEUTS-79.7*
4ccc|BANDS-0
4da4|LYMPHS-13.3*
4ded|MONOS-4.6
4fca|EOS-2.2
4fda|BASOS-0.2
5056|HYPOCHROM-1+
52b3|ANISOCYT-NORMAL
534d|POIKILOCY-1+
537c|MACROCYT-NORMAL
53b7|MICROCYT-NORMAL
54b8|POLYCHROM-NORMAL
55ac|OVALOCYT-1+
56b6|PLT COUNT-88*
5702|PT-13.4
58a5|PTT-25.9
58d1|INR(PT)-1.1
5913|RET AUT-0.3*
593c|COLOR-Amber
5941|APPEAR-SlHazy
5956|SP [**Last Name (un) 155**]-1.025
595d|BLOOD-NEG
59db|NITRITE-POS
5ba8|PROTEIN-30
5ba9|GLUCOSE-NEG
5cb1|KETONE-TR
5d7c|BILIRUBIN-LG
5e92|UROBILNGN-0.2
5fa3|PH-5.5
60a9|LEUK-NEG
60e1|RBC-0-2
6178|WBC-0-2
61aa|BACTERIA-MOD
625d|YEAST-NONE
6387|EPI-[**3-22**]
63ef|RENAL EPI-0-2
63f2|HYALINE-0-2
641d|CT abd on [**2115-11-7**]
64c4|Recurrent cholangiocarcinoma
6514|intrahepatic bile duct dilatation
65ac|gastric outletobstruction
662e|exact extent of disease is unclear, but likelyextensive
6689|No evidence of portal hypertension is seen
66a8|Large,cystic, multiseptated mass arising from the adnexa
6760|second primary malignancy
67c9|Ascites
688c|intraperitoneal carcinomatosis
68ab|Hiatalhernia
692f|WBC-2.2*
693c|RBC-3.09*
696b|Hgb-9.6*
6ac5|Hct-28.7*
6c7e|MCV-93
6d55|MCH-31.2
6d98|MCHC-33.6
6dd2|RDW-17.0*
6ddd|Plt Ct-89*
6ec6|Neuts-89.7*
6f6b|Bands-0
6fa0|Lymphs-6.9*
7136|Monos-2.6
719c|Eos-0.2
73dd|Baso-0.7
7423|PT-15.2*
74ad|PTT-29.7*
74c2|INR(PT)-1.5
74cc|Glucose-117*
7530|UreaN-11
756c|Creat-0.9
761b|Na-135
7625|K-3.5
766d|Cl-97
76ef|HCO3-28
778a|AnGap-14
7890|AlkPhos-431*
7a8f|TotBili-7.8*
7ada|Calcium-8.3*
7b43|Phos-3.5
7b69|Mg-1.9
7c63|calTIBC-230*
7cfb|Ferritn-197*
7eab|TRF-177*
7ed5|Hct of 20
7f23|bloody NG lavage whichdid not clear
7ff3|transfused 1U PRBC
81b6|zofran
8491|iv protonix
849c|admitted to the [**Hospital Unit Name 153**]
8681|EGD which revealed grade III esophagealvarices
87c9|signs of old bleeding
8845|started onoctreotide
8899|nadolol
8a60|portal htn
8ae7|stable
8b57|Hct bump to 25 after 2U PRBC's
8b73|climbing bilirubin
8bcd|low grade temp
8cf4|started on Zosyn
8d02|suspected biliary obstruction
8e6b|ascendingcholangitis coverage
9032|rescoped on [**11-18**]
917b|varices weresclerosed
9275|no banding due to latex allergy
93ca|lasix readded
93cc|aldactone readded
9418|ascites
9534|BP stable
95b5|transfused another 3U PRBC's
95e0|hct bump to 31.9
967e|antibiotic coverage broadend to Unasyn
9698|Ceftriaxone
97eb|Flagyl
98fc|continued to spike
992d|SBP prophylaxis
99ec|Preprocedure of PTC on [**11-20**]
9a03|transfused 1 unit PRBC's
9bac|2 platelets
9c6f|2U FFP
9ce8|procedure went without complication
9d6c|hemodynamically stable
9de9|stable Hct
9eb2|declining bilirubin
9fc0|afebrile
9ffd|antibiotic regimen was weaned to only levofloxacin
a053|repeat EGD with non latex banding in[**7-27**] days
a0dc|went home on naldolol 20mg qd for portalhtn
a0f9|home doses of diuretics to control her ascites
a1b0|Rhydronephrosis
a26b|R adenexal mass on her US
a2b7|no intervention was done
a33e|second primary maligancy
a5fb|seen on a prior CT scan
a7fc|nointervention made at this time
a82e|Lasix 40 mg p.o. b.i.d.
a8c1|Aldactone 25 mgp.o. b.i.d.
a902|Prilosec 20 mg p.o. daily
a981|ciprofloxacin 250 mgp.o.daily
aa20|iron
aa51|Pantoprazole Sodium 40 mg Tablet, Delayed Release (E.C.) Sig: One (1) Tablet, Delayed Release (E.C.) PO Q12H (every 12 hours). Disp:*60 Tablet, Delayed Release (E.C.)(s)* Refills:*2*
aa57|Furosemide 40 mg Tablet Sig: One (1) Tablet PO BID (2 times a day). Disp:*60 Tablet(s)* Refills:*2*
aa99|Spironolactone 25 mg Tablet Sig: One (1) Tablet PO BID (2 times a day). Disp:*60 Tablet(s)* Refills:*2*
aafb|Levofloxacin 500 mg Tablet Sig: One (1) Tablet PO Q24H (every 24 hours). Disp:*30 Tablet(s)* Refills:*0*
ab8c|Ursodiol 300 mg Capsule Sig: One (1) Capsule PO TID (3 times a day). Disp:*90 Capsule(s)* Refills:*2*
ad36|Prochlorperazine 10 mg Tablet Sig: One (1) Tablet PO Q6H (every 6 hours) as needed. Disp:*30 Tablet(s)* Refills:*0*
ad63|Nystatin 100,000 unit/mL Suspension Sig: Five (5) mL PO four times a day: Swish and swallow. Disp:*qs mL* Refills:*2*
af03|Nadolol 20 mg Tablet Sig: One (1) Tablet PO once a day. Disp:*30 Tablet(s)* Refills:*2*
af33|CBC
b02c|alkaline phosphatase
b066|total bilirubin checked on Monday [**11-25**]
b0a2|Home With Service
b0d4|Cholangiocarcinoma
b1cf|Biliary obstruction
b2a7|Grade III esophageal varices
b305|Stable
b320|increasing nausea
b339|vomiting
b3ba|legswelling
b444|confusion
b548|pain
b6f6|follow up at all scheduled appointments
b762|Wednesday in [**Hospital **] clinic
b7aa|banding procedure in 9 days
b862|see Dr. [**Last Name (STitle) 2161**] for anappointment

027c|Sex M
02f5|No Known Allergies / Adverse Drug Reactions
059e|IPH
0613|Left EVD placement
06e0|Left EVD re-placement
07cd|Angiogram with embolization of AVM feeder vessel
07dd|Right Craniotomy and clot evacuation
086c|Right Decompressive Hemicraniectomy
098f|IVC filter placement
09a3|male
0a53|incarcerated
0a9c|presented with severe headache
0b3e|vomiting
0bde|sudden onset headache
0cc7|left facial droop
0cf0|able to converse
0d90|unable to participate in a full exam
10bf|not involved in anyaltercation
10f5|noncontrast head CT
1223|IVH
12d3|right parietal IPH
132c|CTA head
1410|raised concern for vascular malformation
141b|transferred to ___ for further evaluation
16f6|Neurosurgery was consulted
1751|non-contributory
19c8|Intubated
1a1d|Opens eyes to painful stimuli
1cb8|Makes no sounds
1cba|Flexion/ withdrawal to painful stimuli
1ce2|GCS ___
1e97|30 mL or Greater
2141|Present
2283|No
22c4|Less than ___ years old
237c|sedation held for 10 minutes
23aa|Intubated
2402|Eye opens to noxious briefly
24fd|Pupils 3mm reactive bilaterally
250f|Right upper extremity withdraws to noxious
2515|Left upper extremity extends to noxious
25b4|Bilateral lower extremity withdraws to noxious
26a3|Right greaterthan left
27e5|spontaneous
281b|Person
2984|Place
2b7a|Time
2d2b|Complex
2d56|6-5mm
2ede|6-5mm
2f03|Full
3041|Yes
30b6|Yes
35b8|unable to assess due to LUE plegia
35d4|Yes
3602|Yes
3687|4+
36e8|5
3787|5
38bf|5
38c9|*
38fa|*
3a28|*
3c90|*
3cf8|LUE plegic
3d35|contracted
3ed3|5
40d2|5
4271|___
43e6|5
43e8|plegic
4439|in dorsiflexion boot
44f1|Clean
4696|dry
47e9|intact
47f9|Removed today
48c6|all but 3 staples at approximately mid incision just anterior to apex of head
48dc|IPH
48e7|IVH
4a53|AVM
4b4d|admitted to the ICU
4bdc|R IPH
4c0c|IVH
4dd8|L EVD was placed emergently
4e8c|EVD began to be dysfunctional
4f86|given mannitol
4fcf|started on hypertonic saline
501d|L EVD was replaced
505c|stopped draining
510f|remained functional with good waveform
5229|taken to the angio suite
5243|cerebral angiogram
52e0|partial embolization of his AVM
537d|AVM will require definitive treatment in the future
5396|taken to the OR
5500|R craniectomy
55fc|clot evacuation
57a8|remained intubated
57b1|transferred back to the neuro ICU
57eb|Postoperative portable head CT scan
5895|post-operative changes
597e|without new hemorrhage
5a83|ICPs were elevated
5ba7|portable CT of the head
5cfa|increased edema
5e19|started on hypertonic saline
5e43|persistently elevated ICPs
5e47|taken emergently to the OR
5e61|R decompressive hemicraniectomy
5e69|Subgaleal JP drain was left in place
5e9f|removed
5eb8|Drain was removed
5f25|post-pull head CT remaining stable
61a1|EVD clamp trial was initiated
62aa|underwent a CT head
6396|stable ventricle size
643f|EVD was removed
6541|remained on hypertonic saline
655f|slowly titrated down
66c2|serum sodium levels were checked frequently
6730|remained stable
675d|Hypertonic saline was tapered to off
679e|transferred to the ___
67b5|remained neurologically stable
68bf|transferred to the floor
69ec|staples from all procedures were removed
6a13|3 staples were left at mid-incision
6a95|maintain wound closure
6b5c|Hyponatremia
6c5c|started on salt tablets
6c7b|florinef
6ced|maintain normal sodium
6d05|serum sodium levels remained stable
6d19|medications were slowly titrated down
6d35|discharged with 6 remaining doses of 1 gram sodium tablets TID
6d41|Respiratory failure
6eaa|intubated upon admission
6f0e|successfully extubated
71d8|Pneumonia
72a0|treated with a course of antibiotics
739a|ventilator associated pneumonia
73e8|started on tube feeds
7412|self d/c his NGT
76bd|evaluated by the SLP
77ec|nutrition
77f8|diet was advanced to regular with thin liquids
7805|evaluated by ___
7967|recommended acute rehab needs
796d|discharged to ___
7a99|acute rehab
7ec9|locked unit
7f02|Dysphagia screening before any PO intake Yes
8033|DVT prophylaxis administered Yes
82a2|No
8309|non-smoker
833d|Stroke Education given in written form Yes
8552|Assessment for rehabilitation and/or rehab services considered Yes
858d|___ performed within 6hrs of arrival Yes
85d8|No
85f6|not indicated
8611|Nimodipine given Yes
8759|None
8763|Acetaminophen 325-650 mg PO Q6H:PRN Pain - Mild/Fever
876d|Bisacodyl 10 mg PO/PR DAILY:PRN Constipation - Second Line
8777|Docusate Sodium 100 mg PO BID
87de|Heparin 5000 UNIT SC BID
88fe|LevETIRAcetam 1000 mg PO BID
8930|Ondansetron 4 mg IV Q8H:PRN vomiting
896a|OxyCODONE (Immediate Release) 5 mg PO Q6H:PRN Pain - Moderate
8975|Polyethylene Glycol 17 g PO DAILY:PRN Constipation - First Line
8a96|Ramelteon 8 mg PO QHS insomnia
8aa2|Senna 8.6 mg PO BID
8aa8|sevelamer CARBONATE 800 mg PO TID W/MEALS
8aeb|Sodium Chloride 0.9%  Flush 10 mL IV DAILY and PRN, line flush
8b5c|Sodium Chloride 1 gm PO TID Duration: 6 Doses
8bb6|Extended Care Facility
8bd6|IPH
8cce|IVH
8d0d|AVM
8d5b|Pneumonia
8dc4|Respiratory Failure
8ec1|Dysphagia
8f5e|Confused - sometimes
8f6a|Alert and interactive
90eb|Out of Bed with assistance to chair or wheelchair
9147|surgery (craniectomy) to remove a portion of your skull to allow the brain to swell
91a2|use your helmet at all times when out of bed
92cb|avoid heavy lifting
92f1|running
938d|climbing
9466|other strenuous exercise until your follow-up appointment
94b9|leisurely walks
9528|slowly increase your activity at your own pace
957f|shower
95f3|No driving while taking any narcotic or sedating medication
979b|experienced a seizure while admitted
97a9|refrain from driving
97f3|Resume your normal medications
97fb|begin new medications as directed
981c|take any blood thinning medication (Aspirin, Plavix, Coumadin) until cleared by the neurosurgeon
99a2|discharged on Keppra (Levetiracetam)
9e4b|helps to prevent seizures
9eb1|continue this medication until follow-up
9eef|take this medication consistently and on time
9f16|use Acetaminophen (Tylenol) for minor discomfort
9f2f|smoke and have not stopped smoking yet
a00a|Mild to moderate headaches that last several days to a few weeks
a106|Difficulty with short term memory
a1a2|Fatigue is very normal
a211|Constipation is common
a46a|drink plenty of fluids
a50f|eat a high-fiber diet
a524|taking narcotics (prescription pain medications)
a759|over-the-counter stool softener
a77f|Severe pain
a7a2|swelling
a81d|redness
a83d|drainage from the incision site or puncture site
a86b|Fever greater than 101.5 degrees Fahrenheit
a8c6|Constipation
a935|Blood in your stool or urine
aa72|Nausea and/or vomiting
aadd|Extreme sleepiness and not being able to stay awake
ab4c|Severe headaches not relieved by pain relievers
abb5|Seizures
abcb|Any new problems with your vision or ability to speak
acbe|Weakness or changes in sensation in your face, arms, or leg
ad35|Sudden numbness
ad92|weakness in the face, arm, or leg
ad94|Sudden confusion or trouble speaking or understanding
ad9f|Sudden trouble walking, dizziness, or loss of balance or coordination
ae2c|Sudden severe headaches with no known reason

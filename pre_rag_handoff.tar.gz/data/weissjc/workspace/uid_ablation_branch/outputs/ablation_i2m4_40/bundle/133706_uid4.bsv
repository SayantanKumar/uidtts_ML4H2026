0075|Sulfa (Sulfonamides)
019c|Penicillins
03c6|s/p Pedestrian struck by auto
0925|Open reduction and internal fixation of right tib/fib fractures
0933|17 year old
0d76|male
0da9|pedestrian
0ee7|struck by auto at unknown speed
0f98|+LOC
103e|medflighted to Hospital1 18 for ongoing trauma care
1134|GCS 15
121a|alert
1263|oriented x3
13cf|Attention deficit disorder
14b0|High school student
15fb|parents
16ba|siblings
1835|GLUCOSE-101
19a8|LACTATE-2.9*
1b12|NA+-142
1c0b|K+-3.6
1dc5|CL--102
1ed1|TCO2-26
2079|UREA N-12
213c|CREAT-1.0
216b|AMYLASE-44
220f|ASA-NEG
2258|ETHANOL-NEG
2514|ACETMNPHN-NEG
25d0|bnzodzpn-NEG
25eb|barbitrt-NEG
2a0d|tricyclic-NEG
2a47|WBC-16.0*
2a67|RBC-4.89
2c66|HGB-14.5
2e3e|HCT-40.4
2f30|MCV-83
2f8d|MCH-29.7
2fec|MCHC-35.9*
322a|RDW-13.4
33f7|PLT COUNT-247
35be|PT-12.7
3672|PTT-23.8
37ed|INR(PT)-1.1
3969|linear nondepressed right temporal calvarial fracture extending into the mastoid process
39bf|small subdural hematoma with components of pneumocephalus tracking from the mastoid air cells
3b03|no shift of normally midline structures
3c1a|left occipital scalp contusion
3e39|no associated skull fracture
3fc8|No other acute fractures are appreciated
402e|small amount of mucosal thickening in the sphenoid sinuses
4039|No air-fluid levels to suggest occult facial fractures
4060|Orbits are unremarkable
41b4|Linear right temporal calvarial fracture extending into the mastoid process with small associated right posterior convexity subdural hematoma and pneumocephalus
4200|lung apices are clear without pneumothorax
4211|upper ribs are intact
43c0|linear right temporal calvarial fracture extending into the right temporal bones
4846|Multiple posterior right-sided mastoid air cells are opacified with blood
4920|No acute cervical spine fracture
4a4a|post-op fever
4a7d|Postoperative fever
4b33|heart is of normal size
4bb9|Mediastinal and hilar contours are within normal limits
4bf2|lung fields are clear
4c48|no pleural effusions or focal consolidations
4c6f|no evidence of CHF
4d35|No evidence of significant abnormality
4dc0|intramedullary rod is seen fixating a proximal diaphyseal comminuted tibial fracture with six proximal and two distal screws
4e4b|side plate is seen medially fixating the fracture
4e64|non-displaced comminuted fracture of the proximal fibula diaphysis
4ead|surrounding soft tissue swelling
4faf|Os trigonum is visualized
503f|Comminuted proximal tibiofibular fractures status post ORIF of the tibia with an intramedullary rod and side plate
505a|No evidence of immediate hardware complication
509f|pneumocephalus
514a|pneumocephalus
5168|previously noted subdural hemorrhage in the right posterior fossa appears less conspicuous
51a4|pneumocephalus adjacent to the linear skull fracture appears to have decreased in size
51b1|persistent bifrontal and right parietal hemorrhagic contusions with surrounding edema
54f5|possible small left frontal subarachnoid hemorrhage (adjacent to falx)
565c|no shift of normally midline structures or hydrocephalus
56a6|ventricles, cisterns and sulci are normal
58b7|air-fluid level in the right sphenoid sinus and bilateral opacification of the mastoid air cells are unchanged
5a4c|Decreased size of right posterior subdural hemorrhage
5ae3|Multifocal hemorrhagic contusions and surrounding edema are largely unchanged
5b89|admitted to the trauma service
5bf4|Orthopedics consulted
5e0f|Neurosurgery consulted
5e84|Neurosurgical issues were nonoperative
5e90|loaded with Dilantin
5f3a|serial head CT scans were performed and were stable
606c|follow up with Dr. Last Name in 4 weeks for repeat head imaging
6547|continue with Dilantin for one month
6608|right tib/fib fracture was repaired by Orthopedics on 9-11
6661|postoperatively there were no complications
6692|Weight bearing status was increased to weight bearing as tolerated
67c3|fitted with a hinged Doctor Last Name brace for his LLE
67c9|Lovenox injections for at least 4-6 weeks
67dc|transfused with 3 u packed cells for a hematocrit of 21
6b7a|post transfusion HCT was 26.1
6b9a|questionable transfusion reaction at the end of his first unit of packed cells
6c99|receive the remaining 2 units without any further reaction
6e16|Physical therapy consulted
6edf|Occupational therapy consulted
6f6c|home with services
6fd2|Phenytoin 50 mg Tablet, Chewable Sig: Two (2) Tablet, Chewable PO three times a day for 1 months
7000|Oxycodone 5 mg Tablet Sig: Two (2) Tablet PO Q4H (every 4 hours) as needed for pain
71df|Docusate Sodium 100 mg Capsule Sig: One (1) Capsule PO BID (2 times a day)
72b1|Magnesium Hydroxide 400 mg/5 mL Suspension Sig: Thirty (30) ML PO Q6H (every 6 hours) as needed for constipation
72ca|Lovenox 40 mg/0.4 mL Syringe Sig: 0.4 ML's Subcutaneous once a day for 30 days
72f3|Home With Service
734e|s/p Pedestrian Struck by Auto
73f7|Subdural hematoma
73f8|Skull fracture
742b|Right comminuted tibia/fibula fracture
756d|Good
75f9|fevers
760f|chills
7886|severe headaches
7944|visual disturbances
7bd8|nausea
7ce6|vomiting
7ddc|Lovenox injections for at least 4-6 weeks
7edc|Follow up with Dr. Last Name, Orthopaedics in 9-29 days
7f22|Follow up with Dr. Last Name, Neurosurgery in 4 weeks
7fba|repeat head CT scan

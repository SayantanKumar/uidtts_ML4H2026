007c|male
00ec|allergy to Sulfonamides
01c4|allergy to Penicillins
022d|allergy to Tetracyclines
025e|allergy to Azithromycin
0405|allergy to Iodine
04fd|allergy to Shellfish
0a82|allergy to Ace Inhibitors
0ab3|allergy to Ciprofloxacin
0b61|Chronic prostatitis
0bed|TURP
0e54|60 year old
0f30|man
0f6d|chronic prostatitis
1021|transurethral resection of the prostate procedures in 2165
10d1|transurethral resection of the prostate procedures in 2169
1102|diagnosis of interstitial cystitis
118d|history of coronary artery disease
128c|recent catheterization
138a|supraventricular tachycardia
1653|progressive mitochondrial myopathy
16b7|dribbling
1916|stress incontinence
19ae|hematuria
19b7|no dysuria
19d1|preadmitted for cardiac clearance
1c79|Coronary artery disease
1d39|s/p stents to LAD
1eb4|s/p stents to 3rd OM
1f18|Supraventricular tachycardia
1fc6|on a beta blocker
1fe6|Mitochondrial myopathy
20ab|orthostasis
21cc|tilt table testing done in the past
226e|transurethral resection of prostate times two
22dd|Interstitial cystitis
2376|Pericarditis
25e5|Hypertension
267f|Hypercholesterolemia
271f|Gastrointestinal bleed
279d|denies any tobacco
27a3|MI at 42
28d8|MI at 76
28df|NAD
2a04|MMM
2b2d|RRR
2d31|no m/r/g
2dbf|CTAB
2ee0|soft
3029|+distension with tympany
315e|no HSM
331f|hyperactive BS
3407|no c/c/e
3491|A&Ox3
3871|NSR at 62
3a60|nl axis
3b7b|nl intervals
3c96|Q waves in III
40d1|Q waves in avR
440c|Q waves in V1
44dc|TWI's in III
4514|TWI's in V1
46b1|GLUCOSE-94
46d9|UREA N-22
4792|CREAT-1.4
481e|SODIUM-142
488d|POTASSIUM-5.9
4afd|CHLORIDE-108
4bb4|TOTAL CO2-23
4ce0|ANION GAP-17
4ed0|CALCIUM-9.7
5435|PHOSPHATE-3.9
5610|MAGNESIUM-1.9
5753|WBC-7.5
5760|RBC-5.09
5938|HGB-15.4
59b1|HCT-43.7
59d9|MCV-86
5a41|MCH-30.2
5be6|MCHC-35.2
5e26|RDW-13.6
5e5e|PLT COUNT-257
5f49|PT-12.2
62ad|PTT-23.8
631c|INR(PT)-0.9
6615|cardiac clearance was obtained
67e7|tolerated procedure on 2176-3-4
69c3|transferred to ICU for 24hr post-op cardiac monitoring
6a00|uneventful
6b26|transferred out of Hospital Unit Name 153 to 12R
6ca6|removed
6ccf|started on Pyridium
6ce0|deemed suitable and stable for discharge
6e0e|discharged
6eb3|Hydroxyzine HCl 10 mg Tablet DAILY
6f08|Atorvastatin Calcium 20 mg Tablet DAILY
6f71|Ezetimibe 10 mg Tablet DAILY
6fe5|Simethicone 80 mg Tablet QID as needed for indigestion/gas pain
710f|Aluminum-Magnesium Hydroxide 225-200 mg/5 mL Suspension QID as needed for indigestion
7358|Atenolol 100 mg Tablet DAILY
73d7|Hyoscyamine Sulfate 0.125 mg Tablet QID
7450|Phenazopyridine HCl 100 mg Tablet TID for 3 days
7520|Home
764b|Chronic prostatitis
777c|Interstitial cystitis
786f|Good
795e|new and continuing nausea
7a1d|vomiting
7ac1|fevers (>101.5 F)
7cf4|chills
7f95|shortness of breath
8034|wound becomes red
8129|swollen
8161|warm
82b2|produces pus
846d|remove your dressings 2 days after your surgery
8576|clear drainage from your wounds
89a7|stop showering until the drainage subsides for at least 2 days
8a1a|No heavy lifting or exertion for at least 6 weeks
8b2e|No driving while taking pain medications
8cec|constipation
8f81|constipation
8ff1|resume your regular diet as tolerated
9067|take showers (no baths) after your dressings have been removed from your wounds
911e|Continue taking your home medications unless otherwise contraindicated
91f5|follow up with PCP
93e2|F/U with Doctor Last Name 365
93ef|F/U with Dr. Last Name (STitle) in 3-7 weeks

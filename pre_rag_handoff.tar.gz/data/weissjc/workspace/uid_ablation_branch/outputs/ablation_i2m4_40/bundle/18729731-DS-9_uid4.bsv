0067|allergy to Penicillins
0083|allergy to Dilantin Kapseal
00c0|unsteady gait
0126|no major surgical or invasive procedure
0135|man
0197|left-handed
030c|worsening of gait
036a|history of atrial fibrillation
0380|on anticoagulation
0387|anticoagulation held
03be|steroid injection of his back and hips
03e7|restarted on warfarin
0438|INR subtherapeutic
0446|cardioversion
0479|briefly off warfarin
0524|taking his warfarin as prescribed
058e|woke up feeling well
058f|suddenly noticed that he was falling to the left
05fe|did not actually fall
06d7|lean harder on his cane
07bf|new symptom
080a|denied vertigo
0840|denied lightheadedness
0945|denied diplopia
098c|denied dysarthria
09b6|denied speech difficulty
0a1d|denied weakness
0c9a|denied numbness
0cba|denied headache
0dea|denied neck pain
0e01|denied back pain
107c|denied hip pain
10dd|denied other symptoms
10e5|called a taxi cab
117e|sent him to the emergency department
1350|leaning to the left resolved
1365|able to ambulate to and from the bathroom
138f|thinks he is back to normal
139d|using the cane for the past several weeks
13b0|gait has been worsening
141d|leaning backwards while walking and standing
1426|falling about once per week
1504|tripping onto his knees
151f|has not struck his head
15dc|has not lost consciousness
15ea|denies headache
1618|denies neck pain
167b|chronic low back pain
1796|denies headache
1801|denies lightheadedness
180b|denies confusion
1a4d|denies difficulty with producing or comprehending speech
1a8a|denies loss of vision
1ab4|denies blurred vision
1af3|denies diplopia
1b07|denies vertigo
1b0c|denies tinnitus
1b3d|denies hearing difficulty
1b74|denies dysarthria
1c27|denies dysphagia
1d67|denies muscle weakness
1e37|denies loss of sensation
1e5e|denies bowel or bladder incontinence or retention
1eb2|endorses difficulty with gait
1efd|denies fevers
1f57|denies rigors
2240|denies night sweats
2284|denies noticeable weight loss
22e6|denies chest pain
2325|denies palpitations
23fb|denies dyspnea
24d8|denies cough
25b1|denies nausea
25e2|denies vomiting
2613|denies diarrhea
2677|denies constipation
26df|denies abdominal pain
2789|denies dysuria
27e2|denies hematuria
282d|denies myalgias
2881|denies arthralgias
28e7|denies rash
294d|history of questionable syncope versus seizure
2a07|S1 radiculopathy from lumbar disc disease
2a54|AF
2a9c|prior 1st degree AVB
2aba|AVR
2b14|HTN
2b72|HL
2cd1|Ascending aortic aneurysm
2dd1|Peripheral vascular disease
2ddb|DM2
2deb|mother had a stroke
2df7|no other known history of stroke
2e20|no seizures
2e46|no movement disorders
2e87|no demyelinating disease
2e8e|no rheumatologic disease
2ecd|no heart attacks
2f09|temperature 98.2
2f82|heart rate 70
2fd0|blood pressure 150/85
3127|respiratory rate 16
32e3|oxygen saturation 97% RA
335c|NAD
3468|lying in bed comfortably
3576|well-appearing elderly man
357f|mildly disheveled
3605|no conjunctival icterus
36a7|no oropharyngeal lesions
36b6|supple neck
36c0|no nuchal rigidity
3701|no meningismus
3742|no carotid/subclavian/vertebral bruits
3807|limited neck rotation to 45 degrees bilaterally
385f|no significant muscle tenderness
39b0|irregularly irregular rhythm
3a37|distant heart sounds
3a48|equal air entry bilaterally
3a4d|no crackles or wheezes
3a8f|soft abdomen
3b0c|non-tender
3b5a|non-distended
3c7a|positive bowel sounds
3d0c|no guarding
3d63|warm extremities
3dd7|no edema
3e24|scattered ecchymoses mostly on shins and knees
3e2c|no focal tenderness to percussion
3e4b|awake
3ead|alert
3ec6|oriented x 3
3f98|attention to examiner easily attained and maintained
4013|recalls a coherent history
4067|fluency with full sentences
406e|intact repetition
408b|intact verbal comprehension
4115|intact naming high and low frequency
4223|no paraphasias
425b|normal prosody
4289|no dysarthria
42f0|no apraxia
4372|no evidence of hemineglect
437b|no left-right agnosia
45a3|PERRL 2 to 1 brisk
45b1|visual fields full to number counting
45be|extraocular movements intact
4645|no nystagmus
4676|V1-V3 without deficits to light touch bilaterally
468d|no facial movement asymmetry
4775|hearing intact to finger rub bilaterally
479a|palate elevation symmetric
48f4|SCM/Trapezius strength ___ bilaterally
4921|tongue midline
4a46|decreased bulk in small muscles of the hands
4aa1|decreased bulk in the EDBs in the feet
4b13|no pronation
4b37|no drift
4bef|no tremor or asterixis
4c06|no cogwheeling
4c9c|Infraspinatus C4 R 4+ L 4+
4cbc|Deltoids C5 R 5- L 5-
4e4e|Biceps C5 R 5- L 5-
4f96|Triceps C6/7 R 4 L 4+
4f9c|Extensor Carpi Radialis C6 R 5 L 5
5018|Extensor Digitorum C7 R 5- L 5
5038|Flexor Digitorum C8 R 5 L 5
5125|Interosseus C8 R 5- L 5-
5129|Abductor Digiti Minimi C8 R 4+ L 4+
51da|Iliopsoas L1/2 R 5- L 5-
51e3|Quadriceps L3/4 R 5 L 5
522e|Hamstrings L5/S1 R 5- L 5-
5313|Tibialis Anterior L4 R 5- L 5-
531a|Gastrocnemius S1 R 5 L 5
532f|Extensor Hallucis Longus L5 R 5- L 5-
5331|Extensor Digitorum Brevis L5 R 5- L 5-
536c|Flexor Digitorum Brevis S1 R 4+ L 5-
543c|no deficits to light touch or temperature bilaterally
5475|proprioception markedly impaired at the first toes bilaterally
54af|misses his nose with both fingers from outstretched position with eyes closed
557a|plantar response flexor bilaterally
568b|dysmetria with the left hand
56b5|intact coordination on the right
56dc|somewhat impaired cadence with the left hand with finger-tapping
578e|some decrement with RAM with both hands with hand opening-closing
57e2|rebound with the left arm
5835|normal rebound on the right
58eb|heel-shin impaired on the left
597e|heel-shin intact on the right
5abc|normal initiation
5b24|wide base
5b8a|normal stride length
5c7a|limited arm swing
5c9a|leans backwards when standing still with eyes open and when walking with a regular gait
5cb7|falls backwards with Romberg
5ce2|takes several steps with turns but when turning quickly nearly falls
5dd0|uses a cane in his left hand
5e5f|WBC 7.4
5e7c|RBC 4.45 low
5f15|Hgb 14.3
617b|Hct 40.9
61e2|MCV 92
6207|MCH 32.3 high
6236|MCHC 35.1 high
625c|RDW 15.0
62ab|WBC 5.6
6409|RBC 4.16 low
6416|Hgb 13.4 low
64cd|Hct 37.9 low
65b1|MCV 91
65f4|MCH 32.1 high
66e8|MCHC 35.3 high
6770|RDW 15.3
6778|WBC 5.2
67da|RBC 3.97 low
6975|Hgb 12.7 low
6988|Hct 36.3 low
6abe|MCV 92
6b51|MCH 32.0
6c13|MCHC 35.0
6c48|RDW 15.2
6c99|WBC 8.4 high
6cf9|RBC 4.22 low
6e2f|Hgb 13.5 low
6ed8|Hct 38.6 low
6ef6|MCV 92
6f58|MCH 32.1 high
6f61|MCHC 35.1 high
6f80|RDW 14.8
6fea|WBC 7.3
7054|RBC 4.17 low
708f|Hgb 13.3 low
7132|Hct 38.3 low
72bb|MCV 92
7313|MCH 32.0
7384|MCHC 34.8
73e9|RDW 15.0
7505|WBC 7.5
750b|RBC 4.09 low
758b|Hgb 13.2 low
772b|Hct 37.9 low
775f|MCV 93
7780|MCH 32.3 high
77fe|MCHC 34.9
7818|RDW 15.3
78a5|Neuts 75.6 high
797e|Lymphs 16.5 low
7aa8|Monos 6.5
7b9e|Eos 0.3
7c3f|Baso 1.0
7c91|PTT 31.7
7c99|PTT 81.7 high
7ce5|PTT 87.8 high
7d0e|PTT 89.3 high
7d6c|PTT 93.4 high
7df6|PTT 93.0 high
7e30|PTT 56.1 high
7e4c|PTT 48.7 high
7f68|PTT 51.6 high
7fc6|PTT 61.5 high
8060|PTT 58.5 high
807a|PTT 54.3 high
8084|PTT 52.2 high
8104|PTT 57.1 high
81c8|PTT 62.0 high
8223|Glucose 157 high
8270|UreaN 26 high
8304|Creat 1.3 high
834e|Na 141
83f6|K 3.7
840e|Cl 101
844f|HCO3 32
8525|AnGap 12
8716|Glucose 214 high
8725|UreaN 29 high
877c|Creat 1.1
8844|Na 149 high
895c|K 3.6
89ec|Cl 109 high
89fd|HCO3 26
89ff|AnGap 18
8a84|Glucose 166 high
8aea|UreaN 22 high
8b0b|Creat 1.1
8b21|Na 142
8c10|K 3.7
8c62|Cl 107
8caf|HCO3 29
8d0f|AnGap 10
8d2a|Glucose 64 low
8d70|UreaN 28 high
8efc|Creat 1.2
8f1d|Na 144
8f3a|K 3.6
8f3e|Cl 109 high
8f45|HCO3 27
8fa5|AnGap 12
8fb5|Glucose 133 high
9006|UreaN 25 high
9030|Creat 1.1
9081|Na 141
909b|K 3.6
90df|Cl 105
90f5|HCO3 25
911e|AnGap 15
916f|ALT 18
917c|AST 29
917f|AlkPhos 67
9188|TotBili 1.1
920f|CK CPK 33 low
9225|Albumin 4.9
933b|Calcium 10.2
93bc|Phos 3.1
9466|Mg 2.9 high
94da|Calcium 9.0
94f7|Phos 3.3
96c4|Mg 2.2
96e7|Cholest 151
976b|Calcium 8.6
97db|Phos 3.3
98ad|Mg 2.4
98db|Calcium 9.2
98de|Phos 3.1
9904|Mg 2.5
9997|HbA1c 6.3 high
9b14|eAG 134 high
9b9a|Triglyc 150 high
9c55|HDL 36
9c63|CHOL/HD 4.2
9dd1|LDLcalc 85
9e38|TSH 1.8
9e52|ASA negative
9eac|Ethanol negative
a0a4|Acetmnp negative
a133|Bnzodzp negative
a13d|Barbitr negative
a19c|Tricycl negative
a299|presented with sudden onset worsening of gait
a2ad|history of atrial fibrillation on warfarin
a2f9|bioprosthetic aortic valve replacement
a319|mitral regurgitation
a3c1|hypertension
a502|hyperlipidemia
a511|diabetes mellitus
a52d|INR has been subtherapeutic
a52f|warfarin was held
a538|corticosteroid injection in the back and hip
a546|suddenly was leaning to the left
a724|no associated weakness
a75d|no sensory change
a7c2|no vision change
a7c5|no speech change
a83e|no double vision
a8d6|no other neurologic symptoms
a937|lasted for a few hours
a99d|somewhat unstable gait
a9a6|Romberg positive
aa86|decreased proprioception
aba3|vascular imaging does not show an acute occlusion
ac6a|extensive intracranial vessel calcifications
ac73|concerning for posterior circulation acute ischemic stroke related to atrial fibrillation in setting of subtherapeutic INR
acb8|no other brainstem symptoms such as vertigo or diplopia
acbf|background of cervical myelopathy leading to chronic gait difficulty
adf9|necessitating use of a cane in recent weeks
ae2f|symptoms had entirely resolved
ae47|stroke/TIA could not be fully ruled out
ae53|confirming it with MRI would not change management
aedf|continued on heparin gtt
af24|INR was therapeutic with warfarin at home dose
af2f|A1C 6.3
afd4|LDL 85
aff6|HDL 36
affa|pravastatin 40 mg daily
affe|evaluated by PT and OT
b0fb|home physical therapy
b139|no further OT needs
b14a|Warfarin 3 mg on ___ otherwise 2 mg
b16b|amlodipine 2.5 mg daily
b1c2|Brimonidine 0.1% drops three times daily
b399|Fenofibrate 160 mg daily
b44b|pravastatin 40 mg daily
b4d6|furosemide 10 mg daily
b503|amlodipine 2.5 mg daily
b511|allopurinol ___ mg daily
b616|metoprolol 50 mg daily
b630|Losartan 25 mg daily
b637|coenzyme Q 10
b659|Humulin 70/30 23 units every morning and 30 units every night
b68e|omega-3 fatty acids
b6bd|Tylenol 3
b7d4|fluticasone 50 mcg each nostril daily
b84e|brimonidine 0.1% TID
b91e|Finasteride 5 mg PO DAILY
b9bb|HumuLIN 70/30 units Subcutaneous BID 23 units every morning and 30 units every night
ba6d|Pravastatin 40 mg PO DAILY
baef|Warfarin 3 mg PO 3X/WEEK MO WE SA
bb4e|Warfarin 2 mg PO 4X/WEEK
bbeb|Amlodipine 2.5 mg PO DAILY
bc79|fenofibrate 160 mg Oral daily
bc92|Furosemide 100 mg PO DAILY
bcf5|Allopurinol ___ mg PO DAILY
bda9|Metoprolol Succinate XL 50 mg PO DAILY
be92|Losartan Potassium 25 mg PO DAILY
beb2|Fish Oil Omega 3 1000 mg PO BID
c13a|Acetaminophen w/Codeine PO Q4H PRN pain
c198|Fluticasone Propionate NASAL 1 SPRY NU DAILY
c2a0|Outpatient Physical Therapy
c2c7|discharged home
c339|episode of gait unsteadiness
c3e9|possible TIA
c3ef|clear and coherent
c40e|alert and interactive
c44b|ambulatory requires assistance or aid walker or cane
c485|admitted with an episode of gait unsteadiness
c4f8|gait unsteadiness resolved
c525|suffered a small stroke
c58d|transient ischemic attack
c59a|not able to confirm stroke or TIA
c7d0|poor sensation in feet
c980|decided to not get an MRI of brain
c9f5|INR was low
ca48|warfarin was held for a procedure
ca4a|restarted warfarin
ca6d|kept in hospital until INR therapeutic
caa2|INR is 2.3 at discharge
cb69|cardiologist comfortable with discharge
cb70|INR check arranged
cb71|A1C was 6.3
cb83|LDL was 85
cbbd|HDL was 36
cbce|did not make any changes to medications during hospitalization
cbd5|follow up with PCP
cc3c|follow up with cardiologist
cc59|follow up in stroke clinic

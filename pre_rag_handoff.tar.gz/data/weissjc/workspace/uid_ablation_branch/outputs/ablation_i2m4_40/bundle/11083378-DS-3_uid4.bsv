00b2|female
00d1|allergy to statins-Hmg-Coa Reductase Inhibitors
0240|RLE necrotizing fasciitis
024a|RLE wound debridement
024c|vac application
0257|RLE wound debridement
0272|partial closure
027f|vac application
029f|female
02ba|HTN
03ec|DM2
0419|gout
04e0|RA
05f4|OA
0687|PE
06a6|on coumadin
0727|presenting with right leg pain
07bb|redness to ___
0803|c/o constant sharp pain in right leg
08da|no alleviating factors
08f8|redness on right lower leg developed proximal to right knee
092b|developed fever of 102.7
09c7|denied trauma
0b60|denied tick/animal bites
0b91|recent left leg cellulitis
0bc3|requiring admission
0c2f|IV antibiotics for left leg cellulitis
0c5d|tachycardia to 120
0d5d|stable BP
0d80|erythema
0dd8|no signs of abscess
0de5|no crepitus
0e06|WBC of 27.3K
0e26|creatinine 1.3
0e66|elevated lactic acid
0eaf|elevated CRP
0fc6|CT negative for gas
1089|CT negative for abscess
10c8|given Tylenol PO x1
10dc|given IV morphine
10f9|given 2 L NS
1161|given IV clindamycin x1
1187|given IV vancomycin x1
12b8|blood cultures sent
12f3|given broad spectrum antibiotics for sepsis secondary to RLE cellulitis/necrotizing fasciitis
1396|underwent radical debridement of RLE necrotizing fasciitis
13f8|procedure went well
1408|developed severe sepsis post-op
1423|hypotension
144e|stabilized in ICU
150c|MAP>60 without vasopressor support
1570|low UO
15ed|mild response to fluids
160a|remained sluggish/drowsy
1640|put on bipap overnight for episodes of sleep apnea
165f|O2 sats maintained at 94% with nasal cannula
16e1|RLE debrided a second time
178c|clean margins
17a9|good bleeding
183f|remained intubated due to bouts of sleep apnea
1a35|remained in critical condition
1b23|transferred to ___
1bc1|DM2
1bda|HTN
1bee|PE on Coumadin
1c38|Gout
1cb0|RA
1ceb|OA
1d29|RLE debridement
1d4b|Mother deceased at ___ from pneumonia
1db6|___ deceased at ___ from MI
1dbd|T-98.7
1e2f|HR 94
2010|RR 16
205d|BP 120/49
212d|93% O2sat on APV
2200|intubated
2338|not sedated but very somnolent
23a4|clear to auscultation
23ac|normal air movement
23bf|no wheezing
2433|no crackles
24a1|no ronchi
252e|regular rate
256c|normal S1/S2
257e|no MRGs
2582|abd soft
263c|non-tender
2650|open CCY scar
268d|hysterectomy scar
26d5|posterior right leg debrided to healthy/pink muscle/tendon
272a|no prurulence
28b4|no foul odor
28d6|no necrotic-appearing tissue noted
299f|NAD
2b03|RRR
2b4a|no m/r/g
2bda|no difficulty breathing
2c44|lungs CTAB
2c74|abdomen soft
2d43|NT/ND
2d92|open chole scar
2dd2|hysterectomy scar
2e60|posterior lateral right lower extremity with healthy pink granulation tissue
2ef8|no necrotic-appearing tissue on exam
2f21|wrapped in wet-to-dry dressing for transport
2f86|AAOx3
2fc9|mood appropriate
3001|affect appropriate
3056|WBC-24.7 elevated
3193|RBC-2.79 low
31a2|Hgb-9.0 low
31a5|Hct-28.9 low
3235|MCV-104 elevated
3263|MCH-32.3 elevated
336c|RDWSD-57.1 elevated
337c|WBC-10.4 elevated
33d2|RBC-2.39 low
33df|Hgb-7.7 low
3448|Hct-24.3 low
3486|MCV-102 elevated
34c4|WBC-6.6
3533|RBC-2.75 low
35a8|Hgb-8.8 low
3684|Hct-27.7 low
36c5|WBC-9.8
36ca|RBC-3.15 low
372b|Hgb-10.3 low
380a|Hct-31.8 low
38d9|WBC-11.4 elevated
3917|RBC-2.98 low
3a0e|Hgb-9.4 low
3a22|Hct-30.2 low
3a5f|WBC-8.1
3bf6|RBC-2.82 low
3c12|Hgb-9.1 low
3cb6|Hct-28.9 low
3cd8|WBC-10.6 elevated
3cf6|RBC-2.54 low
3ddd|Hgb-8.1 low
3e4c|Hct-26.8 low
3ec9|WBC-9.6
3edd|RBC-2.71 low
3f71|Hgb-8.8 low
3fe8|Hct-28.6 low
4077|Glucose-167 elevated
428c|UreaN-37 elevated
42d2|Creat-1.4 elevated
4309|HCO3-19 low
4368|AnGap-17 elevated
441e|Glucose-177 elevated
4441|UreaN-31 elevated
44ea|Creat-1.2 elevated
4572|HCO3-21 low
45b3|Glucose-136 elevated
4662|UreaN-22 elevated
46f4|K-3.2 low
47cc|Glucose-148 elevated
483c|K-3.2 low
48fa|HCO3-38 elevated
4a04|AnGap-9 low
4a1e|Glucose-144 elevated
4a42|K-2.9 low
4a7b|Cl-95 low
4b9e|HCO3-40 elevated
4bb7|Glucose-207 elevated
4be2|HCO3-39 elevated
4bfa|Glucose-210 elevated
4c0b|K-3.2 low
4d43|Cl-94 low
4ef0|HCO3-39 elevated
4f52|Glucose-232 elevated
504f|Glucose-152 elevated
5135|UreaN-16 elevated
52e7|HCO3-33 elevated
5332|Glucose-200 elevated
54cc|UreaN-13 elevated
55b7|ALT-10
5620|AST-19
566a|AlkPhos-93
5819|TotBili-0.3
5896|ALT-8
58ed|AST-18
58f0|LDH-184
592b|AlkPhos-56
5a13|TotBili-<0.2
5a32|Albumin-2.6 low
5a7c|Calcium-7.2 low
5aac|Phos-5.4 elevated
5ad0|Mg-1.6
5b1c|Calcium-7.8 low
5ba2|Phos-4.4
5bb4|Calcium-8.0 low
5bee|Phos-2.8
5c83|Calcium-8.4
5d44|Phos-2.1 low
5e0d|Phos-2.4 low
5ecf|Phos-2.0 low
5ee9|Calcium-8.6
5f72|%HbA1c-6.9 elevated
5f7e|eAG-151 elevated
5f83|Lactate-0.9
606e|Lactate-0.9
609e|Lactate-0.9
611d|Lactate-1.0
621a|loose stool
6303|C. difficile DNA amplification assay positive
6487|urine appearance hazy
64ee|urine blood trace
6512|urine protein 30
6571|urine ketone 10
6660|urine pH 6.0
6690|urine leukocytes negative
6749|urine RBC-7
6873|urine WBC-6
68d5|urine bacteria moderate
68df|urine yeast none
68e3|urine epithelial <1
691e|urine granular casts 4+
6bda|urine hyaline casts 4+
6c7e|diffuse atherosclerotic vascular disease with limited 3 vessel runoff to R ankle
6d1f|diffuse soft tissue edema consistent with cellulitis, no focal collection/abscess
6d25|osteopenia and osteoarthritis, no fracture, no osteomyelitis
6d93|endotracheal tube withdrawn from right main bronchus
6e70|upper lungs clear
6eab|lung bases incompletely aerated, probably atelectasis
6f37|exclude developing pneumonia
6f4d|heart size normal
6fc2|mediastinal and hilar contours and pleural surfaces unremarkable
7029|left PIC line ends in low SVC
70a9|left atrium mildly dilated
7168|no atrial septal defect
71b3|normal left ventricular wall thickness, cavity size, and regional/global systolic function
726a|normal estimated cardiac index
727e|normal left ventricular filling pressure
745e|right ventricular chamber size and free wall motion normal
74a0|diameters of aorta normal
74a1|aortic valve leaflets structurally normal
7573|no aortic valve stenosis
7719|no aortic regurgitation
7779|mitral valve leaflets structurally normal
77ed|mild (1+) mitral regurgitation
780c|moderate (2+) tricuspid regurgitation
7847|moderate pulmonary artery systolic hypertension
7903|no pericardial effusion
798f|WBC-8.1 discharge
7ad1|RBC-2.87 low discharge
7b39|Hgb-9.1 low discharge
7b54|Hct-30.1 low discharge
7b90|MCV-105 elevated discharge
7bfa|PTT-27.6 discharge
7c4c|Glucose-94 discharge
7c5c|UreaN-12 discharge
7cf5|Creat-0.7 discharge
7da7|Na-144 discharge
7dcb|K-4.1 discharge
7e63|Cl-101 discharge
7f14|HCO3-32 discharge
7f45|Calcium-8.8 discharge
7f54|Phos-3.2 discharge
7fb0|Mg-1.5 low discharge
804f|female
8162|hypertension
826f|diabetes
82ee|gout
8311|rheumatoid arthritis
83c1|osteoarthritis
83f6|history of PE
849d|presented with right lower leg pain
84eb|recognized as cellulitis
85a6|cellulitis progressed to necrotizing fasciitis
85d6|taken to OR for radical debridement of fasciitis
8674|transferred to ___
87f9|underwent right lower extremity debridement
889d|VAC drain placed
88a9|arrived intubated on ventilator with levophed
88d6|consulted Acute Care Surgery
88ea|admitted to ICU
891e|taken to OR for VAC dressing take down and repeat debridement
8933|repeated debridement with clean margins achieved
8acb|remained intubated
8b1e|requiring levophed for blood pressure support
8bc8|WBC elevated at 20
8c64|continued to require levophed
8cff|IV fluid bolus administered
8d15|stress dose steroids administered
8d3f|cardiac echocardiogram showed EF of 55%
8d5d|successfully extubated
8d9e|pressors weaned off
8e65|A-line discontinued
8e8c|wound vac placed
904a|transferred to surgical floor
9091|tolerating a regular diet
919e|alert and oriented throughout hospitalization
9277|IV fentanyl while intubated
92ab|transitioned to oral oxycodone and Tylenol
92fd|IV dilaudid breakthrough
9305|remained stable from cardiovascular standpoint
93a8|remained stable from pulmonary standpoint
943b|given a regular diet which she tolerated without issues
9453|blood sugar controlled on long acting insulin and sliding scale
9476|c.diff diagnosed
950a|started on flagyl
9573|foley catheter removed
96ca|voided spontaneously without issues
9735|home Lasix restarted
973e|fever curves closely watched for signs of infection
9786|treated with IV clindamycin
9827|treated with zosyn
99ff|treated with vancomycin
9a4b|clindamycin discontinued
9a6f|vancomycin discontinued
9aca|zosyn discontinued
9b47|levofloxacin started
9d25|levofloxacin discontinued
9ded|diagnosed with c.diff
9e77|prescribed 14 day course of flagyl
9ef7|flagyl completed
9f1b|left the hospital negative for C. difficile infection
a0a0|of which there were none
a11f|methotrexate held in hospital for wound healing
a17a|methotrexate can be restarted as outpatient
a1aa|received subcutaneous heparin
a1de|___ dyne boots used during stay
a20a|encouraged to get up and ambulate as early as possible
a390|Coumadin held in setting of multiple surgical debridements
a47e|doing well
a500|afebrile at discharge
a505|hemodynamically stable at discharge
a52d|tolerating a diet at discharge
a532|voiding adequate urine at discharge
a53a|pain well controlled at discharge
a578|received discharge teaching and follow-up instructions
a587|MetFORMIN 1000 mg PO BID home med
a5b2|Carvedilol 6.25 mg PO BID home med
a608|Methotrexate 10 mg PO 1X/WEEK home med
a664|Glargine 5 Units Bedtime home med
a6b0|Losartan Potassium 25 mg PO DAILY home med
a6ee|WelChol 625 mg oral BID home med
a72f|Omeprazole 20 mg PO DAILY home med
a735|Ibuprofen 400 mg PO BID home med
a744|PredniSONE 5 mg PO DAILY home med
a84c|Colchicine 0.6 mg PO DAILY home med
a90e|Allopurinol ___ mg PO DAILY home med
a919|Furosemide 40 mg PO DAILY home med
a962|Ezetimibe 10 mg PO DAILY home med
a991|BuPROPion 150 mg PO BID home med
aa47|Ascorbic Acid ___ mg PO BID discharge med
ac01|Heparin 5000 UNIT SC TID discharge med
ac58|MetroNIDAZOLE 500 mg PO Q8H for 14 days discharge med
ac7d|OxyCODONE 2.5-5 mg PO Q4H PRN discharge med
ace8|Glargine 11 Units Dinner discharge med
ad3b|Humalog 4 Units Breakfast discharge med
ad52|Humalog 4 Units Lunch discharge med
ad55|Humalog 4 Units Dinner discharge med
ae1d|Allopurinol ___ mg PO DAILY discharge med
ae93|BuPROPion 150 mg PO BID discharge med
af08|Carvedilol 6.25 mg PO BID discharge med
af1d|Colchicine 0.6 mg PO DAILY discharge med
af8e|Ezetimibe 10 mg PO DAILY discharge med
b056|Furosemide 40 mg PO DAILY discharge med
b07a|Ibuprofen 400 mg PO BID discharge med
b080|Losartan Potassium 25 mg PO DAILY discharge med
b19f|MetFORMIN 1000 mg PO BID discharge med
b207|Methotrexate 10 mg PO 1X/WEEK discharge med
b265|Omeprazole 20 mg PO DAILY discharge med
b27d|PredniSONE 5 mg PO DAILY discharge med
b299|WelChol 625 mg oral BID discharge med
b334|discharged to Extended Care Facility
b33e|RLE necrotizing fasciitis diagnosis
b449|c. difficile infection diagnosis
b4a3|clear and coherent at discharge
b4d8|alert and interactive at discharge
b592|ambulatory requires assistance at discharge
b649|admitted to hospital with infection in right leg
b724|given IV antibiotics
b831|taken to operating room at ___ for infected tissue removal
b95c|transferred to ___ on ___
ba2e|taken to operating room every few days to assess wounds, remove infected tissue, change VAC dressing
bbc5|wound shows no active signs of infection
bbe1|tolerating VAC changes at bedside
bc57|diagnosed with clostridium difficile infection
bd30|many loose bowel movements
bda9|treated with flagyl
bdae|complete total of 14 days of flagyl treatment
bef2|doing better
bf43|tolerating a regular diet at discharge
bf7e|wound healing progressively with wound vac dressing
c247|ready to be discharged to rehab
c251|new chest pain warning sign
c252|new or worsening cough warning sign
c2e6|shortness of breath warning sign
c34e|wheeze warning sign
c3ab|vomiting and cannot keep down fluids or medications warning sign
c3f0|getting dehydrated warning sign
c3f4|dry mouth
c691|rapid heartbeat
c6ad|feeling dizzy or faint when standing
c6cb|blood or dark/black material when vomit or bowel movement warning sign
c6d3|burning when urinate warning sign
c7eb|blood in urine warning sign
c827|discharge warning sign
c8e3|pain not improving within ___ hours warning sign
c986|pain getting worse or changes location warning sign
c9d5|shaking chills warning sign
c9de|fever greater than 101.5 warning sign
c9ed|change in symptoms warning sign
ca10|new symptoms that concern you warning sign
cac1|resume all regular home medications unless specifically advised not to
cb5c|take any new medications as prescribed
cbb3|get plenty of rest
ccc2|continue to ambulate several times per day
cccf|drink adequate amounts of fluids
cd8f|avoid lifting weights greater than ___ lbs until follow-up with surgeon
cdab|avoid driving or operating heavy machinery while taking pain medications
cdad|wound vac change with black sponge approximately every ___ days
ce73|monitor for signs of infection

00c5|M
01ec|47-year-old
01ef|male
0283|history of coronary artery disease
0388|2-vessel percutaneous transluminal coronary angioplasty in 2186
0544|3-vessel percutaneous transluminal coronary angioplasty in 2190
07a6|history of hypertension
08af|new onset type 2 diabetes
08e7|history of hypercholesterolemia
08e9|substernal chest pain
09f7|exercise
0bcd|substernal burning without radiation
0c56|exercise
0c89|exercised
0dd9|pain became worse
0f41|nitroglycerin patch did not help
0f52|slight relief with sublingual nitroglycerin times three
102b|shortness of breath
111e|headache
113d|change in vision
11e0|dizziness
1600|nausea
169a|vomiting
1905|abdominal pain
1ae2|change in bowel or urinary habits
1b4d|fevers
1bd8|chills
1d91|sweats
1e9f|stress test in 2193-5-7
1f7e|aspirin
2032|nitroglycerin drip
2067|heparin drip
2201|Dilaudid
22d0|TNK
2467|decreased in his pain
2548|without resolution of symptoms
2689|ST elevations
272f|J point elevations in V2 through V4
286f|catheterization
2c53|100% occlusion of the proximal left anterior descending artery
2c7d|50% stenosis of first diagonal
2e71|percutaneous transluminal coronary angioplasty and stenting was performed on proximal left anterior descending artery
2e85|percutaneous transluminal coronary angioplasty was performed on first diagonal
30e5|intra-aortic balloon pump was placed
3201|history of Coronary artery disease
334b|percutaneous transluminal coronary angioplasty times three in 2190
3373|percutaneous transluminal coronary angioplasty times two in 2186
3484|history of Type 2 diabetes
348d|history of Hypercholesterolemia
35bc|history of Hypertension
36e7|No ethanol use
3709|No tobacco at this time
370a|quit 20 years ago
3771|married
391f|Diltiazem 180 mg p.o. q.d.
3979|Lipitor 10 mg p.o. q.d.
3ace|Glyset 25 mg p.o. q.d.
3e61|Prevacid 30 mg p.o. q.d.
3e84|metoprolol 50 mg p.o. b.i.d.
3faf|Glucophage 500 mg p.o. q.d.
4127|PENICILLIN
42c9|IODINE
430c|Temperature maximum 98.7
445d|temperature current 98.3
44fe|pulse ranged from 82 to 92
460e|blood pressure 104 to 124/67 to 74 with a mean of 86 to 99
4779|respiratory rate of 11 to 16
4853|oxygen saturation 94% to 98% on 2 liters
4971|Pulmonary artery pressure was 29/15 with a mean of 22
4b8e|Cardiac output was 7
4c7e|Intra-aortic balloon pump augmented systole was 109
4d75|augmented diastole was 111
4da4|no apparent distress
4e6e|No lymphadenopathy
4ff6|clear to auscultation bilaterally, anteriorly and laterally
51bf|jugular venous distention not appreciated
523a|bilateral bruits
5306|No S3 or S4
539f|No murmurs, rubs or gallops
5551|decreased bowel sounds
55c5|No hepatosplenomegaly
5623|no edema
58a1|white count 7.8
5943|hematocrit was 41.7
5b58|platelets of 252
5b5b|MCV 89
5d55|RDW 12.7
5d8e|sodium of 136
6017|potassium 4.7
60bb|chloride 103
6144|bicarbonate 22
6174|BUN 16
61e2|creatinine 0.8
636d|glucose 284
6413|PT 14.2
66a9|PTT 108.5
6718|INR 1.3
67db|Creatine kinase at 11 a.m. was 83
6828|at 5 p.m. was 3021
6a78|Arterial blood gas at 11 a.m. was 7.33/46/115
6e67|3450 at 11 p.m.
6fb0|1734 at 5:30 a.m. on 9-11
707d|1277 at 11:30 a.m. on 9-11
70a3|83 at 9:30 a.m. on 9-15
70e0|ST elevations
7195|J point elevations in V2 through V3
7196|ejection fraction of 30%
7541|moderate systolic dysfunction
75ad|basal anterior hypokinesis
7614|mid anterior akinesis
7636|basal anteroseptal hypokinesis
77c9|mid anteroseptal akinesis
786d|Anterior apex akinesis
790f|inferior apex akinesis
79bd|apex akinesis
7a7b|mitral regurgitation
7a96|tricuspid regurgitation
7c97|acute coronary syndrome
7d9c|Dopamine was discontinued
82d3|intra-aortic balloon pump was discontinued
83d7|heparin
84cc|transitioned to Coumadin
866d|Lipitor
8854|aspirin
88de|Plavix was added
8948|Lopressor
8abb|captopril
8c97|Zestril 10 mg q.d.
8e33|atenolol 25 mg q.d.
8fac|discharged from the hospital
9104|stable
9146|discharged home
9249|Lipitor 10 mg p.o. q.d.
92b6|Aspirin 325 mg p.o. q.d.
930d|Plavix 75 mg p.o. q.d. times 30days
93b9|Prevacid 30 mg p.o. q.d.
94c1|Atenolol 25 mg p.o. q.d.
9654|Zestril 10 mg p.o. q.d.
9723|Glyset 25 mg p.o. q.d.
9758|Glucophage 500 mg p.o. q.d.
97af|Coumadin 5 mg p.o. q.d.

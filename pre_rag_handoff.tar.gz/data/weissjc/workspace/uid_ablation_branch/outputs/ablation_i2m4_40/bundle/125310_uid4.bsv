0016|Shellfish allergy
02b8|Chest pain
0389|None
039b|Age over 90
0460|woman
054c|h/o HTN
06c1|substernal chest pain after exercise
0873|performed here regular exercises
0a68|SSCP without radiation
0b0d|No nausea
0bca|No vomiting
0d3a|No diaphoresis
0e10|ECG at rehab demonstrated new ST depressions in V1-V4
0e41|received ASA 81 mg x 2
0f1c|nitro SL x 2 with partial relief at nursing home
1249|HR 68
1315|BP 142/68
1437|RR 28
1484|O2 sat 100% RA
149c|RRR
1518|no murmur
17f2|bibasilar crackles
1848|guaiac negative
1912|EKG showed sinus brady
1b8a|old LAD
1ccd|new ST depressions in V1-V4
1dc6|Troponin was 0.07
1fef|received ASA
2064|nitro SL then gtt
20c2|morphine
2163|metoprolol
229c|heparin gtt
237b|discussed cath
245f|turned down cath
249f|Transferred to CCU for further management and observation
25f9|HTN
2792|Hearing difficulty
280a|Blindness macular degeneration
284d|R ankle fx
2896|S/p hysterectomy
28bb|currently lives at Rehab
2972|no tobacco use
29ce|no EtOH use
2a8c|used to be housewife
2aeb|T 97.8
2bfc|HR 53
2d05|BP 156/58
2d23|RR 16
2e3f|O2 sat 94% on 2.5 L
2e7b|NAD
2ea5|awake
2f16|alert
2f4f|blind
30c9|able to hear loud voices at L ear
30de|MMM
30e5|OP clear
3150|JVP 11 cm
317c|Reg rate
31d9|nl S1 & S2
32c2|no m/r/g
32d2|Crackles at base and mid-lungs bilaterally
3515|Soft
35d9|NT
3677|ND
37a6|BS present
37e3|no masses
384f|Trace ankle edema bilaterally
38a1|WBC-11.4
39cf|RBC-3.61
39d4|Hgb-11.4
3a5b|Hct-32.6
3a5e|MCV-90
3b43|MCH-31.7
3b8a|MCHC-35.1
3c37|RDW-14.7
4032|Plt Ct-281
411c|Glucose-124
4142|UreaN-30
433a|Creat-1.3
45ea|Na-137
4627|K-4.2
48b7|Cl-102
49b7|HCO3-27
4a92|AnGap-12
4b5b|CK(CPK)-42
4b6e|cTropnT-0.07
4c5d|sinus brady @ 48 bpm
4cae|LAD
4de7|LVH
4ed5|RBBB
4ff4|Q wave in I
5214|ST depressions in V1-V4
52fe|ST elevation in III aVF
533f|TWI in III V5
54ab|slight worsening of still mild pulmonary edema
551d|no pneumothorax
5589|Small right pleural effusion is stable
55bc|Cardiac size is normal
5630|LVEF >70%
5682|LA 6.1 cm
56c1|no regional wall motion abnormality
5775|CK(CPK)-1471
5824|CK-MB-207
587b|MB Indx-14.1
58ed|cTropnT-6.00
5b53|CK(CPK)-1288
5be7|CK-MB-158
5c86|MB Indx-12.3
5dd5|cTropnT-6.88
5f06|CK(CPK)-627
5f40|CK-MB-55
5ff0|MB Indx-8.8
61e5|cTropnT-4.46
6326|WBC-13.8
639e|RBC-3.39
63b6|Hgb-10.7
6520|Hct-30.2
65c6|MCV-89
6610|MCH-31.5
6668|MCHC-35.3
669a|RDW-14.8
6c51|Plt Ct-214
6db8|Glucose-120
6ea4|UreaN-30
708a|Creat-1.2
717c|Na-134
73b0|K-4.2
749c|Cl-100
75ca|HCO3-25
7628|AnGap-13
778e|Calcium-8.7
7824|Phos-2.5
7863|Mg-2.1
78f4|substernal chest pain shortly after exercise at nursing home
7a2e|EKG showing ST depressions in V1-V4
7a36|troponin 0.07
7aa0|Likely NSTEMI
7aef|patient's family refused coronary artery catheterization
7bf5|given ASA
7c75|Plavix
7cba|heparin drip x 24 hours
7d9b|nitro drip
7e08|atorvastatin
7e55|metoprolol
7ea3|lisinopril
7f27|chest pain was controlled with morphine
81bd|SBP remained in the 160s-170s on hospital day 1
829e|gently diuresed
82c9|experienced atrial fibrillation with HR in the 140s
8366|metoprolol dose was increased from 25 mg PO bid to 50 mg PO bid then 75 mg PO tid
837a|HR decreased to 70s-80s
83cf|BP remained stable
8438|preserved EF
8551|no wall motion abnormalities
85bc|decided given her age that she would not be a good candidate for cardioversion for her afib
8696|good candidate for coumadin
86a1|continue rate control with metoprolol
8879|aspirin and plavix for anti-coagulation
8914|continue on lipitor and lisinopril
8ae7|Bilateral crackles at bases and midlungs
8b14|elevated JVP
8b8f|trace bilateral ankle edema
8ba2|CXR with diffuse opacities suggest possible pulmonary edema
8d48|likely secondary to acute MI
8e22|O2 sat was stable at 94-97% on 2.5L of supplemental O2
8e90|experienced no respiratory difficulty during the hospital stay
8f13|diuresed small amount
8f5f|CXR prior to discharge showed mild pulm edema
9026|given 40 of lasix prior to going to rehab
90aa|developed mild elevated WBC
92c3|UA had WBC's few bacteria
9519|initially started on Bactrim
961c|Bactrim was stopped as she was afebrile
9787|culture pending
97e0|DNR/DNI
9859|tylenol PRN
987d|lisinopril 5 mg PO qd
98bc|protonix 20 mg PO qd
9a06|artifical tears
9b6e|metoprolol 25 mg PO bid
9bb3|Senna 8.6 mg Tablet
9bcc|Docusate Sodium 100 mg Capsule
9d67|Aspirin 325 mg Tablet
9dc5|Clopidogrel 75 mg Tablet
9e8c|Atorvastatin 80 mg Tablet
9ebe|Pantoprazole 40 mg Tablet Delayed Release
a010|Polyvinyl Alcohol 1.4 % Drops
a1b8|Lisinopril 10 mg Tablet
a1df|Metoprolol Tartrate 25 mg Tablet TID
a4d6|Acetaminophen 325 mg Tablet
a770|Maalox 225-200 mg/5 mL Suspension
a79a|Lasix 40 mg Tablet
a7a5|Extended Care
a7ea|NSTEMI
aa74|Atrial Fibrillation
ab51|HTN
abbc|without chest pain
abda|heart rate stable
ac14|BP stable

0175|No Known Allergies to Drugs
03b7|lightheadedness
03e4|slight DOE
0456|Redo AVR with aortic root enlargement
04b7|68 yo
04bc|female
050b|transferred in from Catholic Med. Ctr.
07da|periprosthetic aortic valve stenosis
0839|aortic valve thrombus
0841|No cath done
09ef|echo showed EF 60-65%
0ad4|stenotic mech. valve
0b81|mean gradient 33 mm
0cf4|decreased disc motion
0de5|mobile mass in LVOT
0f8c|mild AI
0fc0|mild to moderate MR
1246|trace TR
1353|Referred for surgical evaluation
13c8|HTN
13d0|elev. lipids
14f0|hypothyroidism
1584|back pain
17c6|GERD
1a3a|s/p AVR
1c5b|remote tonsillectomy/adenoidectomy
1d4a|partial thyroidectomy
1e3b|rem. right wrist ganglion cyst
1eab|left foot bunionectomy
1ebc|breast biopsies
205c|retired
20b1|lives alone
2173|widowed
2213|quit smoking 20+ years ago
233a|no ETOH use
23b9|180/88
23ce|HR 68
2486|RR 18
2763|95% sat
27fe|65.5
29b2|87 kg
2a89|NAD
2b75|skin/HEENT unremarkable
2bc2|neck supple
2c84|murmur radiates bilat. to carotids
2cdb|CTAB
2def|RRR with holosystolic murmur
307e|soft
30d9|NT
32f3|ND
33fa|+ BS
3638|warm
36d5|well-perfused
37ef|no edema
383f|superficial varicosities
398c|neuro grossly intact
3a3c|2+ bil. fem/ radials
3a92|1+ bil. DP/PTs
3ae3|AV paced
3bf1|infusion of phenylephrine
3c3a|bioprosthesis is well seated in the aortic position
3c91|leaflets open well
3cba|trace central AI is seen
3f28|Trace AI is also noted between the left and right coronary cusps
3f36|small paravavluar leak in the area adjacent to the anterior mitral leaflet
3fa7|trace insuffiency outside the sewing ring
3fd1|Mitral regurgitation is unchanged from before
40d8|Biventricular systolic function is unchanged
45f7|Aorta is intact post decannulation
47f4|Hct-29.2
47f9|WBC-12.4
496a|RBC-2.89
49e6|Hgb-9.0
4b32|Hct-26.0
4d1e|MCV-90
4f67|MCH-31.3
52ed|MCHC-34.9
5317|RDW-13.5
57cd|Plt Ct-262
5826|PT-16.8
58ab|PTT-65.3
58bf|INR(PT)-1.5
5959|Glucose-115
5a9f|UreaN-20
5b65|Creat-1.3
5bfa|Na-137
5c38|K-4.8
5c49|Cl-96
5d19|HCO3-34
600b|AnGap-12
610c|Admitted to cardiology service for surgical work-up
6219|INR 2.7
633c|echo repeated
634e|coumadin held
6373|heparin drips started
63be|peak gradient of 64mm
640a|pannus involving the valve
659d|? thrombus
6829|underwent redo AVR with aortic root enlargement on 3-7
6b41|Transferred to the CSRU in stable condition
6b71|phenylephrine
6bb0|propofol drips
6c27|Weaned toextubation on POD #2
6c67|off all drips
6cb0|Episode of AFib
6dce|treated with amiodarone
6df0|converted to SR
6e76|Transferredto the floor on POD #3
7051|increasing her activity level
7085|Chest tubes removed
7124|wires removed
71b4|Cleared fordischarge to home with services
71d0|synthroid 75 mcg daily
71f4|HCTZ 37.5 mg daily
74a0|MVI daily
75a2|Vit.C 500 mg daily
7660|prevacid 15 mg daily
76c9|coumadin held
76ea|toprol XL 100 mg daily
789f|zocor 40 mg daily
7aee|KCl mEq daily
7d19|cozaar 25 mg daily
7e8c|Metoprolol Tartrate 25 mg Tablet
8007|Docusate Sodium 100 mg Capsule
8069|Aspirin 81 mg Tablet, Delayed Release (E.C.)
81c4|Oxycodone-Acetaminophen 5-325 mg Tablet
8212|Levothyroxine 75 mcg Tablet
8233|Simvastatin 40 mg Tablet
8375|Pantoprazole 40 mg Tablet, Delayed Release (E.C.)
83c4|Amiodarone 200 mg Tablet
85e2|Potassium Chloride 10 mEq Capsule, Sustained Release
86b2|Furosemide 20 mg Tablet
86e7|Home With Service
885d|prosthetic aortic valve stenosis
886a|HTN
892f|elev. lipds
8ad7|hypothyroidism
8d15|back pain
8d37|GERD
8df9|A Fib
9006|s/p AVR
90c3|stable

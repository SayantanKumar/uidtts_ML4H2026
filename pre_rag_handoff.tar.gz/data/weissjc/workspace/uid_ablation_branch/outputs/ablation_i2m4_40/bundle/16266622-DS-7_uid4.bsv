010d|transfer for OSH for cardiac catheterization
0182|chest pain
0266|abnl. ETT
0324|___ year old
0404|man
0477|chronic abdominal pain
04df|local pain clinic
056c|SVT
0680|treated with Cartia for the last ___ years
06aa|admitted toOSH
08c3|palpitations
0b5a|chest pain radiating to bilateral arms
0cb4|called ___
0d03|SVT
0d17|rate of 170's
0f1f|possible inferior ST elevations on EKG
1089|responded to Adenosine
1122|converted to normal sinus rhythm
115a|Ck-MB peak was 11.1
120c|peak troponin was 0.38
1469|Adenosine stress was positive
1497|fatigue
155a|ST elevations inferiorly
1570|EF was 64%
15c7|chest pain free since admit
1686|no further SVT
17a1|transferred for cardiac catheterization
1827|coronary artery bypass grafts x 4
1913|LIMA to LAD
197d|SVG to OM1
19dc|SVG to OM2
19e4|SVG to PDA
1a20|___ year old
1e97|man
1ec8|chronic abdominal pain
1ee1|local pain clinic
1f66|SVT
209d|treated with Cartia for the last ___ years
24dc|admitted toOSH
2537|palpitations
25d2|chest pain radiating to bilateral arms
299c|called ___
2beb|SVT
2c36|rate of 170's
2c96|possible inferior ST elevations on EKG
2d89|responded to Adenosine
2fb0|converted to normal sinus rhythm
2fe6|Ck-MB peak was 11.1
30c9|peak troponin was 0.38
3159|Adenosine stress was positive
316f|fatigue
3189|ST elevations inferiorly
319d|EF was 64%
32c3|chest pain free since admit
3404|no further SVT
3439|transferred for cardiac catheterization
350a|chronic abdominal pain
358d|renal/liver cyst
359f|2 prior surgeries
3737|anxiety
380a|hernia repair
3917|hypertension
3933|supra ventricular tachycardia
39e1|non-contributory
3a6c|Thin pale appearing male in NAD
3b17|nasal fold eczema
3dda|unremarkable
3f25|supple
4059|lungs CTA
409f|RRR S1, S2
40e4|soft, NT, ND, +BS
4278|Tenderness in RUQ to palp/fullness in RUQ
42f4|well profused
4413|no edema
4616|pulses +2 in all 4 extremities
475d|none
485f|WBC
49e6|RBC
4b0d|Hgb
4b66|Hct
4cd2|MCV
4db6|MCH
4ef5|MCHC
4f55|RDW
500b|Plt Ct
5261|4.8
5270|3.38*
5295|8.6*
539a|26.9*
5453|80*
5586|25.3*
55e2|31.8
5604|14.1
5671|211
5872|Neuts
58ab|Bands
591d|Lymphs
5960|Monos
5a75|Eos
5bd8|Baso
5e86|Atyps
5f7c|Metas
6127|58.0
6356|26.9
63d6|9.0
641c|5.8*
6489|0.4
64f8|PTT
656f|bun 11
6680|creat 0.7
69a4|K 4.2
69f2|ALT
6a90|AST
6c4d|LD(LDH)
6db9|CK(CPK)
6f89|AlkPhos
7017|Amylase
710b|TotBili
7256|DirBili
7321|16
7432|23
7433|69
75d7|65
7c55|0.4
7dce|TotProt
7e13|Albumin
7e95|Globuln
8076|Calcium
808d|Phos
81df|Mg
829c|UricAcd
82cf|Iron
82d9|2.2
8309|VitB12
84b3|504
85af|%HbA1c
86c9|6.0*1
872d|admitted from OSH
8a99|presenting w/ new onset chest pain-radiating to both arms
8cab|Admitted for cardiac cath
8d50|Cardiac cath was done
8eb5|revealing 80% left main
8ed5|taken to the OR
8f89|pre-op work up was completed
9000|underwent CABg x4
92db|admitted to the ICU
9380|stable condition
9514|intubated
96e0|sedated
96ea|awakened from sedation
978c|extubated
9868|chest tubes and wires were removed
9bda|transferred from the ICU to the floor
9c11|Pain control was a major issue
9cde|pain service was consulted
9d4e|progressed well with his recovery
9ecc|started on betablockers
a0d8|aspirin
a14a|statin
a24d|diuresis
a259|cleared for home by physical therapy
a283|discharged to home
a291|No ___ services were provided
a302|declined ___ services
a356|Methadone 30
a42b|Oxycodone 60 Q4-prn
a44f|Cartia XT 360
a4a9|Valium 10 q8h prn
a4b1|ASA 81
a53c|Celebrex
a56f|Aspirin 81 mg
a58d|Docusate Sodium 100 mg
a5c2|Methadone 10 mg
a767|Atorvastatin 80 mg
a7b0|Oxycodone 30 mg
a7f6|Furosemide 40 mg
a9c9|Potassium Chloride 20 mEq
ab62|Metoprolol Tartrate 25 mg
abc2|Ibuprofen 400 mg
ac01|Home
acbf|coronary artery bypass grafts x 4
ad44|LIMA to LAD
ae21|SVG to OM1
ae75|SVG to OM2
aeb1|SVG to PDA
af94|coronary artery disease
b0c1|hypertension
b103|h/o hepatic cysts and resections
b125|s/p herniorrhaphy
b30a|anxiety disorder
b395|good
b3c9|Shower daily, no baths or swimming.
b430|No lotions, creams or powders to incisions
b4ff|No driving for 6 weeks and off all narcotics.
b537|No lifting more than 10 pounds for 10 weeks.
b625|Report any fever greater than 100.5.
b843|Report any redness of, or drainage from incisions.
b99f|Report weight gain gretaer than 2 pounds a day or 5 pounds a week.
b9ac|Take all medications as directed.

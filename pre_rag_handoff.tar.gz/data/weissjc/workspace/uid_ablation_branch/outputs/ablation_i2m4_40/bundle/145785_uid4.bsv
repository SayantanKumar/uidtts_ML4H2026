00e0|female
01ed|allergy to penicillins
0352|allergy to sulfonamides
0689|benzo overdose
07ff|intubation for airway protection
0897|34 year old
0931|woman
0978|bipolar disorder
0ae2|group home resident
0c32|apparent alprazolam overdose
0db5|lethargic
0e14|unable to give a history
0ea3|intubated for airway protection
0f89|administer charcoal
0fa4|found at group home in am laying on floor by bed unresponsive
11a4|last seen awake 8 hours prior at dinner
12a4|may have taken too many Xanax
12e9|history of suicidal ideations
1560|self mutilation
1644|feeling down
1875|impulsively ingested 5 days worth of medications
18b6|intent at that time was to end her life
194d|bipolar disorder
1981|asthma
19d3|posttraumatic stress disorder
1a0a|GERD
1a4a|chronic constipation from laxative abuse
1aef|denies any recent use of EtOH or illicit drugs
1b87|history of sporadic marijuana use
1c36|living at the DBT House
1d52|relationship with a man
1ee0|not in contact with her family
1f05|raised in multiple care homes
1f0d|mother could not care for her
1fbf|physically abused
201c|severely neglected as a child
2095|sexually assaulted
22d1|no current romantic relationship
23fb|never been married
250d|completed up to the tenth grade of high school
2613|no current legal issues
2803|substance abuse in mother
2838|substance abuse in brother
2857|history of depression
2983|suicidality
2a1a|temperature 95.4
2b54|heart rate 62
2c5e|blood pressure 99/70
2ccc|respiratory rate 20
2e15|oxygen saturation 100%
2e23|intubated and sedated
2ff3|ATNC
314f|pupils dilated at 5 mm but minimally reactive
319a|anicteric
321f|CTA ant/lat
32a3|RR nl S1 S2 no m
32e3|soft non-distended hypoactive bowel sounds
3416|WWP
35cc|multiple linear scars and burns on hands and arms
3767|sedated
3818|DTRs
382d|no rashes or petechiae
38bc|linear and burn scars
3b25|WBC 9.4
3d71|RBC 4.75
3e69|HGB 14.7
3eb2|HCT 42.2
3edb|MCV 89
3f2b|MCH 30.9
3f2f|MCHC 34.8
3f4b|RDW 13.6
4045|platelet count 330
4167|neutrophils 73.0
42a1|lymphocytes 21.8
42e9|monocytes 3.8
4483|eosinophils 1.1
44af|basophils 0.3
4672|ASA negative
46b6|ethanol negative
4741|acetaminophen negative
4794|benzodiazepine negative serum
47a5|barbiturate negative
4825|tricyclic positive
4c56|lithium less than
4ca5|digoxin less than 0.2
4cca|glucose 116
4dec|urea nitrogen 14
4e0b|creatinine 1.0
4ec3|sodium 137
4ef7|potassium 4.5
50fe|chloride 105
519d|total CO2 20
53bf|anion gap 17
5495|calcium 9.7
54be|phosphate 3.7
5512|magnesium 2.1
56ee|ALT 21
5790|AST 40
58af|alk phos 70
5967|amylase 59
5a28|total bilirubin 0.4
5d2b|lipase 66
5dfd|urine blood negative
5f5f|urine nitrite negative
5fd2|urine protein negative
601e|urine glucose negative
605c|urine ketone trace
61d1|urine bilirubin negative
61ec|urine urobilinogen negative
6228|urine pH 6.5
651d|urine leukocyte negative
6716|urine benzodiazepine positive
676e|urine barbiturate negative
6826|urine opiates negative
6827|urine cocaine negative
687a|urine amphetamine negative
6880|urine methadone negative
6978|CK CPK 4713
69af|UCG negative
6a2e|D-dimer 7998
6a31|probable atelectasis of lingula consistent with pneumonitis
6af3|NSR rate 60
6b02|normal axis
6b7d|normal intervals
6d20|incomplete RBBB
6d7d|flat T aVL V2
6da4|T wave inversion V1
703b|bilateral segmental subsegmental PEs
7085|bilateral lower extremity ultrasound negative
70e8|intubated in ED for airway protection
70f3|administration of charcoal
71d9|toxicology consulted
71e3|benzo overdose
722c|ABG revealed widened A-a gradient
729e|d-dimer was sent
7576|d-dimer elevated
7795|CTA showed bilateral pulmonary embolisms
77e6|started on heparin drip
784a|bilateral lower extremities ultrasound done
789d|negative for DVT
7904|exubated after 1 day in ICU
7a4e|painful bullae on hands and arm
7b10|swelling
7d69|dermatology consulted
7d8e|plastic surgery consulted
7e2d|symptoms due to trauma
7eb3|not felt that patient had compartment syndrome
7f90|splinted
811a|UE kept elevated
823a|put back on outpatient xanax dose of 1mg qid
834c|clozaril restarted
835b|transferred to floor
8488|patient stable
84e3|plastic surgery did not feel patient had compartment syndrome
84f1|recommended aggressive upper extremity elevation
864d|hands improved
87b3|good range of motion of left hand
87d1|poor range of motion of right hand
8991|X-ray of hands and wrist obtained
89b5|X-ray negative
89f5|seen by PT
8c98|seen by OT
8d3b|recommended hand exercises
8d42|recommended splints
8ddb|put on coumadin
8efe|bridged with lovenox
8f39|INR therapeutic
9038|continued to have SI
9196|transferred to psychiatry
9243|urinalysis suggestive of UTI
92a8|put on 6 day course of levofloxacin
92cc|propanolol XL 80mg qd
942c|modifinal 100 mg po qd
9446|lamictal 100 mg po bid
9466|alprazolam 1 mg po qid
953e|senna
9556|trazadone 200 mg po qhs
9657|clomipramine 100 mg po qhs
9783|pantoprazole 40 mg po qd
97b4|clozapine 300 mg po qhs
9925|folate 1 mg po qd
995d|multivitamin
99c0|acetaminophen 325 mg
99d3|lamotrigine 100 mg
99ff|pantoprazole sodium 40 mg
9a74|folic acid 1 mg
9b11|multivitamin
9b9f|senna 8.6 mg
9bd3|clozapine 25 mg
9cab|warfarin sodium 3 mg
9dae|docusate sodium 100 mg
9e2f|trazodone HCl 100 mg
9e48|alprazolam 1 mg
9f67|levofloxacin 500 mg
a274|bisacodyl 5 mg
a27b|nicotine 14 mg/24 hr patch
a2c2|extended care
a2c6|benzodiazepine overdose
a2f1|traumatic/pressure bullae
a2f6|bipolar disorder
a4aa|stable
a4cd|swelling in hands reduced
a577|range of motion continue to improve
a8dc|continue coumadin
a902|continue antibiotics
aa7b|keep hands elevated
aafd|admitted to psychiatry service
ad20|follow up with plastic surgery clinic in 2 weeks

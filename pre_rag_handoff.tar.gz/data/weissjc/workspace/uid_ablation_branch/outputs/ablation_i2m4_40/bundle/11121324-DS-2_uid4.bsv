0032|No Known Allergies / Adverse Drug Reactions
005c|flank pain
006f|Bilateral nephrostomy tube placement
00bd|Exchange of nephrostomy catheter on the left, with a PCN with a smaller pigtail loop
00de|Exchange of left percutaneous nephrostomy tube for 8 ___ 26 cm nephroureteral stent
0126|Exchange of existing right nephrostomy with an 8 ___/ 26 cm nephroureteral catheter
0195|Cystoscopy with ureteral stent removal
0196|Exchange of bilateral nephroureteral catheters with bilateral double-J catheters and bilateral nephrostomies
02c2|Lumbar puncture with intrathecal MTX administration
02c7|Bilateral nephrostomy tube removal
0364|no significant or chronic medical problems
0367|first admitted ~2.5 weeks ago to ___ ___ with R flank pain
03ac|readmitted on ___
03ef|transferred to ___ after developing anuric renal failure
0471|started having symptoms on ___
0495|developed sudden onset sharp pain in his right flank
04d4|saw his PCP ___ ___
056c|prescribed oxycodone
0570|prescribed ibuprofen
057f|presumed treatment of a kidney stone
0581|pain continued to worsen
05d1|evaluated in the ___ ED on ___
0686|CT showed a subcapsular hematoma
0688|no mention of stones
06ab|hospitalized
06d1|found to have hydronephrosis
070f|CT abdomen with contrast
0780|resolution of pelvic fluid collections seen prior
07a3|cystoscopy
07f8|enlarged prostate
0865|no obstruction on the right
08a5|stent was placed
0910|sent home on ___ with ciprofloxacin 500mg BID x5 days
091a|pain initially improved during that hospitalization
09be|able to resume some normal physical activity
09cd|developed recurrent pain with involvement of the left flank as well on ___
0a8c|represented to the ED
0aa8|discharged home with toradol
0c00|discharged home with tamsulosin
0c50|returned to the ED with decreased urine output
0c5b|leg swelling
0ca7|ongoing right flank pain
0d26|Cr 1.78
0def|baseline of ~0.8
0e00|pos leuks
0e4e|neg nitrites
0ead|Foley was placed
0f33|good drainage of urine
0f3c|urine culture eventually was negative for growth
0f3f|7mm nonobstructing right renal stone
0fbd|none on left
1042|started empirically on IV ceftriaxone
1051|NSAIDs toxicity
10be|UTI
1103|Cr continued to rise
1174|became anuric on ___
11f3|trended up to 2.36 on ___
11fa|4.26 on ___
1230|6.73 on ___
123e|WBC 31.5 (10% bands)
1251|Hgb 13.8
1282|Plt 156
129e|K 4.7
12af|Cl 95
12bd|HCO3 20
12c1|LDH 450
1305|AST 83
130c|ALT 23
1359|albumin 3.2
1363|transferred to ___ for further workup
1399|notified of transfer
13e8|T 98.1
1423|BP 153/82
1450|HR 80
1525|RR 18
156c|O2 Sat 98%RA
169a|very uncomfortable
170b|pacing around the room
175b|hurts to lie on his right side in bed
17b8|reports no fevers
17f2|no chest pain
180d|no shortness of breath
1848|significant lower extremity edema
189d|abdominal swelling
199e|cross country skiing prior to first onset of symptoms
1a77|falls
1a9d|does not recall any direct trauma to his kidneys
1aa7|takes ibuprofen for joint pain
1aae|never takes more than 3 pills per day
1acd|Per HPI
1aef|negative
1b26|s/p Left Knee Replacement
1b2d|No family history of kidney disease
1b67|T 97.5
1b6d|BP 134/82
1bd9|HR 85
1c1a|RR 22
1c6b|SAT 99%RA
1cb8|Pain ___
1cc2|Alert
1d0e|oriented
1d24|no acute distress
1d2b|Sclera anicteric
1daf|MMM
1df7|oropharynx clear
1e94|EOMI
1f04|PERRL
1f26|Regular rate and rhythm
1f34|normal S1 + S2
1f96|no murmurs
2039|no rubs
204f|no gallops
20cb|Clear to auscultation bilaterally
20d3|no wheezes
20f9|no rales
2110|no rhonchi
216d|Soft
2179|non-tender
21fa|non-distended
23a0|bowel sounds present
23d2|no organomegaly
23fd|no rebound
242b|no guarding
24da|Right CVA tenderness
24fa|No Foley
2516|Cool feet bilaterally
2533|2+ pulses
255b|2+ pitting edema up to knee
2564|CNII-XII intact
256d|___ strength upper/lower extremities
256e|grossly normal sensation
2606|2+ reflexes bilaterally
2623|gait deferred
26bc|Tm 98.1
27fc|BP 104-126/60-66
2807|HR 60-77
2870|___
287f|100%RA
28bd|Alert
28d4|oriented
290a|pleasant
2adb|comfortable
2af0|NAD
2af2|RRR
2afc|normal S1 + S2
2b87|no murmurs
2cca|no rubs
2d5e|no gallops
2d6b|CTAB
2d6e|no wheezes
2dbe|no rales
2ddf|no rhonchi
2e59|soft
2f8b|nondistended
3020|bowel sounds present
3058|nontender to palpation throughout
3082|no organomegaly
310b|no rebound
311e|no guarding
313f|Dressing c/d/i over previous nephrostomy sites
31ca|nontender
3206|no surrounding erythema
3220|no tenderness to palpation
3223|no edema
33a7|warm and well perfused
33c7|aox3
33cd|steady gait
33d4|fluent speech
3475|central line, R, without surrounding erythema or tenderness to palpation
34a5|WBC-34.7*
3509|RBC-4.00*
355e|Hgb-11.8*
36cc|Hct-33.9*
3735|MCV-85
3750|MCH-29.5
3817|MCHC-34.8
3824|RDW-14.6
388f|Plt ___
38f5|Neuts-74*
3908|Bands-2
3922|Lymphs-2*
3956|Monos-8
3968|Eos-0
3980|Baso-0
3a03|Atyps-7*
3a11|Metas-5*
3aad|Myelos-2*
3b8c|Hypochr-NORMAL
3c11|Anisocy-1+
3c80|Poiklo-1+
3ca7|Macrocy-NORMAL
3d0f|Microcy-1+
3d22|Polychr-1+
3d2c|Schisto-OCCASIONAL
3d4d|Burr-1+
3dc3|Bite-OCCASIONAL
3de5|PTT-26.6
3e1e|Plt ___
3e36|QG6PD-14.4*
3e3b|Ret Aut-1.1*
3f53|Glucose-88
3f81|UreaN-68*
3fb2|Creat-8.6*
4048|Na-131*
4078|K-4.6
409b|Cl-95*
415c|HCO3-18*
420d|AnGap-23*
4211|ALT-19
4245|AST-58*
4273|AlkPhos-67
4281|TotBili-0.3
428d|ALT-19
42a3|AST-54*
42fb|LD(LDH)-2422*
434b|CK(CPK)-181
4370|AlkPhos-65
44bd|TotBili-0.3
44ca|Calcium-8.3*
4507|Phos-3.1
45b4|Mg-2.0
4617|Hapto-78
4684|Ferritn-1747*
46a5|Triglyc-160*
46db|HDL-17
470a|CHOL/HD-7.7
474f|LDLcalc-82
4826|HBsAg-NEGATIVE
48b5|HBsAb-NEGATIVE
494c|PSA-0.3
4a18|IgG-795
4a1a|IgA-165
4a2c|IgM-91
4ad7|HIV Ab-NEGATIVE
4b2a|HCV Ab-NEGATIVE
4b5e|Color-Amber
4b68|Appear-Cloudy
4b6e|Sp ___
4b73|Blood-LG
4b7b|Nitrite-NEG
4bd8|Protein->600
4c26|Glucose-TR
4c60|Ketone-10
4c9b|Bilirub-NEG
4ca4|Urobiln-NEG
4cce|pH-8.0
4ce1|Leuks-NEG
4d0e|RBC->182*
4d36|WBC->182*
4d6d|Bacteri-NONE
4d8c|Yeast-NONE
4dc5|Epi-0
4de9|Hours-RANDOM
4e31|UreaN-72
4e7c|Creat-12
4f45|Na-129
4f7f|K-6
4faf|Cl-95
4fb3|Osmolal-392
4fc6|WBC-70.3*
50b6|RBC-3.77*
5109|Hgb-11.4*
5139|Hct-32.5*
51a6|MCV-86
51b1|MCH-30.1
5225|MCHC-35.0
5258|RDW-15.3
5260|Plt ___
52ae|WBC-0.1*
52d7|RBC-2.40*
53db|Hgb-7.3*
54c9|Hct-20.1*
550a|MCV-84
55a1|MCH-30.6
5650|MCHC-36.5*
565e|RDW-13.4
56c0|Plt Ct-32*
56d2|QG6PD-7.8
56d4|Ret Aut-0.7*
5708|ALT-96*
5732|AST-349*
5746|AlkPhos-108
579d|TotBili-0.3
57e3|GGT-23
57f3|CK-MB-1
5803|cTropnT-<0.01
5857|proBNP-269*
58bc|CK-MB-2
58ea|cTropnT-<0.01
5934|Hapto-<5*
5958|Ferritn-1747*
599d|Cortsol-15.2
59dd|HBsAg-NEGATIVE
5a2a|HBsAb-NEGATIVE
5a8f|HIV Ab-NEGATIVE
5a9d|HCV Ab-NEGATIVE
5af9|Color-Yellow
5b14|Appear-Hazy
5bd0|Sp ___
5c35|Blood-LG
5c3b|Nitrite-NEG
5ca8|Protein-100
5d08|Glucose-NEG
5d0e|Ketone-NEG
5d6d|Bilirub-NEG
5d74|Urobiln-NEG
5e23|pH-6.5
5e5b|Leuks-SM
5e70|RBC->182*
5ee8|WBC-29*
5f0a|Bacteri-NONE
5f25|Yeast-NONE
5f92|Epi-<1
5f9f|WBC-1
5fa7|RBC-0
5faa|Polys-15
5fe3|TotProt-28
60d2|Glucose-73
60fd|CSF HOLD-PND
6120|WBC-1
615e|RBC-0
6250|Polys-0
63c2|Monos-75
63f0|Atyps-3
63f4|TotProt-23
642d|Glucose-75
6493|CD45-DONE
64f0|CD10-DONE
652c|CD19-DONE
6555|WBC-58.8*#
6574|RBC-3.22*
6581|Hgb-9.6*
65ae|Hct-29.7*
65ea|MCV-92
6604|MCH-30.0
6649|MCHC-32.5
667a|RDW-17.7*
66ce|Plt ___
672a|WBC-5.0
6740|RBC-2.98*
6767|Hgb-9.3*
6782|Hct-26.6*
679e|MCV-89
6817|MCH-31.1
6828|MCHC-34.8
68e8|RDW-17.9*
68eb|Plt ___
693a|Neuts-99*
6990|Bands-0
6a07|Lymphs-1*
6b33|Monos-0
6b6a|Eos-0
6b72|Baso-0
6bff|Myelos-0
6c0f|Glucose-71
6c51|UreaN-25*
6ce2|Creat-0.5
6d9c|Na-139
6e11|K-3.7
6f2d|Cl-101
6f5c|HCO3-23
702c|AnGap-19
7059|ALT-30
705e|AST-11
7077|LD(LDH)-274*
707d|AlkPhos-71
70d5|TotBili-0.2
715b|Albumin-3.1*
71ac|Calcium-8.2*
724c|Phos-3.6
728c|Mg-2.0
72ce|UricAcd-2.9*
739a|CULTURES x2 no growth
7486|Urine cultures x2 no growth
74b4|MRSA SCREEN: No MRSA isolated
7565|CULTURES x2 no growth
756a|culture no growth
7643|CULTURE no growth
7657|Culture no growth
7661|culture no growth
7670|C. difficile DNA amplification assay (Final ___: Negative for toxigenic C. difficile by the Illumigene DNA amplification assay
768d|culture no growth
76d4|SPINAL FLUID gram stain and culture negative, no growth (preliminary)
7713|Existing left nephroureteral catheter in good position
7730|Existing right nephroureteral catheter appears in right UPJ with incompletely formed proximal lobe, likely the source of patient's pain
77b2|Contrast within the colon from previous CT with moderate stool burden
77df|Minimal contrast extravasation from the right renal pelvis noted upon injection of the existing nephroureteral catheter
77f0|Good positioning of bilateral double-J catheters as well as bilateral nephrostomies
786d|Injection of both nephrostomies demonstrated minimal flow to the bladder suggesting incomplete obstruction
78d1|Bilateral nephro-ureteral stents in appropriate position
7916|No hydronephrosis
79a1|Mild increase in right perinephric stranding
7a05|small amount perinephric hematoma
7a22|No significant change since the prior CT in left perinephric hematoma which has decreased since ___
7a3b|Significant decrease in previously seen soft tissue density concerning for lymphoma in the pelvis, mesentery, and urinary bladder consistent with treatment response
7afc|Decreased size of left perinephric hematoma, now hypodense consistent with evolving blood products
7b7e|Trace residual right perinephric hematoma, decreased in size
7b96|Satisfactory placement of bilateral percutaneous ureteronephrostomy tubes
7b9c|No hydronephrosis
7cd6|Resolved small bilateral pleural effusions, ascites and anasarca from ___
7d3a|The left atrium is normal in size
7db3|No atrial septal defect is seen by 2D or color Doppler
7e7d|Left ventricular wall thickness, cavity size and regional/global systolic function are normal (LVEF >55%)
7ec4|There is no ventricular septal defect
7f0c|Right ventricular chamber size and free wall motion are normal
7f37|The aortic valve leaflets (3) appear structurally normal with good leaflet excursion and no aortic stenosis or aortic regurgitation
7fa4|The mitral valve appears structurally normal with trivial mitral regurgitation
7fd2|The estimated pulmonary artery systolic pressure is normal
7ffa|There is a very small pericardial effusion
8049|There are no echocardiographic signs of tamponade
8051|no clear change
8089|Right central venous line tip is at the level of lower SVC
8100|Heart size and mediastinum are stable
8131|Lungs are clear with resolution of substantial improvement at least of previously seen bilateral pleural effusions and bibasal consolidations in only minimal amount of left pleural fluid noted
815a|The previously described subsegmental pulmonary embolism within the atelectatic left lower lobe is not well seen on this study, which may be secondary to respiratory motion
82d8|No new pulmonary artery filling defects are detected
83c6|No CT evidence of right heart strain
83e6|Partially visualized left perinephric hematoma
83fe|Moderate, left larger than right, pleural effusions with associated atelectasis are similar to the prior study
8447|Solid/ground-glass opacities in bilateral lower lobes have decreased over the interval, and likely represent atelectasis
8449|No pelvic vein thrombosis
849f|Decrease in size of perinephric and retroperitoneal hematoma
84a9|Mild increase in ascites
84b1|Soft tissue masses in the pelvis and bony lesions are consistent with patient's known history of lymphoma
8504|Overall left ventricular systolic function is normal (LVEF>55%)
8521|Right ventricular chamber size is normal with normal free wall contractility
8554|There is a trivial/physiologic pericardial effusion
857b|right ventricular size and systolic function appear unchanged
8606|No evidence of deep venous thrombosis in the bilateral lower extremity veins
860e|Complex ___ cyst within the right popliteal fossa
8632|Single subsegmental pulmonary embolus within atelectatic left lower lobe
8729|Moderate left larger than right pleural effusions are similar to prior study with associated atelectasis
8774|No new solid/ground-glass opacities of bilateral lung bases more likely represent atelectasis rather than early pneumonia, however followup chest radiographs are suggested
87c1|Partially visualized left perinephric hematoma
87d3|No evidence of deep venous thrombosis in the right lower extremity veins
880c|there are slightly lower lung volumes
8856|Hazy opacification at the bases, more prominent on the left, is consistent with layering effusion and mild atelectatic changes
8872|No definite vascular congestion
88fa|Palpable area of soft tissue swelling in the left flank corresponds to subcutaneous soft tissue edema
894d|No fluid collection or nodules seen
8960|Interval increase in bilateral pleural effusions, bows non hemorrhagic
8973|Evidence of anemia
89cf|Bibasal atelectasis
8a22|Unchanged subcutaneous air predominantly in the lower neck and a minimal extent in the thoracic inlet
8a82|Left perinephric hematoma and nephrostomy
8aa5|Trace ascites
8aac|there is a moderate left pleural effusion with compressive basilar atelectasis
8b1b|little change
8b52|Exchange of left percutaneous nephrostomy tube for 8 ___ 26 cm nephroureteral stent
8c2d|No evidence of active arterial extravasation or pseudoaneurysm involving the left kidney
8c37|Embolization not performed
8cb7|Left lower lobe collapse and/or consolidation and small left effusion
8ccd|Minimal atelectasis right cardiophrenic region
8d42|Left perinephric hematoma, increased in size from ___
8db4|No active extravasation of contrast
8dc0|Satisfactory positioning of bilateral percutaneous nephrostomy tubes
8ecf|No hydronephrosis
8f06|Extensive soft tissue throughout the pelvis, mesentery and gallbladder wall, compatible with known lymphoma
8f16|Small bilateral pleural effusions, small ascites and extensive anasarca reflect volume status and have increased from ___
8f3e|Small right perinephric hematoma, unchanged
8f41|Successful exchange of a 8 ___ nephrostomy catheter on the left, with a PCN with a smaller pigtail loop
906e|Left percutaneous nephrostomy tube terminates more superiorly compared with the radiograph from ___
90f4|Diffuse heterogeneous FDG avidity within the bone marrow as well as increased FDG avidity in the spleen concerning for lymphoma, although intense marrow stimulation could be a cause of these findings
90f8|Increased FDG avidity within multiple epicardial lymph nodes
9127|Diffuse peritoneal FDG uptake, likely secondary to peritonitis; the appearance is atypical for lymphoma
913b|Increased FDG avidity surrounding the bladder with fat stranding, most compatible with infection
9145|Left perinephric hematoma
9153|The left atrium and right atrium are normal in cavity size
915f|No atrial septal defect is seen by 2D or color Doppler
91a7|There is mild symmetric left ventricular hypertrophy with normal cavity size and global systolic function (LVEF>55%)
9203|suboptimal technical quality
9244|focal wall motion abnormality cannot be fully excluded
9254|Right ventricular chamber size normal
928a|free wall motion normal
92bf|diameters of aorta at the sinus, ascending and arch levels are normal
92d7|aortic valve leaflets appear structurally normal
93ea|good leaflet excursion
941e|no aortic valve stenosis
9423|No aortic regurgitation is seen
9430|mitral valve appears structurally normal
944a|trivial mitral regurgitation
9486|no mitral valve prolapse
94dc|pulmonary artery systolic pressure could not be determined
951a|no pericardial effusion
9529|Suboptimal image quality
9613|Mild symmetric left ventricular hypertrophy
964e|preserved global biventricular systolic function
9668|No definite valvular pathology
966c|pathologic flow identified
96ba|prophylaxis is NOT recommended
9771|RIGHT PICC LINE TIP IS AT THE LEVEL OF LOWER SVC
97a0|HEART SIZE AND MEDIASTINUM ARE STABLE
97eb|NEW LEFT BASAL OPACITY
9806|SMALL AMOUNT OF PLEURAL EFFUSION
9852|NO PNEUMOTHORAX
991e|Successful exchange of left-sided percutaneous nephrostomy tube
9a06|Placement of temporary triple-lumen central line through the right internal jugular
9b5f|Mild to moderate bilateral hydronephrosis
9b89|Pre-existing right-sided subcapsular hematoma
9bb6|Appropriate placement of bilateral nephrostomy tubes
9beb|Successful placement of 8 ___ nephrostomy on both sides
9c44|Cystitis with adjacent edema
9d4c|Intrapelvic hyperdensity in particular surrounding distal aspect of right ureteral stent, is suggestive of hemorrhage
9d9f|hemorrhagic cystitis
9e4c|Moderate right hydronephrosis
9eed|without nephrolithiasis
9eff|Double-J ureteral stent appears appropriately positioend
9f00|Suspected small right lower pole subcapsular hematoma
9f17|Mild left hydronephrosis
9f91|Moderate to severe right hydronephrosis
9fba|possible 0.7 cm obstructing calculi proximal to double-J stent
9fef|Findings worrisome for stent malfunction/occlusion
9ff1|Normal right and left renal Dopplers
a064|Severe bladder wall thickening measuring up to 1.7 cm
a066|acute cystitis
a0c4|Echogenic renal parenchyma can be seen in acute renal failure
a0d4|acute renal failure
a0f5|Moderate to severe right hydronephrosis
a102|possible 0.7 cm obstructing calculi proximal to double-J stent
a108|Findings worrisome for stent malfunction/occlusion
a12e|Normal right and left renal Dopplers
a19e|Severe bladder wall thickening measuring up to 1.7 cm
a1cb|acute cystitis
a2bc|Echogenic renal parenchyma can be seen in acute renal failure
a2e3|acute renal failure
a304|IGH/BCL2 gene rearrangement
a347|rearrangements of the MYC and BCL6 genes
a36c|triple hit lymphoma
a37d|BONE MARROW WITH EXTENSIVE INVOLVEMENT BY NON-HODGKIN B-CELL LYMPHOMA
a414|lymphoma cells are large with punched out vacuoles and irregular nuclear contours with ___ nucleoli
a43c|aggressivelarge B-cell lymphoma
a4a3|Immunophenotypic findings consistent with involvement by the patient's known B-cell lymphoma
a4fd|no significant past medical history
a543|presented with right flank pain
a5f9|anuric kidney failure of obstructive etiology
a656|relieved by bilateral percutaneous nephrostomy tube placement
a65c|Obstruction was thought secondary to TLS
a6a3|diagnosis of an aggressive large B-cell lymphoma
a732|treated with 3 cycles of EPOCH and rituximab during this admission
a75b|WBC was 34.7
a7e7|continued to trend up to 51.8 on HD3
a7ef|dramatically elevated LDH to 12,000
a7f2|uric acid to 17.6
a80e|many atypical lymphocytes seen
a820|immature blasts
a82f|given Rasburicase 6mg IV
a831|Hematology/Oncology service was consulted
a83f|performed a bone marrow biopsy
a88c|transferred to the Hematologic Oncology service
a8a1|Bone Marrow Biopsy was performed
a8c7|results showed triple hit lymphoma
a8de|Treatment was initated with EPOCH on ___
a906|received BID 80 IV of methylprednisone prior to start of chemo
a909|tapered to completion on ___
a91c|tolerated the chemotherapy well
a988|treated with filgrastim 480 mcg SC after each of the first two cycles of chemotherapy
a9a7|leukopenia recovered
a9ca|required a total of 3 units of platelets
aa3c|8 units of PRBCs
aa4f|good response to chemotherapy
aa66|significant reduction in soft tissue density
aa70|LP was performed on ___ for prophylactic intrathecal methotrexate
aa7e|revealed several atypical lymphocytes
aa83|continued treatment with EPOCH + Rituximab for 3 cycles while inpatient
ab6b|cycle#3 was initiated on ___
abbb|repeat LP was performed on ___ with intrathecal methotrexate injection
ac1f|results from LP were pending at the time of discharge
ac41|Filgrastim was restarted on ___
ac4b|WBC increased from 5 to 58 on the day of discharge
ac96|continue to take filgrastim daily after discharge
ace5|establish local Oncology care with Dr. ___
ad0f|Q72hour CBC with differential while outpatient
ad7e|discharged with plans to follow up with Dr. ___ for discussion of next cycle of chemotherapy
adca|continue infectious prophylaxis with acyclovir and Bactrim
ade6|bilateral hydronephrosis
adec|suggestive obstructive etiology
ae3d|Cr continued to rise with peak at 9.1 on HD2
ae6e|bilateral nephrostomy tubes placed by ___
aea1|drain a large amount of urine
aef6|Cr quickly recovered
af0f|obstruction from lymphoma
af59|uric acid deposition of TLS versus obstruction of ureters by lymphoma itself
afd9|Intrinsic injury from NSAIDs used for pain control in weeks prior to admission were thought to have contributed
b058|treated with Rasburicase
b08d|allopurinol
b0e5|Urine culture returned no growth
b129|left PCN was replaced twice due to severe pain
b20d|PCN tube on the left side became malpositioned
b35c|expanding hematoma
b36d|stabilized
b451|resolved
b4e8|having UOP, primarily from his PCN tubes
b50d|Foley discontinued on ___
b599|limited UOP from the bladder
b676|UOP out of proportion to intake
b683|post-obstructive diuresis versus solute diuresis
b6b5|Renal was consulted
b6eb|recommended giving less IVF
b765|Follow up procedure was performed on ___ where right PCN was transitioned to a PCNU
b7cf|developed significant recurrent pain
b844|performed cystocopy and ureteral stent removal at bedside ___
b8d8|performed stent repositioning on ___ with relief of his symptoms
b9ad|underwent successful capping trial following this procedure
ba60|Bilateral PCN tubes were removed by ___ on ___
ba6f|developed leakage of urine
bb37|foley was placed
bbd4|Tamsulosin was continued
bd0f|Leakage from previous nephrostomy site improved over next ___ hours
bd79|foley catheter was removed prior to discharge
bd8b|able to void urine spontaneously prior to discharge
bda7|follow up with Urology (Dr. ___ as an outpatient
bdd9|Started vancomycin and cefepime on ___ given Tmax 100.8
bdf1|CXR without evidence of pneumonia
be25|Skin surrounding PCN tubes and central line without signs of infection
bede|Vancomycin and cefepime were discontinued on ___
bfbf|no longer neutropenic
c097|not had fever for >48 hours
c0a0|remained afebrile throughout remainder of hospitalization
c0b6|Resolved
c0ca|Triggered on ___ for HR 180s on routine VS monitoring
c1a3|tachycardia was not sustained
c1d7|HR had downtrended to 90-100s
c212|remained asymptomatic
c24d|ECG with new TWI in V3-V6
c28f|Trop/CKMB negative x2
c355|monitored on tele
c39c|HR 80-100s
c3a6|occasional bursts of HR in the 130-150s
c40b|sinus tachycardia from deconditioning and poor PO intake based on telemetry
c4d0|Tachycardia resolved on ___
c4dd|telemetry was subsequently discontinued on ___
c4ed|incidental finding of a small subsegmental PE without hemodynamic compromise
c555|no troponin elevation
c55a|no RV strain on ECHO on ___
c55f|no clot burden on LENIs and MRV abdomen/pelvis
c596|heparin gtt was not started
c63d|Cardiology was consulted
c72b|recommended against an IVC filter in the absence of an identified large clot burden
c805|Repeat CTA chest on ___ obtained in the context of tachycardia revealed no filling defect consistent with PE
c834|Further intervention decided against
c84b|maintained on DVT prophylaxis with lovenox while inpatient
c8a9|Developed dysuria on ___
c945|pain at the tip of his penis with urination
c990|irritation from multiple previous urologic procedures in combination with medications
c9d5|UA revealed many RBCs
ca0b|Urine culture was negative for infection
ca28|hemorrhagic cystitis given cyclophosphamide
ca59|treated empirically with MESNA
cb14|foley catheter was placed in the setting of leakage from nephrostomy tube sites as above
cb7a|Topical lidocaine was used for symptomatic relief
cbc3|persistent discomfort with foley in place that self-resolved
cbf0|Urine remained concentrated prior to discharge
cc8f|PO fluid intake was encouraged
ccc2|Foley was removed
cce0|able to void spontaneously without recurrence of symptoms
cda6|Resolved
cdd0|decribed pain in his throat and esophagus
ce34|worse with eating and drinking
cec3|limiting his PO intake
cfdc|treated with acyclovir and fluconazole in case of esophagitis
d03c|magic mouthwash, caphosol, cepastat as needed
d0db|nutrition was consulted for TPN recommendations
d0f8|mucositis resolved
d100|PO intake improved such that TPN was not needed
d121|EPOCH level 3 + Rituximab cycle#3 day#7 on the day of d/c (___)
d17a|repeat CBC w/diff on ___
d18d|PRBC transfusion ___ for Hgb 7.7
d1b1|daily filgrastim injections as an outpatient until instructed to stop by ___ ___ team
d1f2|prednisone taper will be ___ (10mg)
d23e|repeat LP results (performed ___, pending at discharge
d267|Establishing care with local oncologist (Dr. ___ for daily filgrastim injections and blood work
d269|follow up with ___ ___ (Dr. ___ for further chemotherapy
d336|acyclovir, Bactrim
d37e|Urology (Dr. ___ regarding stent management
d4cd|Tamsulosin 0.4 mg PO QHS
d529|ketorolac 10 mg oral tid
d54e|Tamsulosin 0.4 mg PO QHS
d6b0|Sulfameth/Trimethoprim SS 1 TAB PO DAILY RX *sulfamethoxazole-trimethoprim 400 mg-80 mg 1 tablet(s) by mouth daily Disp #*30 Tablet Refills:*0
d6f2|Acyclovir 400 mg PO Q8H RX *acyclovir 400 mg 1 tablet(s) by mouth Three times a day Disp #*90 Tablet Refills:*0
d71c|Ondansetron 4 mg PO Q8H:PRN nausea RX *ondansetron HCl 4 mg 1 tablet(s) by mouth Every 8 hours Disp #*45 Tablet Refills:*0
d735|Senna 8.6 mg PO DAILY:PRN constipation RX *sennosides [senna] 8.6 mg 1 tablet by mouth daily Disp #*30 Tablet Refills:*0
d781|Docusate Sodium 100 mg PO BID:PRN constipation RX *docusate sodium 100 mg 1 capsule(s) by mouth Twice a day Disp #*60 Capsule Refills:*0
d7c4|Filgrastim 480 mcg SC Q24H RX *filgrastim [Neupogen] 480 mcg/0.8 mL 1 syringe daily Disp #*10 Syringe Refills:*0
d7dc|PredniSONE 10 mg PO ONCE Duration: 1 Dose RX *prednisone 10 mg 1 tablet(s) by mouth once Disp #*1 Tablet Refills:*0
d7e2|Home
d847|Triple Hit B Cell Lymphoma
d89f|Anuric renal failure due to obstruction
d8a3|Clear and coherent
d90b|Alert and interactive
d96b|Ambulatory - Independent
d9ca|transferred to us with what appeared to be obstructed kidneys
d9dc|placed two tubes into your kidneys to help drain urine
daa7|helped clear uric acid from your blood (which was causing the obstruction)
dae9|underwent several subsequent procedures with the Interventional Radiology and Urology teams to exchange and reposition the tubes
db38|external tubes were removed prior to discharge
db94|leakage from these sites over the next several days
dbf5|found that you have an aggressive type of lymphoma
dbfd|closely monitored in the ICU for 24 hours for possible electrolyte abnormalities during a critical phase of your illness
dc26|started chemo with a regimen call EPOCH + rituximab
ddd2|tolerated well for 3 cycles
ddd3|lumbar puncture (spinal tap) for injection of chemotherapy that showed some abnormal cells
dde9|repeat lumbar puncture was performed prior to discharge
de26|results from this sample are still pending
de6b|follow up with Dr. ___ will be your primary Oncologist after discharge to arrange further monitoring and treatment
de7f|take a medication called Neupogen (filgrastim) that will be a daily injection for several days after discharge
de87|seen by an Oncologist that is closer to your home for these injections (see below)
deed|recheck your lab work every 3 days while you are at home
dfe8|get your first set of labs drawn on tomorrow (___)

0029|Shortness of breath
011e|fever
0152|51 year-old
0153|male
01a3|metastatic RCC
0274|left radical nephrectomy
028a|Avastin
02ee|sorafenib
02f5|Sutent monotherapy
03e7|mild renal insufficiency
0415|presented from home
055d|shortness of breath
057e|fever
05a2|chest pain
05d3|cardiac enzymes
0643|echocardiogram
07eb|pharmacological stress test performed
0906|fatigued
097b|congested in his chest
0a27|new fever
0be3|taken to the ED
0c92|mild cough for 2 days PTA
0d18|non-productive cough
0ff0|denies a history of aspiration events
110b|denies choking with food intake
11f8|mild reflux symptoms at night
1259|mild SOB in the days preceding admission
1278|surprised to find out about his low oxygen saturation
1456|denies chills
164c|no chest pain
167d|no LE swelling
16af|Tmax 102.8
1704|BP 100-140/60s
1757|HR 80s
17c7|RR 20s
1825|Sat 75% on RA in triage
1884|up to 100% on NRB
18fc|bibasilar consolidations
1914|given Levo 750 mg PO X1
194f|Flagyl 500 mg PO X1
1a1b|BP decreased to 100 systolic
1d8c|hydration with 2L of NS
1de8|admitted to the ICU for further care
1ed4|placed on Levo
1f5e|placed on Ceftriaxone
1f81|cosyntropin stimulation test
2150|cortisol 32.1-->36.4
2301|oxygen requirement decreased
2349|overall status improved quickly
2370|transferred to the floor for ongoing care
23f8|Metastatic renal cell carcinoma
2493|diagnosed in [**3-/2198**]
2495|left radical nephrectomy
252d|renal cell carcinoma of chromophobe type
2661|Lymphovascular invasion was present
26f4|presented with increasing back pain
2731|metastaticdisease was documented
281f|Avastin plussorafenib
283e|discontinued
28e2|grade III rash
28fa|involving the hands and feet
2950|proteinuria secondary to the Avastin
29f0|Sutent 50 mg daily
2a5b|completed nearly 6 cycles
2b4b|mild renalinsufficiency in the setting of Sutent
2df3|Seasonal allergies
302f|lives at home
30b7|7 years old
32d5|works in real estate development
333f|invests in stockmarket
342f|lifelong non-smoker
3668|T 96.9
3681|BP 110/70
371f|HR 84
3790|RR 20
382e|Sat 97% on 4L
384e|In NAD
3a63|Flushed cheeks
3b03|Slightly dry MM
3b68|JVP not elevated
3c24|Decreased air entry
3c69|crackles at both lung bases
3c78|Egophony
3cfc|RRR
3d4a|Normal S1, S2
3d77|No S3, S4
3e47|No murmur or rub
3e89|BS NA
3ea2|Abdomen soft and non-tender
3f31|Without edema
4093|Good pedal pulses
412d|WBC-8.0
43ed|RBC-4.22*
449e|Hgb-12.9*
4530|Hct-41.7
4666|MCV-99*
466f|MCH-30.5
47a7|MCHC-30.8*
4a1e|RDW-16.8*
4b2b|Plt Ct-797*#
4bb6|WBC-11.1*
4dc0|RBC-3.47*
4fc0|Hgb-10.9*
4fd2|Hct-34.1*
5042|MCV-98
50a4|MCH-31.3
50af|MCHC-31.9
5110|RDW-16.7*
515a|Plt Ct-604*
51ae|PT-11.2
52c4|PTT-23.9
534b|INR(PT)-0.9
53b6|Plt Ct-797*#
53fd|Glucose-134*
544b|UreaN-39*
54aa|Creat-2.1*
5510|Na-133
555e|K-7.9*
55c2|Cl-94*
5736|HCO3-28
573e|AnGap-19
5796|Glucose-73
57e8|UreaN-20
583e|Creat-1.1
5845|Na-136
5861|K-5.0
588a|Cl-101
5896|HCO3-27
595b|AnGap-13
5963|ALT-34
59f1|AST-167*
5ac8|CK(CPK)-313*
5b3f|AlkPhos-383*
5b65|Amylase-44
5ba7|TotBili-0.7
5be0|CK(CPK)-194*
5c48|CK-MB-3
5c49|cTropnT-0.05*
5deb|CK-MB-4
5e38|cTropnT-0.03*
5fa9|proBNP-258*
5fac|Calcium-8.3*
600b|Phos-4.3
6458|Mg-1.9
64c3|calTIBC-229
64e8|Ferritn-GREATER TH
658a|TRF-176*
65e4|TSH-43*
6661|Free T4-0.36*
668f|WBC-11.1*
6879|RBC-3.47*
68ec|Hgb-10.9*
6930|Hct-34.1*
6a87|MCV-98
6aa5|MCH-31.3
6b34|MCHC-31.9
6c88|RDW-16.7*
6e65|Plt Ct-604*
6f6c|Neuts-77.0*
6fb1|Bands-5.0
6fc5|Lymphs-11.0*
7184|Monos-3.0
741b|Eos-0
748d|Baso-0
751b|Atyps-1.0*
7532|Metas-2.0*
76b5|Myelos-1.0*
7744|PT-11.5
783f|INR(PT)-1.0
78eb|Glucose-73
78f7|UreaN-20
797f|Creat-1.1
7a60|Na-136
7c99|K-5.0
7d27|Cl-101
7d60|HCO3-27
7dfa|AnGap-13
7ea6|Calcium-8.0*
7eb0|Phos-3.3
7ec8|Mg-2.0
7fe4|No evidence of deep venousthrombosis in the lower extremities bilaterally
8079|New bibasilar consolidations are demonstrated
8096|bilateral small pleural effusion
815d|lungvolumes are slightly increased
819d|no pneumothoraxidentified
8250|Marked interval enlargement of the cardiacsilhouette
849a|cardiac insufficiency
849f|volume overload
8513|echocardiogram may beindicated for further evaluation
858c|Bilateral basilar compressive atelectasis
8641|Superimposedinfectious consolidation is likely
8793|tree-in-[**Male First Name (un) 239**] nodular opacities
8908|scattered ground glassopacities involving the right lung
896b|infectiousprocess
8986|viral infections
8bfd|fungal infections
8d0e|atypical mycobacterial infections
8fa8|Drugtoxicity would be a consideration
8fae|jejunal wallthickening
8fbd|distal ileal wall thickening
910f|diffuse mesenteric stranding
9126|infectious etiology
9133|stability in metastatic burden
915d|Mild symmetric left ventricular hypertrophy
916d|preservedbiventricular systolic function
9212|Mild posterior mitral valveprolapse
9295|mild mitral regurgitation
9321|Small (0.6 cm)circumferential pericardial effusion
937f|sclerotic lesion
938e|interval periosteal new bone formation involving theintertrochanteric and subtrochanteric regions
9603|No displacedfracture is demonstrated
9833|fever
9884|hypoxemia
991d|bibasilarpneumonia
99a2|treated forcommunity-acquired pneumonia
99e5|placed onCeftriaxone
9a9c|placed on Levaquin
9ab1|placed on Flagyl
9ac0|Azithromycin
9b0e|CTX
9b81|oxygen requirement
9c29|ground glass opacities
9c61|underlying infectiousprocess
9cb3|confirmed normal ejection fraction
9cd4|improved slowly
9cef|oxygen was weaned off
9d34|discharged on course of Levaquin
9e57|Sutent was held on admission in light ofacute infection
9ef0|staging CT scan torso
9f78|nosignificant increase in tumor burden
9faa|abnormal TFTs on Sutent
a00a|started on replacementtherapy
a020|need follow-up bloodwork as an outpatient
a14e|destruction of L femoral neck
a195|xray of the L femur
a1f7|acutefracture
a333|No limitations were placed in regards to weightbearingstatus
a356|instructed to restart Sutent next [**Year (4 digits) 766**]
a417|Creatinine improved from 2.1 to 1.3 attime of discharge
a41e|underlying malignancy
a46d|prerenal component given improvement with gentlehydration
a479|takes Imodium
a47a|takes Lomotil
a4be|diarrhea
a561|not had a BM in 3 days now
a590|MS Contin 45 mg PO q12 hours
a61d|Morphine 15 mg every 4 hours as needed
a6c5|Heparin 5000 UNIT SC TID
a853|Albuterol 0.083% Neb Soln 1 NEB IH Q6H
a8e0|Ipratropium Bromide Neb 1 NEB IH Q6H
a913|CeftriaXONE 1 gm IV Q24H
a992|Levofloxacin 500 mg PO Q24H
a9f5|Morphine Sulfate 2-4 mg IV Q4H:PRN
aa1e|Docusate Sodium 100 mg PO BID
aa78|Pantoprazole 40 mg PO Q24H
aad9|Fluticasone Propionate 110mcg 2 PUFF IH
aafc|Levothyroxine 50 mcg Tablet
ab44|Levofloxacin 500 mg Tablet
ac36|Docusate Sodium 100 mg Capsule
ac6e|SUTENT 50 mg Capsule
aca2|Morphine 15 mg Tablet
aeb8|Morphine 15 mg Tablet Sustained Release
b062|Home
b198|Pneumonia
b28d|Acute renal failure
b3fd|Metastatic renal cell carcinoma
b43c|Hypoxemia
b498|Stable
b4ab|admitted to the hospital
b572|started on an antibioticcalled Levaquin for a pneumonia
b7bf|continue taking thismedication
b8fe|Sutent wasstopped
bbf6|resume this medication starting [**Last Name (LF) 766**], [**7-1**]
bdc4|lowthyroid hormone levels
be0f|started on thyroidsupplements
be3f|follow-up blood tests by yourprimary care physician [**Last Name (NamePattern4) **] 3 months
bec6|fevers
bedd|chills
bfca|chest pain
c13c|shortness ofbreath
c1e1|dizziness

0049|female
007b|allergy to Bactrim Ds
00eb|allergy to Lisinopril
015f|progressive dyspnea
01e8|Thoracentesis/ Left Pleural tap (dx)
021d|Thoracentesis/ Left Pleural tap (~1400cc)
0337|Pleurex Catheter Placement with 1100 cc removed
03ef|Transthoracic Ultrasound
042c|Bronchoscopy
0437|female
043c|COPD
04c5|CAD
0537|CABG
05b5|CHF
05bc|EF 40-50%
0626|BiV ICD
0682|progressive dyspnea
06b4|cough productive of brown sputum
07a3|fevers
07cb|chills
083c|night sweats
088b|chest pain
0912|diaphoresis
097a|headache
09b7|lightheaded
09f2|decreased PO intake
0a1b|inhalers at home
0b1d|minimal relief
0c31|shortness of breath progressive
0c7d|worsened with exertion
0d00|dyspneic while eating cereal
0d51|refused
0d7f|agreed to present today
0d80|T 97.7
0e88|BP 80/38
0e9b|HR 70
0f13|RR 17
0f39|O2sat 88% on RA
0f88|O2sat improved to 95% on 2L
0fa0|500cc NS for low blood pressure
0fd2|good response to systolic 100-110
0fff|BP trended down to systolic
1004|500cc NS given
1053|good improvement in BP to systolic 110
10aa|maintenance IVF at 100cc/hr
10bc|300cc of urine output
11b3|albuterol nebulizer
1255|ipratropium nebulizer
12a2|symptomatic improvement in shortness of breath
1318|CXR showed new LLL opacity concerning for PNA
1356|adjacent parapneumonic effusion
13a1|UA negative for infection
13fe|Blood cultures drawn
1417|urine cultures drawn
141b|ceftriaxone
142a|levofloxacin
145d|acute renal failure
148d|low suspicion for PE
157f|CTA deferred
1634|admitted to the ICU
16f5|labile blood pressure in the ED
1702|feeling well
1781|breathing much improved
1822|cough
184f|chest pain
1db0|shortness of breath
1de2|dizziness
1fc1|A&Ox3
2044|speaking in full sentences without difficulty
204f|20lb unintentional weight loss over the past several months
2092|fevers
2119|chills
21b7|chest pain
223a|diaphoresis
224b|lightheadedness
22d6|dizziness
22fb|orthopnea
2427|PND
243a|edema
2506|COPD
2537|100 PYH
270d|CHF
2767|weight @ baseline 160 lbs
2806|Ischemic cardiomyopathy
2810|EF 40%
28f0|CAD
2a83|MIs
2ad3|CABG
2aff|MI
2b6b|EPS with AVRNT ablation
2bdc|RCA stenting
2c61|positive ETT-thal
2c69|MI
2cc8|CABG
2ced|Cath
2d38|EF 20% on left ventriculography
2d5c|P-MIBI
2dc6|calculated LVEF of 39%
2edc|BIV/ICD pacer
2ef6|ICD device change
2f6d|Valvular Disease
2f6f|Mild AS/AI
2fb6|Mild-to-mod MR & TR
2fb8|Hypertension
2fea|Hyperlipidemia
3081|Anemia
3198|Renal insuff
31cf|Hypothyroidism
3264|XRT for Pituitary tumor
3286|GERD
3302|Carpal tunnel
3307|Spinal stenosis
3367|Chronic lower back pain
33d7|Greater trochanteric bursitis bilaterally
343f|Osteoarthritis
349e|Polyarthritis
35b6|Hard of hearing
3684|h/o pos PPD
3723|started on INH
377b|acute INH hepatitis
377c|h/o psoriasis
37db|Right TKR
38b7|cataract O.S. w/ implant
38c8|1V CABG (mammary to LAD)
39c2|R Knee Arthroscopy
3b47|foot neuropathy
3b79|hernia repair
3cff|T 96.1
3d49|BP 130/49
3dc8|HR 60
3e2c|RR 16
3e80|O2 sat 94% on 3L NC
3f58|Elderly female in NAD
3fc2|No accessory muscle use
4034|Dry MM
413c|EOMI
423a|PERRL
42d7|JVP flat
42e9|no HJR
4324|Supple
436b|Regular rate and rhythm
4383|soft holosystolic murmur at the apex without radiation
440a|Scattered rhonchi diffusely
459d|decreased breath sounds at the LLL
45da|+egophony
4716|Dull to percussion at left base
4733|Soft
47c0|NT
47ca|ND
488e|+BS
489a|No edema bilaterally
48a6|2+ DP pulses
4917|A&Ox3
4922|nonfocal neuro exam
49a2|Guaiac negative in the ED
4a40|WBC 8.7
4a52|RBC 4.14
4a63|Hgb 12.6
4a66|Hct 38.0
4a8c|MCV 92
4b5f|MCH 30.4
4b62|MCHC 33.1
4bd6|RDW 13.9
4bfa|WBC 7.4
4c47|RBC 3.76
4d30|Hgb 11.8
4d8f|Hct 35.5
4da0|MCV 94
4da9|MCH 31.3
4e61|MCHC 33.1
4f0f|RDW 13.2
4f9c|Neuts 64.1
4fa1|Monos 5.7
4fa9|Eos 4.7
5001|Baso 0.3
51a2|Glucose 117
51f6|UreaN 43
528a|Creat 1.7
5360|Na 136
5522|K 4.9
5652|Cl 105
5660|HCO3 21
5672|AnGap 15
567f|Glucose 90
5696|UreaN 39
571a|Creat 1.6
5836|Na 140
5853|K 5.2
58b3|Cl 110
595b|HCO3 20
5962|AnGap 15
5a52|LDH 441
5b49|CK 47
5b5a|cTropnT 0.08
5c03|TotProt 6.2
5c12|Albumin 3.5
5c1c|Globuln 2.7
5c8c|Calcium 8.8
5d0f|Phos 3.8
5d55|Mg 2.2
5d82|TSH 0.29
5dbe|Lactate 1.3
5dc7|Urine Blood SM
5e30|Urine Nitrite NEG
5e54|Urine Protein 30
5eea|Urine Glucose NEG
5fed|Urine Ketone NEG
6180|Urine Bilirub NEG
628c|Urine Urobiln NEG
62b2|Urine pH 5.0
62c3|Urine Leuks NEG
62db|Urine Bacteri NONE
62dc|Urine Yeast NONE
63ea|Urine Epi 0
64c5|Pleural TotProt 3.6
6571|Pleural Glucose 93
65bb|Pleural LDH 716
65be|Blood culture no growth
65e2|Pleural fluid no growth
65e6|PLEURAL FLUID GRAM STAIN with PMNs no organisms seen
6601|CXR new left lower lung opacity concerning for pneumonia with adjacent parapneumonic effusion
6621|CXR opacification in left lower lung consistent with pneumonia
6661|CXR no major change pneumonia unchanged
6672|CT Torso moderate-to-large left pleural effusion
6673|CT Torso mediastinal lymphadenopathy
672e|CT Torso emphysema with interstitial lung disease and calcified pleural plaques
67f0|CT Head no definite intracranial metastatic lesions
67fb|Transthoracic Echo left atrium elongated
68fe|mild symmetric left ventricular hypertrophy
69dd|left ventricular cavity size normal
6a2c|LVEF 40-50% mildly depressed
6aab|right ventricular chamber size normal
6b86|borderline normal RV free wall function
6ba1|focal calcifications in aortic arch
6bd3|aortic valve leaflets mildly thickened
6be4|minimally increased gradient consistent with minimal aortic valve stenosis
6c42|mitral valve leaflets mildly thickened
6c54|no mitral valve prolapse
6cf8|trivial mitral regurgitation
701c|tricuspid valve leaflets mildly thickened
7138|supporting structures of tricuspid valve thickened/fibrotic
718c|moderate tricuspid regurgitation
71ff|moderate pulmonary artery systolic hypertension
721c|no pericardial effusion
7230|WBC 13.9
7292|RBC 3.01
733f|Hgb 9.3
738d|Hct 28.3
7407|MCV 94
748c|MCH 30.7
7492|MCHC 32.7
7494|RDW 13.3
75ad|Plt Ct 393
7639|Glu 78
7658|UreaN 52
7688|Creat 1.7
76ce|Na 141
76e8|K 5.0
76ea|BNP 2536
76f5|woman
77ed|CAD
7807|CKD
781a|COPD
795e|admitted with pneumonia
7969|hypotension
7a79|in the ICU upon admission
7a84|transferred to the floor
7abd|admitted with hypoxia
7b3e|new infiltrate on CXR
7b55|fluid-responsive hypotension
7bac|ceftriaxone in ED
7c08|levofloxacin in ED
7d2e|continued on levofloxacin monotherapy in ICU
7d41|thoracentesis revealing uncomplicated exudative parapneumonic effusion
7d8d|Cultures of blood without growth at time of transfer
7dac|pleural fluid without growth at time of transfer
7ddd|cytology positive for malignant cells
7de4|hypoxia resolved saturating low-mid 90s on room air
7f74|LLL Pneumonia community acquired and likely obstructive with effusion and hypoxia
7fd1|effusion tapped by IP dx
8017|effusion tapped 1400 cc
8082|satting at around 92% on O2 by nasal cannula
80b6|Levofloxacin 750 mg PO Q48H for 9 days
80bc|did not improve
80c2|started on Zosyn after CXR showed new R base pulmonary infiltrate
81a1|nebulizers with albuterol and atrovent q 6 hours
8221|incentive spirometry
8253|CXR showed no improvement
8313|started on prednisone 30 mg daily
83b2|improvement in patients breathing
83e6|WBC rose to 16
8423|blood cultures repeated
844c|Sputum culture sent negative
84f3|WBC increased again to 16.4
8589|blood cultures drawn
85b4|afebrile
86d8|WBC trending down
86e3|antibiotics stopped
870e|NSCLC diagnosed
87dd|Pleural fluid cytology positive for non-small cell lung cancer
87e2|confirmed NSCLC
898d|Chest/abdomen/pelvis CT showed no metastases outside the lungs
899c|Head CT without contrast showed no metastases
89b6|family meeting held to discuss diagnosis and plan
89e0|bronchoscopy
8a92|L sided Pleurex catheter placement by IP
8ccc|No endobronchial lesions noted
8d00|large amount of mucus removed from L bronchus
8d30|1100cc of blood fluid removed on this tap
8da0|600cc removed
8dda|oncology felt stage IIIB vs IV
8e50|No surgical intervention as no clear mass
8e56|No xrt at this time as no symptoms to improve
8e67|May be eligible for palliative agent +/- EGFR inhibitor
8eca|thoracic oncology to further evaluate
8f12|Acute on CKD Stage III baseline creat ~1.6
8f19|lasix 10 mg IV
8f7f|Creat did rise to 1.9 with BUN of 55
8fc1|improvement in output
8fe9|Creat peaked at 2.2 with K+ of 5.4
903f|lasix 20 mg IV
9091|Sodium Polystyrene Sulfonate 30 gm daily x2d
915a|creatinine trended down to baseline
918e|early satiety
9232|furosemide restarted at 20mg
92ca|Hypotension on admission
933b|holding Imdur
93db|holding Valsartan
9461|Remain on hold at discharge
9508|COPD wheezing prominent for several days
9577|transitioned from tiotropium to duonebs
959a|started on Prednisone 30 mg daily for wheezing
95e1|prompt improvement
9603|albuterol and atrovent nebs scheduled
972b|slow taper q 7 days by 10mg starting 20mg
97a6|CHF lasix on hold for hypotension & inc creat
97a8|lasix 20 mg IVP x1
9812|Lasix 10 mg IV given for increased congestion
9826|moderate output
9828|rise in BUN/Cr
9867|Lasix restarted at 20mg as weight increased to 168 lbs
996f|02 sat s/p thoracentesis
997e|weight 165.8 lbs
9a74|Cr slightly increased to 1.7 and K 5.0
9b19|Lasix changed to 10mg daily
9b4f|CAD s/p MIs & CABG chronic Troponin elevation has ICD
9ca5|continued on ASA
9ce0|beta blocker dose decreased due to hypotension
9d48|remained off isordil and valsartan
9dcd|SBP to 160 on day of discharge
9de3|Nausea and vomiting long-standing in AM without weight loss
9f47|worsened with constipation
9f60|severe cramping after lactulose and dulcolax po
9fb3|numerous episodes of emesis
9fe8|IV Zofran
a046|IV compazine
a05c|LFTs all WNL
a137|CT abdomen with diffuse stool but no obstruction
a1c4|symptoms improved after several bowel movements
a205|responded well to Miralax
a20e|No further nausea after relief of constipation
a21e|Osteoarthritis followed by pain clinic had injections
a275|minimal pain at rest L knee
a3f1|L knee pain with ambulation
a434|geriatrics suggested stopping neurontin
a473|scheduled tylenol
a4e5|Lidocaine 5% Patch 1 PTCH TD DAILY
a73a|Constipation significantly constipated requiring attempts at tap water enema
a7a4|Stopped meds contributing to constipation including calcium
a7af|Hypothyroidism TSH 0.29
a7ef|Free t4 0.98
a8a3|Hyperlipidemia Statin stopped as inpatient
a8ba|GERD continue home prilosec
a9a7|Anemia baseline Hct ~33%
a9d3|low as 28 after IVF
a9e4|Anemia profile not consistent with chronic disease or iron deficiency
aa78|Stool guaiac negative
aaa1|Remained stable at 29
aaa4|Advance Directives Currently Full Code
aab3|not prepared to discuss as dealing with new diagnosis of NSCLC
aac0|mentioned open to hospice in the future
ab49|Centrum 1 tab daily
abde|Lipitor 40 mg daily
ac34|Valsartan 80 mg daily
ac79|Triamcinolone topical cream
ac7c|Aspirin 81 mg daily
ac88|Lasix 40 mg daily
adef|Omeprazole 20 mg BID
adfb|Isosorbide mononitrate SR 30 mg daily
ae4f|Percocet tabs Q6H PO PRN for left CP
aea9|Tramadol 50 mg q6H PRN
aeaa|Unithroid mcg daily
af29|Neurontin 300 mg BID
af2f|Toprol XL 50 mg daily
b03e|Ipratroprium 2 puff INH QID
b058|TEDS
b0df|Bisacodyl 5 mg Tablet Delayed Release PO daily prn for constipation
b0e2|Aspirin 81 mg Tablet Chewable PO DAILY
b116|Levothyroxine 100 mcg Tablet PO DAILY
b490|Senna 8.6 mg Tablet PO HS
b4cb|Prednisone 10 mg Tablet PO once a day 20mg daily then 10mg daily x7 days then stop
b524|Polyethylene Glycol 3350 100% Powder PO DAILY
b540|Acetaminophen 500 mg Tablet PO Q8H
b570|Cholecalciferol Vitamin D3 1000 unit Capsule PO once a day
b5f2|Lidocaine 5% Patch Topical DAILY
b676|Guaifenesin 100 mg/5 mL Syrup PO Q6H prn for cough
b6b1|Zofran 4 mg Tablet PO q6h prn for nausea
b6c4|Metoprolol Tartrate 25 mg Tablet PO BID
b724|Heparin Porcine 5000 unit/mL Injection TID
b789|Ipratropium Bromide 0.02% Solution Inhalation Q6H
b83e|Miconazole Nitrate 2% Powder Topical BID
b857|Albuterol Sulfate 2.5 mg/3 mL Nebulization Q6H
b8e7|Prilosec 20 mg Capsule PO once a day
b94a|Furosemide 20 mg Tablet PO once a day one half tab
b9b6|Extended Care Facility
ba65|NSCLC found in pleural fluid consistent with adenocarcinoma
bbd5|Left pleural effusion malignant
bc33|Pneumonia
bc3f|COPD 100 PYH quit
bc6e|CHF EJ 40% weight @ baseline 160 lbs
bcd8|Acute on Chronic Kidney Disease stage III
bd5d|Ischemic cardiomyopathy EF 40-50%
be7a|BiV ICD device change
bec0|EPS
bed7|AVRNT ablation
befa|Valvular Disease
bf1f|Mild AS
bf37|Mild AI
bf60|Mild-to-mod MR
bf7a|Mild-to-mod TR
bff8|Hypertension
c02f|Hyperlipidemia
c0ae|Anemia
c0ef|Hypothyroidism
c14a|XRT for Pituitary tumor
c151|GERD
c251|Carpal tunnel
c3d2|Spinal stenosis
c3d6|Chronic lower back pain
c404|Greater trochanteric bursitis bilaterally
c4b6|Osteoarthritis, back, hips, legs per OMR
c60f|Polyarthritis
c707|? RA
c726|Hard of hearing
c7b4|pos PPD
c85d|no CXR abnl
c92c|started on INH in ___
ca5e|acute INH hepatitis
cabc|psoriasis
cb32|Right TKR
cb4d|cataract O.S.
cb9a|implant
cbba|1V CABG (mammary to LAD)
cc4e|R Knee Arthroscopy
cc62|subtotal medial meniscectomy
cc7e|lateral meniscectomy
cc7f|Stable
cce8|Neurontin stopped
cd86|fatigue
cdb9|Furosemide 40 mg qd- changed to 20mg daily
cddb|Valsartan 80 mg qd- on hold
ce6d|low bp
ce7b|Isosorbide Mononitrate 30 mg Tablet Sustained Release 24 hr (more below)- on hold
ced4|low bp
cf5b|Toprol XL dose decreased to 25mg
cf6c|collection of fluid in the lining of your lung
cf90|catheter placed to help drain the fluid and improve your breathing
cfcb|requiring oxygen to help your breathing
d026|on steroids to help your breathing
d052|tapered off over next two weeks
d160|diagnosed with lung cancer
d191|lasix dose has been changed
d1ac|calcium is currently on hold
d1db|constipation
d29f|weight > 3 lbs

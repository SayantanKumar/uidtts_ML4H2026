00c5|male
00de|No Known Allergies to Drugs
0122|none
0165|male
01dc|hypertrophic cardiomyopathy
01eb|moderate MR
0424|HTN
0557|hyperlipidemia
05cb|?CAD
05d5|echo with evidence of old inferoposterior MI
070b|mechanical fall
0710|mild L sided chest pain
0750|R wrist pain
0754|R elbow pain
07aa|R shoulder pain
08e4|fell over 2 bolts on the floor
08e7|denies chest pain
08f5|denies dizziness
0902|denies LH
0ae0|denies SOB
0b70|denies loss of consciousness
0d36|fell on outstretched R arm
0e26|onto L chest wall
0fd0|mild L sided chest pain
1041|R wrist pain
1138|R elbow pain
11af|R shoulder pain
121e|R wrist swelling
12e2|pain on L side of chest worse with pressure
12e4|mild neck pain
12f8|symptoms improved
134a|feels really well
140e|VSS
1560|AF with bradycardia
15de|Xray R shoulder normal
1868|Xray R wrist normal
18d6|Xray R elbow normal
19f2|EKG unchanged from previous
1b1e|EKG with AF
1baf|EKG with lateral STD
1c25|one set of negative enzymes
1d33|given aspirin 325mg
1e7e|admitted
20b0|INR 4.8
20cb|followed in ___ clinic
2147|went up on the dose
2307|no echo
2369|no previous cath
23a1|echocardiogram in ___
240d|severe LV outflow tract gradient
2623|moderate MR on echo
26b4|moderate left atrial enlargement
26d7|old inferoposterior infarction on echo
274f|LVEF 55-65%
27e6|HOCM
27f5|recurrent Afib/Aflutter
2937|DCCV
2982|DCCV
2ad2|return to afib despite amio therapy
2bbc|no longer on amio
2d19|bradycardia
2f98|elevated PSA
313c|HTN
31a1|hyperlipidemia
32de|moderate MR
33ce|Hearing impairment (deaf mute)
34ab|chronic first degree AVB
3531|no family history of premature coronary artery disease
3554|no family history of sudden death
35b4|temperature 97.5
37b2|blood pressure 132/60
38e6|heart rate 63
393d|respiratory rate 18
3951|oxygen saturation 96% room air
39aa|NAD
3dd0|Oriented x3
3e65|Mood, affect appropriate
3f07|NCAT
3f16|Sclera anicteric
3fd5|PERRL
3fe6|EOMI
41d0|Conjunctiva pink
41ec|no pallor
4212|no cyanosis of oral mucosa
42b8|No xanthalesma
42d4|moving neck in all directions with full ROM and without pain
4375|No JVD
4448|PMI somewhat laterally displaced
4452|bradycardic rhythm
4496|irregular rhythm
44c2|normal S1
44f2|normal S2
4575|III/VI systolic harsh diamond shaped murmur
45cb|II/VI holosystolic murmur over apex radiating into axilla
466d|No thrills
46f4|no lifts
472e|No S3
47c7|No S4
47eb|No chest wall deformities
4942|no scoliosis
497c|no kyphosis
4984|Resp unlabored
4aca|no accessory muscle use
4bfe|CTAB
4c16|no crackles
4d22|no wheezes
4d88|no rhonchi
4f08|pain on L side of chest worse with pressure on exam
4f8b|Soft
5105|NTND
514f|No HSM
5179|no tenderness
5292|No c/c/e
53af|No femoral bruits
54da|moving all extremities with no difficulty including RUE
550f|+ stasis dermatitis bilaterally
558a|No ulcers
558e|no scars
5619|no xanthomas
565f|Right Carotid 2+
566a|Right Femoral 2+
57bb|Right Popliteal 2+
5884|Right DP 1+
588d|Right ___ 1+
5893|Left Carotid 2+
599e|Left Femoral 2+
5a7a|Left Popliteal 2+
5b47|Left DP 1+
5cf6|Left ___ 1+
5cff|CK(CPK)-85
5d24|CK-MB-NotDone
5df7|cTropnT-<0.01 at 05:00PM
5e22|GLUCOSE-87
5e48|UREA N-22
5e65|CREAT-0.7
5e93|SODIUM-141
60fb|POTASSIUM-4.0
62f4|CHLORIDE-106
635b|TOTAL CO2-25
6390|ANION GAP-14
649b|CK(CPK)-113
663f|cTropnT-<0.01 at 10:30AM
6854|CK-MB-6
69c1|WBC-9.8
6aa1|RBC-4.82
6b78|HGB-14.9
6b8f|HCT-43.3
6c56|MCV-90
6e3d|MCH-30.8
6e92|MCHC-34.4
7030|RDW-14.2
70b7|NEUTS-76.0
70f8|LYMPHS-16.2
714c|MONOS-6.1
7189|EOS-1.3
7272|BASOS-0.3
7273|PLT COUNT-275
7392|PT
747c|PTT-45.5
7512|INR lab
7571|male
7647|hypertrophic cardiomyopathy in BHC
77f8|moderate MR in BHC
7892|HTN in BHC
792b|hyperlipidemia in BHC
7aa0|?CAD in BHC
7b68|echo with evidence of old inferoposterior MI in BHC
7dc7|mechanical fall in BHC
7e12|mild L sided chest pain in BHC
7f05|R wrist pain in BHC
7f42|R elbow pain in BHC
7fd4|R shoulder pain in BHC
817d|supratherapeutic INR
8182|admitted in BHC
8190|echo in ___ with evidence of old inferoposterior MI in BHC
822c|no cath
8240|no echo here
8536|HTN as risk factor
853e|dyslipidemia as risk factor
85bb|ruled out with 3 sets of enzymes
872f|monitored on telemetry without events
874c|starting aspirin as outpatient
8772|last echo with preserved EF
87f1|no s/s of volume overload
8862|no diuresis indicated
888b|bradycardic as previously known on current regimen
8894|asymptomatic bradycardia
889c|refused pacemaker
88b7|decreasing dose of rate controlling drugs
897c|held coumadin on admission
8a5b|restart coumadin when INR<3
8ade|restart 2mg on ___
8b76|f/u in ___ clinic
8d0f|films negative
8d5b|pain minimal
8d6f|tylenol prn
8e4e|evaluated by ___
8ec1|discharged to home without services
8f92|held coumadin for INR
9171|no sign of bleeding
927e|FFP not indicated
93e0|FFP not given
9678|cont BB
971f|cont CCB
979e|cont statin
97db|atenolol 25mg daily on admission
97f5|verapamil 180mg daily on admission
993a|simvastatin 20mg daily on admission
9af1|Finasteride 5 mg daily on admission
9b35|warfarin ?dose on admission
9b6c|Simvastatin 10 mg Tablet at discharge
9c5b|Finasteride 5 mg Tablet at discharge
9ca3|Atenolol 25 mg Tablet at discharge
9da1|Verapamil 180 mg Tablet Sustained Release at discharge
9e41|Home
9ec9|R wrist pain s/p fall
9f8d|R elbow pain s/p fall
a0ac|R shoulder pain s/p fall
a118|supratherapeutic INR discharge diagnosis
a175|L sided reproducible, non-cardiac chest pain
a22f|HOCM discharge diagnosis
a249|recurrent Afib/Aflutter discharge diagnosis
a568|bradycardia discharge diagnosis
a65a|elevated PSA discharge diagnosis
a6d9|HTN discharge diagnosis
a8ba|hyperlipidemia discharge diagnosis
a8e6|moderate MR discharge diagnosis
a93b|Hearing impairment (deaf mute) discharge diagnosis
a9c7|chronic first degree AVB discharge diagnosis
aa33|Stable
ab03|admitted to make sure you did not have a heart attack
aba4|did not have heart attack
abb1|fever
ac08|chest pain
ac9f|shortness of breath
ae96|No changes to medications
aee8|do not take coumadin until ___ night
afda|restart coumadin at 2mg daily
b080|INR check

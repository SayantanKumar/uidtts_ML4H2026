012e|Sulfa (Sulfonamides) allergy
01d2|Nausea
01d4|vomiting
02d5|Abdominal pain
0307|distention
0348|Subtotal colectomy
036c|end ileostomy
0472|Hartmann's pouch
04ad|G-tube
04b1|Completion sigmoid colectomy
05ce|repair of colovesicular fistula
06f1|small bowel repair
0713|84 year old
0830|female
085c|abdominal pain
0a81|diarrhea
0c1b|nausea
0cd9|vomiting
0d74|presented to an outside hospital
0dec|transferred to [**Hospital1 18**]
0edf|bowel obstruction
1127|ischemia
11cc|worsening abdominal distention
1224|worsening abdominal pain
12af|CAD s/p MI
12f7|HTN
133e|DMII
1341|in the same building with daughter
137d|Afebrile
1551|VSS
15f4|A&O X 3
184b|NAD
1852|RRC
188b|CTAB
189b|mildly decreased breath sounds b/l
18c1|Abd soft
18d9|NT/ND
18e7|+ bs
19a4|no masses
1a3d|ostomy in RLQ pink
1a45|with stool
1b66|G-tube in place
1b99|LE trace edema
1c08|WBC-10.2
1d11|RBC-5.32
1e2d|Hgb-14.9
1e79|Hct-43.4
1ed8|MCV-82
207e|MCH-28.0
209b|MCHC-34.4
21e1|RDW-16.0*
2285|Plt Ct-204
2293|PT-12.9
22c5|PTT-32.5
22f6|INR(PT)-1.1
247f|Glucose-345*
24b5|UreaN-34*
25c9|Creat-1.0
28be|Na-137
29b3|K-4.3
29de|Cl-99
29fc|HCO3-24
2a59|AnGap-18
2a9b|ALT-17
2b1c|AST-27
2f2b|AlkPhos-119*
2fb6|Amylase-27
304a|TotBili-0.9
31f4|Lipase-11
326c|CK-MB-7
32bd|cTropnT-<0.01
3319|cTropnT-0.21*
3351|CK-MB-35*
33b9|MB Indx-25.5*
34e1|cTropnT-0.45*
351c|cTropnT-0.55*
3523|cTropnT-0.42*
355b|cTropnT-0.45*
3634|CK-MB-3
3838|cTropnT-0.19*
390a|cTropnT-0.17*
3981|cTropnT-0.06*
39f5|VRE
3a5e|Markedly dilated colon throughout ascending, transverse, and descending colon with air-fluid levels
3cd0|pneumatosis in the ascending colon
3cfa|Sigmoid diverticulosis
3d60|focal narrowing of the sigmoid colon just distal to the dilatation
3d73|wall thickening
3e3c|diverticulitis
3f48|leading point of obstruction
3f69|underlying mass lesion or cancer cannot be excluded in this area
3f94|sigmoid-vesicle fistula
404d|Small amount of ascites
413e|Bilateral renal cysts
426d|Heavy calcification of the aorta and SMA and its branches
4295|atherosclerosis
4452|assessment of the intraluminal process of these branches is limited
4454|No evidence of pulmonary embolism
44e0|Small bilateral pleural effusions
4554|compressive atelectasis
45bb|Left lower quadrant thick-walled peripherally enhancing fluid collection
4680|abscess
47bc|Moderate intraabdominal ascites
47c8|without evidence of small-bowel obstruction
48c0|Distended gallbladder
49ee|Diverticulosis within the right remnant sigmoid colon
4a64|no leak
4bb6|admitted on [**2139-12-19**] from an outside hospital to the ICU
4bb8|Developed confusion during her first 5 days in the ICU
4c40|mental status improved
4c79|Intermitent delirium throughout admission
4cb3|Required restraints to prevent DC of pertinent therapies while in the ICU
4ff1|AAOx3
5120|Complained of chest pain during first few days of admission
530f|cardiology consult was obtained
5344|recieved serial enzymes
5397|EKGs
53fc|Troponins remained mildly elevated as high as 0.6 throughout her admission
5505|most recent result now 0.1
5507|treated in IUC for unstable angina with nitroglycerin
55e0|recommended to maximize her medical treatment with Beta blockers, aspirin, a statin and an ACE Inhibitor
5652|Required diuresis of >9L while in the ICU, after 2nd surgery
5682|Continues to have trace lower extremity edema
57a4|recieves lasix po
58ca|intubated briefly post-op subtotal colectomy
58fb|again for several days after second surgery
59e3|Recieved nebulizer treatments post-op in the ICU, after successfully extubated
5aaa|dilated [**Last Name (un) 2432**] colon
5aae|wall thickening
5ac2|pneumatosis
5b56|treated nonoperatively with IV fluids
5ce8|antibiotics
5d48|serial exams
5d92|NGT decompression
5e1a|flexible sigmoidoscopy was performed for colonic decompression
6019|colonscopy was performed for decompression
6081|pseudomembrane
6093|friable colonic tissue
616b|remained tender
619e|distended
6224|Subtotal Colectomy
632a|G tube
638b|ileostomy
639a|pink and intact
639c|draining green-brown soft stool
63fb|continued uneventfully in the ICU
6434|transferred to the floor POD#6
65f0|developed additional abdominal tenderness
67ac|distention
67ce|HCT dropped
6829|1 unit PRBCs
6871|Geriatric consult was obtained to assist with management
6874|CT scan was obtained
691d|abcess
69df|colovesicular fistula
6b80|exploration and drainage
6b9d|further resection of remaining colon
6bc9|repair of a leak from [**Doctor Last Name 3379**] pouch
6c65|repair of colovesicular fistula
6dc3|improved steadily
6f43|soft
7082|nontender
7097|remained on IV antibiotics x 14 days
70c4|required pressors for the first few days post-op
70fc|clean
717a|dry
7305|intact
73fb|staples removed on POD#27/18
742d|had a foley catheter from the time of admission
7609|cystoscopy
760f|no leak
764e|dc'd
768c|suffered significant deconditioning since admission
76f4|consisitently recieved PT
7801|held NPO at admission
78ed|initiated on TPN by HD#3
7937|began on TFs
7938|TPN was weaned down
79c9|having high residuals on TFs
7a62|TPN was reinitiated
7c1b|Tf's were dc'ed prior to second surgery
7e52|resumed TF's
7eb3|TPN was tapered again
7f63|TF goals were achieved
800c|TPN dc'ed
8046|diet by mouth was initiated
82d7|tolerating a regular diet
837b|TF's at goal
847e|insulin dependent diabetic
852e|followed by [**Hospital **] Clinic for treatment of persistent hyperglycemia
857a|pain was controlled with IV pain medicines while in ICU
85a4|adequately controlled with Tylenol
8612|Motrin
870a|Oxycodone by mouth
881b|transferred to [**Hospital Ward Name 121**] 9
8a30|continued to progress well with PT
8a36|increasing PO intake
8b11|tolerating TFs
8daa|weaning from nasal cannula oxygen
8ddc|remained stable
8df6|no acute events
8f50|discharged to rehab on POD# 27/18
8f8e|Norvasc
90e4|Atenolol
910c|Isosorbide
913c|Lasix
9390|Insulin
939c|Heparin (Porcine) 5,000 unit/mL Solution
9637|Acetaminophen 325 mg Tablet
9641|Polyvinyl Alcohol-Povidone 1.4-0.6 % Dropperette
972d|Metoprolol Tartrate 25 mg Tablet
973d|Aspirin 81 mg Tablet, Chewable
973e|Atorvastatin 10 mg Tablet
9777|Lisinopril 5 mg Tablet
9808|Furosemide 40 mg Tablet
9811|Ipratropium Bromide 17 mcg/Actuation Aerosol
9838|Albuterol 90 mcg/Actuation Aerosol
9a06|Oxycodone 5 mg Tablet
9ad4|Docusate Sodium 100 mg Capsule
9b25|Potassium Chloride 20 mEq Tab Sust.Rel. Particle/Crystal
9b8e|Glargine
9c08|Miconazole Nitrate 2 % Powder
9c85|Miconazole Nitrate 2 % Cream
9def|Ibuprofen 100 mg/5 mL Suspension
9eff|Debrox 6.5 % Drops
a010|Trazodone 50 mg Tablet
a073|Extended Care
a087|[**Last Name (un) **] Colon
a24e|Diverticulitis
a264|Subtotal Colectomy
a291|Ileostomy
a2fd|Gastrostomy tube
a33c|Exploratory laparotomy
a382|resection of small intestine with primary anastomosis
a3e0|Sigmoid colectomy
a42a|repair of colovesicular fistula
a4ee|Unstable Angina
a4ef|stable
a59a|chest pain
a5b3|shortness of breath
a67f|fever greater than 101.5
a7ef|foul smelling or colorful drainage from your incisions
a82d|redness or swelling
a991|severe abdominal pain
a9b2|distention
aa32|persistent nausea
aa4a|vomiting
ab58|inability to eat
abf1|drink
ac54|No tub baths
adb6|swimming
ae09|shower
afa6|clear drainage from your incisions
afb2|No heavy lifting of items [**10-5**] pounds
afed|Resume your home medications
b080|take a stool softener, Colace 100 mg twice daily as needed for constipation
b1d2|given pain medication which may make you drowsy

0146|Admission Date 2125-1-19
063e|Discharge Date 2125-1-24
0aa3|Male
0da7|39 year-old
0ec8|gentleman
122c|admitted on 2125-1-19
1412|referred from Hospital3 29903
1419|hyperlipidemia
1888|smoking
19f4|acute onset of chest pain
1a6e|radiation to the left arm
1bd9|nausea
1cb1|Symptoms resolved spontaneously
1d15|taken to the Cath Lab
1d18|stent procedure to the RCA
1e1d|guidewire entrapment inside of a stent
1e42|thoracotomy with bypass
205e|excision of the wire
2256|coffee ground emesis
228a|bleed from femoral access site
2364|Gastroenterology was consulted
2372|recommended Protonix
2394|felt it was due to peptic ulcer disease
25e0|Hepatitis B
25f8|Hypercholesterolemia
27df|Fatty liver resolved
29c2|Lipitor
2f6f|no known drug allergies
332d|smokes one pack per day
354c|works as a jeweler
3642|lives at home with his wife
376b|Not significant for coronary artery disease
392a|diagnosed as having an acute myocardial infarction
3d02|taken emergently to the operating room on 2125-1-20
3ee6|CABG
40ad|right coronary endarterectomy
41be|removal of RCA stents
4348|retrieval of the aortic guidewire
4388|did well
4471|transferred to the Cardiac Surgery Intensive Care Unit
4782|on pressor support of Neo-Synephrine
47aa|extubated
4ba8|slowly weaned off Neo-Synephrine
4e2f|transferred to the floor on 2125-1-22
5057|chest tube had been discontinued
5181|wires were discontinued on 2125-1-23
52c8|Foley catheter was discontinued
55e2|seen by Physical Therapy
5a00|electrolytes were repleted
5aa8|discharged home on 2125-1-24
5af7|tolerating a level V
5bb9|Lopressor 25 milligrams po bid
5e35|Lipitor 20 milligrams po q HS
5fe4|Niferex 150 milligrams caplet one cap per day
6474|Protonix 40 milligrams po q day
649e|Colace 100 milligrams po bid
6528|Percocet one to two tablets q four H prn for pain
655b|Plavix 75 milligrams po q day times three months
6627|Aspirin 325 milligrams po q day
6832|Lasix 20 milligrams po times 30 days
68d8|KCL 20 milliequivalents po q d times three days
693b|follow up with Dr. PCP and his cardiologist in 3 weeks

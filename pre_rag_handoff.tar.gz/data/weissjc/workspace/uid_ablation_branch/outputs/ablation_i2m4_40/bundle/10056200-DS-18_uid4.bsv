02d2|No Known Allergies / Adverse Drug Reactions
0448|skateboarding accident
04f9|grade ___ splenic laceration
0766|none
07b7|no past medical history
07db|fall from skateboard
07e6|riding skateboard pretty fast
097d|tried to swerve
09a0|fell off board onto concrete
09a2|landing on L chest/abdomen
0bda|pain immediately after
0c16|pain was so bad
0fb7|felt lightheaded
10f3|sweaty
11db|sat down
167d|witnessed LOC appx 30seconds per report
1705|returned to baseline MS
1993|no seizure-like activity
1afb|T98
1afd|HR95
1bae|BP129/76
1dc7|R20
1e2e|O299%
1e5e|FAST positive
1e87|grade III splenic laceration
1f82|no other abnormalities
2163|Admitted to ___ for monitoring and serial Hcts
225d|negative Stox
26e3|elevated WBC 14.8
27aa|H/H 13.8/40.1
27bf|received dilaudid 1mg
2830|received zofran 4mg
2ad1|VS 79 109/64 14 96% RA
2aeb|Repeat H/H ___
2cb1|some moderate pain in LUQ
2e88|no complaints
2f19|none
3157|Temp: 98
31e1|HR: 95
3280|BP: 129/76
32b2|Resp: 20
352d|O(2)Sat: 99
355d|Uncomfortable appearing
3816|pale
38f4|mildlydiaphoretic
3944|Left chest wall with tenderness to palpation of theleft anterior lower ribs
3976|no appreciable crepitus ordeformity
3a17|Cardiovascular
3a26|Normal Cardiovascular exam
3b11|Soft, guarding LUQ
3bda|no ecchymosis
3caa|Normal Extr/Back
3cad|patches of scaling rash on erythematous base c/wpsoriasis
3cf6|Normal Neuro
3eb1|Normal Psych mentation
3f48|PTT-27.5
3f4c|PLT COUNT-289
4166|NEUTS-90.3
41bb|LYMPHS-7.1
42bd|MONOS-2.4
4349|EOS-0.1
4448|BASOS-0.2
4579|WBC-14.8
4685|RBC-4.64
48b5|HGB-13.8
49de|HCT-40.1
4b5a|MCV-86
4c37|MCH-29.7
4d69|MCHC-34.4
4dd7|RDW-12.4
4e13|ASA-NEG
4e53|ETHANOL-NEG
4e5d|ACETMNPHN-NEG
511d|bnzodzpn-NEG
515b|barbitrt-NEG
516a|tricyclic-NEG
5297|estGFR-Using this
537d|GLUCOSE-226
5563|UREA N-15
5626|CREAT-0.7
5683|SODIUM-136
56d9|POTASSIUM-4.5
575e|CHLORIDE-102
57b3|TOTAL CO2-26
5811|ANION GAP-13
591a|RBC-12
5940|WBC-1
59e8|BACTERIA-NONE
5ae4|YEAST-NONE
5c2a|EPI-0
5c90|BLOOD-TR
5ccb|NITRITE-NEG
5e35|PROTEIN-TR
5f6c|GLUCOSE-NEG
5f73|KETONE-NEG
5fa0|BILIRUBIN-NEG
6094|UROBILNGN-NEG
61c8|PH-7.0
62c3|LEUK-NEG
64e7|COLOR-Yellow
6511|APPEAR-Clear
658d|SP
65a0|PLT COUNT-324
660f|NEUTS-91.4
6708|LYMPHS-6.3
678e|MONOS-2.2
6816|EOS-0
685b|BASOS-0.1
68d9|WBC-18.5
6a07|RBC-4.18
6a20|HGB-12.3
6a2d|HCT-36.4
6ab4|MCV-87
6ab6|MCH-29.5
6b0e|MCHC-33.8
6bdf|RDW-12.6
7299|HGB-13.0
7600|calcHCT-39
76f2|HCT-31.3
77e3|admitted to the acute care/trauma surgery service
781e|management of his grade ___ splenic laceration
786e|admitted to the trauma surgery ICU initially
7a4c|closer observation
7d4e|made NPO
7de1|IV fluids
7fbd|bedrest
80dd|Hematocrits were checked every 6 hours
8261|remained stable in the low ___
8298|monitored closely on telemetry
82f1|remained hemodynamically stable
82f5|pain was controlled with IV dilaudid
835c|hematocrit remained stable
84eb|hemodynamically stable
8555|clinical exam was improved
8602|transferred out of the ICU to the floor
8633|given a regular diet
8770|continued to improve
8886|discharged
88b6|None
8a2c|OxycoDONE (Immediate Release)
8b38|Home
8b58|Grade ___ splenic laceration
8c00|Stable

0089|Admission Date [**2173-6-14**]
010f|Discharge Date [**2173-6-17**]
011c|Date of Birth [**2126-10-2**]
025c|Sex M
02fa|Allergies Penicillins
0536|Dyspnea
0567|None
0671|46-yo-man
0711|active cocaine use
078b|LE edema
07fa|developed b/l LE edema
084b|gotten progressivelyworse until now
0902|developed dyspnea onexertion
0b1e|climbing stairs
0b21|2-pillow orthopnea
0b9c|PND
0c4f|denies any recent chest pain
0e7d|palpitations
0f4d|headache
1075|confusion
10ba|weakness
110f|numbness
113a|abd pain
1199|hematuria
11e4|No recent viral syndromes
1226|URIs
1381|cocaine use last night
139a|present to the EDfor evaluation
13e9|BP was 230/170
16b5|BNP was elevated at 7500
17c1|evidence of cardiomegaly
17e7|pulm edema
188d|ASA 325 mg
18a9|lasix 10 mg IV
195a|hydralazine 10 mg IV x 2
19e1|responded well to lasix w/ good UOP
1a19|diastolic BPremained elevated at 170
1a58|initiation of nitroprussidegtt
1bf3|admitted to the CCU for further care
1e78|none
1e97|current tobacco use
1e9a|Drinks 3-4 beers a fewtimes weekly
1f2a|no h/o withdrawal symptoms
1f6d|seizures
1fe9|DTs
2033|Snorts cocaine 1-2 times monthly
2084|Never injected drugs
2212|no family history of premature coronary artery disease
22b3|sudden death
23b8|BP 181/122
2569|HR 84
27cf|RR 12
2b37|O2 98% 2L/m
2b99|lying flat in bed
2c18|pleasant and conversational
2c8b|NAD
2cec|NCAT
2da2|Sclera anicteric
30fc|PERRL
3172|EOMI
319c|OP clear w/ MMM
3776|Supple with JVP of 8 cm
378a|reg s1
3854|loud s2
3959|2/6 systolic murmur radiating to axilla
3988|no s3/s4/r
39a3|CTA b/l
3b73|no crackles
3b96|wheezing
3bc0|obese
3bcb|+BS
3c1a|soft
3c39|NTND
3da7|warm
3ef2|2+ DP b/l
3f75|2+ pitting edema to knees b/l
3ffd|a/o x 3
3ffe|CN 2-12 intact
4038|WBC-7.7
41a0|RBC-5.00
42a8|HGB-15.0
42f4|HCT-42.8
4552|MCV-86
456b|MCH-30.0
4786|MCHC-35.0
4813|RDW-14.6
48b8|PLT COUNT-315
493b|CK-MB-4
4a1f|proBNP-7489*
4a91|cTropnT-0.02*
4ac1|ALT(SGPT)-77*
4b41|AST(SGOT)-60*
4c64|CK(CPK)-195*
4cb2|ALKPHOS-104
4cea|AMYLASE-100
4ef9|TOT BILI-0.4
4f42|NSR at 87 bpm
4f46|nl axis
5459|nl int
5635|LVH w/ strainpattern
5693|no ischemic changes
56b5|Moderate to severe enlargement of the cardiac silhouette
579f|pulmonaryvascular  congestion
5854|mild pulmonary edema consistent withheart failure
59a4|left atrium is moderately dilated
5a6b|moderatesymmetric leftventricular hypertrophy with mild cavity dilation and severeglobalhypokinesis
5aef|No left ventricular thrombus is seen
5d89|increased left ventricular filling pressure(PCWP>18mmHg)
5dd1|mildly dilated with severe free wallhypokinesis
5f44|minimally thickened
5f99|No aorticstenosis oraortic regurgitation is seen
6128|structurallynormal
63b5|There is no mitral valve prolapse
645a|Mild (1+) mitralregurgitation isseen
64bd|moderate pulmonary artery systolic hypertension
64ce|circumferential pericardial effusion
6b57|Moderate symmetric eft ventricular hypertrophy withsevere globalbiventricular hypokinesis c/w diffuse process (toxin, metabolic,cannotexclude myocarditis; in the absence of LVH on ECG, aninfiltrative processshould also be considered)
6c67|Mild mitral regurgitation
6e92|Moderate pulmonaryarterial hypertension
6f2f|Very small circumferential pericardialeffusion
7156|Possible abnormality on the aortic valve as described abovewithout aorticregurgitation
727a|46-yo-man w/ cocaine abuse presents w/ LE edema and DOE likelyfrom diastolic heart failure in the setting of cocaine usecomplicated by hypertensive urgency
72d3|BP 230/170 on presentation
7398|chronic HTN exacerbated by cocaine use
73e2|No signs ofend-organ damage at present except for elevated creatinine,which is more likely a chronic problem
7476|startedon labetalol
7478|Lisinopril
752b|blood pressure was taken downfrom 230 systolic to approx 160 systolic/100 diastolic ondischarge
787e|lower extremity edema improved with diuresis
7896|LF EF of 25%
7a33|creatinine on admission was 1.6 Likely acutehypertensive nephropathy plus probalbe long-standinghypertensive disease
7c2a|discharged on ACE-I
7cf2|Social work saw patient and counceled himregarding substance abuse
7d3f|cardiology follow up
7d56|scheduled appointment with a new PCP @ [**Street Address(1) 11615**]Health Center
7ee7|none
8112|Aspirin 325 mg Tablet Sig: One (1) Tablet PO DAILY (Daily)
817f|Hydrochlorothiazide 25 mg Tablet Sig: One (1) Tablet PO DAILY(Daily)
8281|Labetalol 200 mg Tablet Sig: Two (2) Tablet PO BID (2 times aday)
84ce|Lisinopril 20 mg Tablet Sig: One (1) Tablet PO DAILY (Daily)
855a|Home
889c|hypertensive emergency
8cd2|ARF
8eba|mild transaminitis likely [**2-19**] etoh and cocaine abuse
8f72|cocaine abuse
9041|lower extremity edema improved
9081|well
911c|came in with hypertensive emergency
915b|treated withmedications to improve your blood pressure
91c2|discharged on Lisinopril 20mg daily
9257|HCTZ 25mg daily
94f2|Labetalol 400mg [**Hospital1 **]
9522|ASA 162mg daily
977a|take these medications
9a40|followup with your cardiology
9aa4|return to the ED if you experience SOB
9b2e|chest pain
9b39|fevers
9bff|chills
9c82|dizziness
9d8c|decreased urine output
9df3|abstain from cocaine use
9e73|see Dr. [**Last Name (STitle) 171**] on Monday [**2173-6-21**] at 10:00 in [**Hospital Ward Name 23**] 7th
9e7f|Primary Care Physician [**Last Name (NamePattern4) **]. [**Last Name (STitle) 11616**] on [**6-25**] @ 1:45pm
9f89|followup with Dr. [**First Name8 (NamePattern2) **] [**Last Name (NamePattern1) 171**] on [**7-12**] at 10:30am

00d0|male
0150|No Known Allergies to Drugs
02d4|Acute Renal Failure
0381|Hypocalcemia
0445|None
0502|male
0595|ESRD
0622|kidney transplant in ___
0714|IS
0715|HCV infection
078a|celiac disease
07ba|presents from ___ clinic
0830|failure to thrive
08bc|severe electrolyte abnormalities
0969|decreased appetitie
09ad|weight loss
0bca|anxiety over his medical conditions and living situation
0cbb|loose stool
0dee|fatigue
0e48|denied f/c
0f1a|denied night sweats
0fec|denied SOB
10c9|denied cough
110a|denied CP
115d|denied n/v/d
1259|denied abd pain
125c|denied edema
12ec|denied rash
134d|muscle cramps
14db|seen in ___ clinic in ___
14f7|started on megace for his appetite
16ca|intervally improved on follow up today
1763|hypocalcemia
17eb|hypomagnesemia
1830|hypophos
189b|acute on chronic renal failure
191b|referred to the ED for further work up
195d|T 98
19e0|HR 63
1ce8|BP 130/65
1e3c|RR 16
1eb4|100%RA
1ebb|slightly prolonged QTc
1f0e|given NS
205e|40meq KCl
20af|20meq KCl
20ff|3g Cal gluconate
21aa|800mg Mg
2283|2 pkts neutraphos
23ca|ESRD
2430|kidney transplant in ___
2664|deceased donor
27dc|IS
27e4|HCV infection
2837|not currently being treated
2853|no evidence of cirrhosis
287c|Celiac Sprue
29e2|+ PPD
29f6|9 months INH
2b12|Osteopenia/osteoporosis
2b52|Anxiety
2bea|HTN
2cbe|Patient unaware of any significant history
2cee|T 97.9
2d0b|BP 129/82
2df3|HR 64
2e7a|RR 20
301c|100%RA
30da|awake and alert
310d|tired appearing
3140|cachectic
315b|temporal wasting
31ed|EOMI
32f4|anicteric sclera
33d6|MMM
341f|OP clear
347f|Chvostek negative
351d|supple
35a4|no LAD
360a|no thyromegaly
3641|CTAB
3671|no wheezes
36c3|no crackles
36de|RRR
3771|nl S1 S2
37bc|no m/r/g
385f|Thin
3932|soft
3944|NT/ND
394f|+ BS
3a40|no rebound
3aa1|no guarding
3b8b|no masses
3c19|no CVA tenderness
3cb0|warm
3cf8|well perfused
3d4f|no pitting edema
3db5|dry skin throughout
3dd8|no rash
3ddc|awake and alert/oriented
3e23|GLUCOSE-95
3f12|UREA N-28*
3f81|CREAT-2.6*
3fd8|SODIUM-138
3fe4|POTASSIUM-2.8*
3fe7|CHLORIDE-109*
4099|TOTAL CO2-17*
412d|ANION GAP-15
41d4|ALT(SGPT)-60*
43fe|AST(SGOT)-116*
4460|ALK PHOS-46
4489|TOT BILI-0.3
4492|CALCIUM-4.9*
44f9|PHOSPHATE-1.0*
4534|MAGNESIUM-0.8*
4612|WBC-5.8
4649|RBC-3.18*
465c|HGB-9.8*
46fb|HCT-30.2*
4888|MCV-95
48a5|MCH-31.0
4a45|MCHC-32.6
4a97|RDW-16.9*
4b38|NEUTS-83.5*
4c97|LYMPHS-9.7*
4d4b|MONOS-5.3
4d70|EOS-1.3
4da7|BASOS-0.1
4dcc|PLT COUNT-335
4dd3|___ PTT-31.6
4e4e|GLUCOSE-108*
4e6f|UREA N-28*
4e77|CREAT-2.5*
4e8f|SODIUM-141
4ee4|POTASSIUM-2.7*
4f3c|CHLORIDE-107
4fed|TOTAL CO2-16*
510d|ANION GAP-21*
51a3|ALT(SGPT)-55*
5229|AST(SGOT)-113*
5239|LD(LDH)-735*
5268|TOT BILI-0.3
543e|ALBUMIN-3.2*
5495|CALCIUM-4.9*
55f2|PHOSPHATE-1.0*
5629|URIC ACID-2.8*
5654|TSH-0.53
566f|PTH-204*
567b|rapamycin-11.2
5698|CREAT-89
56ed|TOT PROT-107
5733|PROT/CREA-1.2*
5795|WBC-8.2#
57b8|RBC-3.19*
5818|HGB-10.1*
5913|HCT-31.3*
5a3a|MCV-98
5b07|MCH-31.6
5b2e|MCHC-32.2
5c1c|RDW-16.7*
5d33|PLT COUNT-335
5d75|COLOR-Straw
5d8b|APPEAR-Clear
5d8f|BLOOD-MOD
5e25|NITRITE-NEG
5eec|PROTEIN-30
5f77|GLUCOSE-NEG
5fda|KETONE-NEG
601c|BILIRUBIN-NEG
6077|UROBILNGN-NEG
6118|PH-6.0
6155|LEUK-NEG
6208|RBC-<1
6410|WBC-1
6495|BACTERIA-FEW
64c1|YEAST-NONE
6533|EPI-<1
65e0|MUCOUS-RARE
6775|WBC-4.6
679e|RBC-2.64*
67db|Hgb-8.4*
686a|Hct-24.9*
68e1|MCV-94
69f1|MCH-32.0
6aae|MCHC-33.9
6abe|RDW-16.7*
6b0e|WBC-3.5*
6b36|RBC-2.60*
6b5e|Hgb-8.1*
6c83|Hct-24.6*
6cb5|MCV-95
6d07|MCH-31.1
6d6f|MCHC-32.8
6df3|RDW-16.3*
6f9d|___ PTT-31.0
72b6|Glucose-90
7339|UreaN-23*
733e|Creat-2.1*
7388|Na-141
74ef|K-3.5
74f1|Cl-113*
75d1|HCO3-17*
75e5|AnGap-15
767a|Glucose-81
7a1f|UreaN-20
7b8a|Creat-1.9*
7baf|Na-140
7c64|K-4.0
7c9b|Cl-115*
7cd6|HCO3-15*
7d15|AnGap-14
7dc4|Glucose-104
7de9|UreaN-14
7def|Creat-1.7*
7f27|Na-138
8026|K-3.6
8058|Cl-109*
8068|HCO3-18*
809c|AnGap-15
80ab|Glucose-84
8134|UreaN-16
818d|Creat-1.7*
8408|Na-138
849f|K-4.2
854e|Cl-108
85d0|HCO3-21*
8624|AnGap-13
893d|Amylase-285*
89ad|Lipase-241*
89d7|Calcium-6.6*
8a9f|Phos-2.6*
8abc|Mg-1.8
8b1f|Calcium-7.3*
8b41|Phos-3.6
8bfb|Mg-2.2
8cf8|Calcium-6.7*
8d20|Phos-2.4*
8d40|Mg-1.6*
8d64|Calcium-7.3*
8deb|Phos-2.2*
8dfb|Mg-2.3
8e10|Folate-4.4
910e|calTIBC-103*
91d4|VitB12-200*
91f9|Ferritn-604*
9236|TRF-79*
9290|Cortsol-6.9
92b1|PSA-2.4
93f8|rapmycn-12.0
93fe|rapmycn-9.2
9421|rapmycn-7.8
9464|rapmycn-4.4*
94af|HCV VIRAL LOAD (Final ___: 3,240,000 IU/mL
94bf|small to moderate bilateral pleural effusions
955d|elevation of the right hemidiaphragmatic contour with apparent colonic interposition
9622|cardiac silhouette is within upper limits of normal in size
9669|No vascular congestion
967b|no acute pneumonia
96b3|Limited study due to technical factors discussed above
97b0|Pulmonary embolism within the right lower lobe
97d5|Anasarca
980d|No malignancy identified
9848|No evidence of DVT in the lower extremities
9933|Bilateral joint effusions
9991|ESRD s/p kidney transplant
99c8|HCV
9a17|Celiac Dz
9a1b|anorexia
9ab7|weightloss
9b65|sweats
9b9a|Acute on Chronic RF
9c68|severe electrolyte abnormalities
9cf8|weightloss was likely multifactorial in etiology including social, dietary and potentially underlying hypermetabolic etiology
9d0e|decreased access to the amount and types of food he consumes while at home
9d22|seen by social work
9e2e|homeless for sometime
9fc5|eating at friends homes
a04b|leave friends homes and sleep in the streets
a0f1|settled in his new apartment that he obtained through the housing authority
a163|purchased groceries
a16d|purchaseda a bed
a17b|phone connected in his apartment
a200|dx of Celiac on biopsy
a316|unable to get adequat gluten free foods
a337|kept on a gluten free diet while in house
a3d1|without melena or flank blood
a467|tan in color
a55a|Vit K was repleted
a6b5|vit D levels (25 and 1, 25) were sent and pending at the time of discharge
a77a|iron studies were also sent and pending at the time of d/c
a79e|limited malignancy work-up
a7f4|PSA was checked and found to be normal
a8ac|CT of the thorax was unremarkable for any suspcious masses
a8cc|decreased PO intake
a9ee|malabsorption secondary to celiac disease
aa9e|Vit D deficiency
ab19|hypokalemia
abd9|hypocalcemia
acc8|hypophosphatemia
acce|hypomagnesemia
ad65|without QT prolongation
ae74|elevated INR
aef7|Vit K was given for 3 days
b0da|PTH was elevated
b0f4|Vit D levels were sent and should be followed up as an outpatient
b128|started on Calcitriol
b13a|Vitamin B12
b15e|Calcium Carbonate
b307|Cr improved over his first night in setting of fluid hydration
b367|FeNA was 2.15% this AM
b3c3|FeUrea  71 in the setting of known CRI
b485|ARF resolved with IVF
b522|Cr returned to his baseline level of 1.7
b570|continued on ___ with level checks and adjusted during his hospital course
b5f3|Sirolimus dose was decreased
b616|kept on Azathioprine throughout his hospital stay
b627|transaminitis which is above recent baseline
b632|HCV viral load was found to be 3.2M IU/mL
b6a0|decreased from a viral load of  4.8M in ___
b6b2|BP Stable while in-house
b705|continued on clonidine
b785|metoprolol
b7a7|AZATHIOPRINE - 50 mg Tablet - 1 Tablet(s) by mouth once a day
b87f|CLONIDINE - 0.2 mg Tablet - 1 Tablet(s)three times a day
b8b1|MEGESTROL 625 mg/5 mL 1 teaspoon daily 1 teaspoon or 5 ml
b8f9|METOPROLOL TARTRATE - 50 mg Tablet - ___ Tablet(s) twice a day
b915|PANTOPRAZOLE 40 mg Tablet, 1 Tablet(s) by mouth once a day
b92b|POTASSIUM CHLORIDE 8 mEq Tablet 1 Tablet Sustained Release(s)every other day
b95e|SIROLIMUS 1 mg Tablet - 2 Tablet(s) by mouth once a day
b99b|CALCIUM-CHOLECALCIFEROL (D3) [OS-CAL 500 + D] - 500 mg (1,250mg)-400 unit Tablet - 1 Tablet(s) by mouth once a da
ba5b|Azathioprine 50 mg Tablet Sig: One (1) Tablet PO DAILY (Daily)
ba92|Clonidine 0.1 mg Tablet Sig: One (1) Tablet PO TID (3 times a day)
bb04|Metoprolol Tartrate 25 mg Tablet Sig: Three (3) Tablet PO BID (2 times a day)
bb68|Pantoprazole 40 mg Tablet, Delayed Release (E.C.) Sig: One (1) Tablet, Delayed Release (E.C.) PO once a day
bc60|Sirolimus 1 mg Tablet Sig: One (1) Tablet PO DAILY (Daily)
bcf4|Calcium Carbonate 500 mg Tablet, Chewable Sig: Two (2) Tablet, Chewable PO TID (3 times a day)
bded|Calcitriol 0.5 mcg Capsule Sig: One (1) Capsule PO once a day
bf17|Cyanocobalamin 500 mcg Tablet Sig: Two (2) Tablet PO DAILY (Daily)
bf54|Home
bf6a|Hypokalemia
bf72|Hypocalcemia
c073|Hypophosphatemia
c1b1|End stage renal disease s/p renal transplant
c249|Hepatitis C
c26d|Hypertension
c27f|Celiac disease
c2dd|hemodynamically stable
c339|afebrile
c35b|appropriate follow up
c377|several of your electrolytes were low
c3cb|poor intake of food
c409|repleted all the electrolytes you needed
c41a|gave you fluids to help your kidney function
c428|kidney function returned back to your baseline by the time you were discharged
c4e2|did not find any cause for your weight loss
c5bb|very small clot was found in your lung which was an incidental finding
c662|breathing and oxygenating perfectly
c6e4|no indication to treat this very small clot
c76d|Calcitriol
c78a|Vitamin B12
c7da|Calcium Carbonate
c7f5|dose of sirolimus (Rapamune) was changed to 1 mg by mouth daily

009f|male
00ca|No Known Allergies / Adverse Drug Reactions
010b|left hand clumsiness
0336|arm clumsiness
0375|right sided burr hold evacuation of subdural hematoma
048d|___ year old
04ce|male
05c6|HTN
0640|left armclumsiness
08b0|unable to get his arm into his leftsleeve
0930|hand lack the coordination
09c4|arm lack the coordination
09c6|seen in the ED
09fa|banged his head on a shelf
0d27|required staples for alaceration
0d5d|head CT was negative
0fda|mild intermittent HA
0fe5|no numbness
1021|no blurredvision
1077|no double vision
10d7|HTN
1114|hypothyroid
12e7|HLD
150a|non contributory family history
1724|BP 141/80
179e|HR 70
1843|R 18
186a|O2Sats 98%
187c|WD/WN
18b9|comfortable
18ed|NAD
190c|normocephalic
1a45|atraumatic
1ae7|Warm extremities
1aea|well-perfused extremities
1c02|Awake
1c23|alert
1c83|cooperative with exam
1d5b|normalaffect
1d71|Oriented to person
1e3e|Oriented to place
1f2c|Oriented to date
21c6|Speech fluent
2547|good comprehension
2600|good repetition
2608|Naming intact
26a4|No dysarthria
296d|No paraphasic errors
29c5|Cranial Nerve I Not tested
2afb|Pupils equally round and reactive to light 4 to 3mm bilaterally
2e9c|Visual fields are full to confrontation
3000|Extraocular movements intact bilaterally
31c8|without nystagmus
31f8|Facial strength intact and symmetric
3291|sensation intact and symmetric
3378|Hearing intact to voice
366b|Palatal elevation symmetrical
3693|Sternocleidomastoid normal bilaterally
3732|trapezius normal bilaterally
383c|Tongue midline
398e|without fasciculations
3999|Normal bulk bilaterally
3a25|Normal tone bilaterally
3b64|No abnormal movements
3b98|No tremors
3c46|+ Left Drift
3cad|Left Grip ___
3e69|Strength full power ___ in other muscle groups
3ec7|Intact to light touch bilaterally
406e|normal coordination on finger-nose-finger
4217|Right handedness
42fa|A&Ox3
43f2|PERRL
44a6|EOMs intact
44bb|face symmetrical
450e|No pronator drift
4541|Motor ___ throughout
4697|Incision c/d/i with sutures
46b3|low lung volumes
46ce|Borderline size of the cardiac silhouette
46d2|without pulmonary edema
4748|No pneumonia
4a0f|no pleural effusions
4cf3|No pneumothorax
4d40|Normal hilar structures
4e2a|Normal mediastinal structures
4e8c|decrease in mass effect
4f39|large pocket of post-op pneumocephalus
4f67|Small residual mixed subdural hematoma
507f|Midline shift decreased from 12 to 7 mm
5138|Patent basal cisterns
539c|No apparent ventricular system obstruction
54a3|No new focus of hemorrhage
55c4|No new large vascular territorial infarct
55f0|sub-acute right temporal infarct
5652|chronic right temporal infarct
57fe|___ year old
5872|male
58a0|presented to emergency department
595a|left arm clumsiness
59de|seen in the ED
5ac3|banged his head on a shelf
5b94|required staples for a laceration
5cf6|NCHCT was performed
5d34|extensive subacute SDH extending the righthemisphere
5d40|maximal thickness 2.5cm
5f47|11mm of Midline shift
6099|admitted to intensive care unit
6207|initiated on Keppra 500 mg BID
633a|taken to the operating room for burr hole drainage of large subdural hematoma
65a0|tolerated the procedure well
6699|electively extubated
682e|taken back to the intensive care unit for recovery
6949|slight L facial droop
69d9|L drift
6b3e|otherwise intact
6c8b|large amounts of pneumocephalus
6f7c|placed on a nonrebreather mask
713f|HOB was flat
7246|patient was stable on exam
73cb|HOB was elevated
7486|transferred to the floor
75c7|___ was consulted
7614|patient was intact on exam
775f|ambulating independently
7b89|___ signed off patient
7b99|discharged home in stable condition
7c20|unknown antihypertensive
7ce3|unkown Cholesterol med
7d11|Levothyroxine
7d69|Amlodipine 10 mg PO DAILY
7e51|Docusate Sodium 100 mg PO BID
80d8|LeVETiracetam 500 mg PO BID
825f|Levothyroxine Sodium 200 mcg PO DAILY
8340|Losartan Potassium 50 mg PO DAILY
85d8|OxycoDONE (Immediate Release)  ___ mg PO Q4H:PRN pain
85dc|Pravastatin 20 mg PO DAILY
8765|Home disposition
8984|subdural hematoma
8a00|Clear and coherent mental status
8a9b|Alert and interactive level of consciousness
8aa3|Ambulatory - Independent activity status
8ae4|wound was closed with sutures
8c0f|discharged on Keppra

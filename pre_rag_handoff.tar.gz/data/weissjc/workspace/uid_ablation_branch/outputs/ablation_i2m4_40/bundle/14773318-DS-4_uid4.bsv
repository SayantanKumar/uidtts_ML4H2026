000f|allergy to Sulfa
014e|allergy to morphine
015f|allergy to lisinopril
01c8|allergy to Betadine
025d|allergy to iodine
0273|fall
0336|Expired
03ae|s/p Bentall for type A aortic dissection
046b|on Coumadin
04ba|sustaining unwitnessed fall at rehab
052a|subdural hematoma
06b9|midline shift
06d8|DNR
0701|DNI
074c|DNH
0766|L leg pain after fall
07e5|non-verbal
08b7|very drowsy
0acb|head strike
0b8b|unsure of LOC
0cba|L intertrochanteric fracture
0e20|no dizziness before fall
0f37|no palpitations before fall
0f80|no weakness before fall
0ff4|numerous prior falls without fracture
0ff6|difficult recovery from open heart surgery
1128|spent 6mo at rehab
1156|transferred to another rehab center
12a4|expressed desire to remain DNR
12d9|expressed desire to remain DNI
12f9|extensive discussion of goals of care
138e|prognosis of intracranial bleed
13a5|need of surgical decompression
1534|decided to proceed with CMO
154b|Type A Aortic Dissection
15a9|s/p Bentall Procedure with hypothermic circulatory arrest
1689|coronary artery bypass grafting x 1
16bf|returned to OR for closing of chest
177c|occlusion of the proximal and mid segments of the left superficial femoral artery
17bf|returned to OR for mediastinal exploration with evacuation of pericardial and bilateral pleural effusions
180e|trach placement
181c|Atrial fibrillation
184b|Congestive heart failure
188d|hypertension
18cf|hypercholesterolemia
1c29|s/p back fusion
1c2d|breast cancer
1cc0|s/p bilateral mastectomies
1cd5|COPD
1d4d|Anxiety
1faa|Father with history of heart problems
20b1|Pulseless
214d|thin elderly woman
22ec|Unresponsive to any stimuli
230b|NCAT
234a|Pupils unreactive
2389|No corneal reflex
25b7|No occulocephalic reflex
26ba|No gag reflex
271a|No withdrawal reflex
2787|GCS 3
289c|Asystole
2947|Apneic
2993|soft abdomen
2b8a|non-distended abdomen
2c2e|non-tender abdomen
2d40|no masses
2d42|Cold extremities
2d5c|purple extremities
2dfe|mottled extremities
2e8a|pulseless extremities
2eda|PTT 36.3
32ea|PLT COUNT 166
33e0|NEUTS 88.0
3428|LYMPHS 5.5
3432|MONOS 5.5
345c|EOS 0.1
3553|BASOS 0.3
356f|AbsNeut 9.58
35af|AbsLymp 0.60
363d|AbsMono 0.60
3646|AbsEos 0.01
36da|AbsBaso 0.03
373b|WBC 10.9
375b|RBC 4.12
37af|HGB 11.2
37db|HCT 36.3
37e7|MCV 88
37eb|MCH 27.2
3806|MCHC 30.9
3a9e|RDW 17.5
3add|RDWSD 56.1
3b24|estGFR
3bb0|s/p Bentall for type A aortic dissection
3c46|on Coumadin
3d11|sustaining unwitnessed fall at rehab
3d5d|subdural hematoma
3daa|midline shift
3e7d|left hip fracture
3fb9|neurosurgical evaluation
3fbf|trauma evaluation
42ff|seen by neurosurgical service
4407|extensive goals of care discussion
452a|prognosis of intracranial bleed
4567|need for surgical decompression
464d|decided to proceed with comfort measures only
4668|admitted to Trauma/Acute Care Surgery service for comfort measures
47c9|mental status made dramatic improvement
4808|became more interactive and alert
480d|transferred to neuro/surgical ICU
49cc|neurological monitoring
4bd6|neurosurgical evaluation in ICU
4d88|transferred out of ICU to floor
4e1d|respiratory status was tenuous
4e9f|several desating events
4f47|inability to clear airway
5026|required respiratory suction at increasing intervals
51af|Discussion with family and palliative care
5208|better served under comfort care measures
52e6|officially withdrawn from intervention
547e|dose of narcotics for comfort measure
5485|angular breathing halted
5535|undistressed
5547|pronounced at 4:20PM
5552|notified
55df|altered mental status on presentation
5603|seen by neurosurgery
5793|deemed poor prognosis
57d4|midline shift
584d|degree of hematoma
585e|opted for comfort measures only
58eb|made good recovery
5941|much more alert and oriented on hospital day 2
5a21|transferred to ICU for monitoring
5acf|Repeat CT head showed blood redistributed and overall improvement
5c4e|developed seizures
5c8e|discussion with family about anti-epileptics
5ce6|agreed to start anti-epileptic medications
5f37|EEG monitor placed
5f62|continued to have subclinical seizures
607c|underwent right craniotomy for clot evacuation
60df|initially extubated
618e|intubated for persistent desaturations and tachypnea
61b7|deemed ready for trial of extubation
645d|extubated
654f|mental status improved slightly
6559|did not make dramatic recovery
6572|intermittent agitation
6649|delirium
686a|MRI/MRA performed demonstrated overall stable findings
688b|continued on antibiotics to treat pneumonia
6a40|electrolyte abnormalities repleted
6a42|started on daily Modafinil
6b99|coffee as needed
6c23|systolic blood goals maintained less than 160 mmHg
6c97|developed paroxysmal atrial fibrillation
6cc1|rate controlled on metoprolol and digoxin
6cdc|converted to normal sinus rhythm
6d67|frequent premature ventricular contraction
6d81|remained do not resuscitate
6e59|NPO
6f10|kept on intravenous fluids
7065|creatinine remained at baseline
70f6|electrolytes repleted as needed
7148|free-water flushes initiated for hypernatremia
728c|well-compensated chronic congestive heart failure
7370|diuresed
74ac|started on home dose of Lasix
7529|started on losartan
7614|stabilized on home therapy
765e|developed hospital acquired MRSA pneumonia
7681|bronchoalveolar lavage
76b2|treated with vancomycin
7765|treated with ceftazidime
7790|treated with flagyl
7878|blood cultures came back negative
7892|continued on vancomycin alone
7934|completed 8 day course of treatment
7aff|discussion with family about extubation
7b5e|extubate with plans to NOT reintubate
7bb3|aggressive chest physical therapy instead
7c14|developed right lower lobe collapse
7e77|mucous plugging
7ec4|no evidence of desaturation
7ed2|received aggressive chest physical therapy and suctioning
7f05|good response
7f89|maintained on albuterol nebulizers as needed
8068|maintained on ipratropium nebulizers as needed
809f|urinalysis positive for >182 white blood cells
80f2|large leukocyte esterases
80fc|empirically started on 3-day course of ceftriaxone
80ff|presumed urinary tract infection
81c9|follow-up urine cultures remained negative
821e|maintained on stress ulcer prophylaxis throughout ICU stay
834d|started on enteral nutrition with supplemental vitamins
838e|well tolerated
8448|developed diarrhea during hospitalization
8555|tested negative for clostridium difficile infection
85b6|did not require any transfusions
85cb|maintained on subcutaneous heparin for DVT prophylaxis
8641|boots for DVT prophylaxis
87e1|concern for heparin induced thrombocytopenia
8a9f|PF4 Ab was positive
8aa9|SRA negative
8ad8|deemed OK to receive heparin
8b7e|left intertrochanteric hip fracture
8ba0|altered mental status from subdural hematoma
8bb8|seizures
8bf7|delayed until hospital day 9
8d42|underwent open reduction and internal fixation of left hip fracture
8efe|better pain control
8f0e|stability
8f16|opportunities for mobility
8f73|tolerated procedure well
8fed|brought back to surgical ICU for monitoring
9145|worked with physical therapy
9180|Palliative care consulted
9253|social work services consulted
93a6|involved early in hospitalization
943e|facilitated multiple family meetings
94d2|decision to extubate despite waxing/waning mental status
9651|decision to maintain do not reintubate
9690|do not resuscitate in event of cardiac asystole
96f1|HYDROcodone-Acetaminophen (5mg-325mg) 1 TAB PO Q6H:PRN pain
9b77|Losartan Potassium 12.5 mg PO DAILY
9bb8|Metoprolol Tartrate 25 mg PO QAM
9bd9|Metoprolol Tartrate 6.25 mg PO QPM
9dbd|Aspirin 81 mg PO DAILY
9ec5|Atorvastatin 40 mg PO QPM
a1ac|Vitamin D 1000 UNIT PO DAILY
a2c3|Digoxin 0.125 mg PO DAILY
a39f|Furosemide 30 mg PO BID
a3c1|Ferrous Sulfate 325 mg PO DAILY
a4cf|LORazepam 0.25 mg PO BID
a6ad|Magnesium Oxide 500 mg PO QID
a83c|Omeprazole 20 mg PO DAILY
a8e8|Potassium Chloride 30 mEq PO BID
a920|TraZODone 37.5 mg PO QHS
a94c|Chlorpheniramine Maleate 12 mg PO BID
a9cd|Aspirin 81 mg PO DAILY
a9de|Atorvastatin 40 mg PO QPM
aa1f|Chlorpheniramine Maleate 12 mg PO BID
aa83|Digoxin 0.125 mg PO DAILY
ab4a|Ferrous Sulfate 325 mg PO DAILY
ac48|Furosemide 30 mg PO BID
ae14|HYDROcodone-Acetaminophen (5mg-325mg) 1 TAB PO Q6H:PRN pain
af4e|LORazepam 0.25 mg PO BID
b0de|Losartan Potassium 12.5 mg PO DAILY
b3ec|Magnesium Oxide 500 mg PO QID
b5f5|Metoprolol Tartrate 25 mg PO QAM
b608|Metoprolol Tartrate 6.25 mg PO QPM
b65c|Omeprazole 20 mg PO DAILY
b6a3|Potassium Chloride 30 mEq PO BID Hold for K >
b79f|TraZODone 37.5 mg PO QHS
b874|Vitamin D 1000 UNIT PO DAILY
b9ad|Expired
ba79|Subdural hematoma
ba81|midline shift
bc32|Left hip fracture
bd1e|Expired

001a|male
0081|No Known Allergies
00fb|Adverse Drug Reactions
0112|Intracranial hemorrhage
0142|Left craniotomy for clot evacuation
0202|male
038d|transferred from ___ ___
03ea|fall
0427|altered mental status
0493|intoxication
051b|small left SDH
06c5|SAH
06e4|transferred to ___ for Neurosurgicalevaluating
071d|unable to participate in ROS due to intoxication
0773|atrial fibrillation
0859|hyperlipidemia
0920|alcohol abuse
0a14|non-contributory
0b85|GCS 12
0cb6|Not intubated
0e00|intoxicated
0e2f|scattered abrasions
0f6c|c-collar
0f83|warm
0fb0|well perfused
0fee|eyes open to voice
10ed|incomprehensible sounds
10f0|Pupil ___ sluggish
1124|pupil ___ sluggish
11ba|Oriented to person only
131e|unable to tell month, year,location
134b|incomprehensible
1371|patient not cooperative for cranial nerve tests
139a|patient moving all extremities
13b2|intermittent commands
142a|awake
142e|not following commands
1433|No verbal response
1541|Intermittently sleeping
156f|No respiratory distress
1619|Moving all extremities spontaneously
1646|Large left temporal intraparenchymal hemorrhage measuring up to 8.3 cm
166e|extensive mass effect on the left lateral ventricle
168a|midline shift to the right of approximately 1 cm
1828|uncal herniation
18a6|moderate left subdural hemorrhage
18bd|small bilateral subarachnoid hemorrhages
1990|tiny right intraventricular hemorrhage
19ce|Curvilinear prominence of vascular structures with a focal cut off in the inferior division of the left MCA
1a22|vascular malformation
1a6e|aneurysmal rupture
1a7e|Moderate to severe intracranial atherosclerotic disease
1b39|Small right subdural hematoma
1b95|Expected postoperative appearance following left frontotemporal craniotomy for evacuation of a left temporal lobe hematoma
1c2e|Expected evolution and redistribution of multi compartment intracranial hemorrhage
1cff|evidence of new or enlarging hemorrhage
1d15|Interval decrease in rightward midline shift, now measuring 4 mm
1d64|status post left pterional craniotomy for evacuation of left temporal lobe parenchymal hemorrhage
1de9|expected redistribution of blood product
1f09|residual multi compartment hemorrhage
1f41|No new hemorrhage
1fac|No acute large territory infarct
20b1|improved rightward midline shift
20ed|decreased mild enlargement of the right temporal horn
2130|Residual left uncal herniation
2166|Previously seen curvilinear enhancement along the inferior division of the left MCA is no longer seen
23d7|tip of the endotracheal tube lies approximately 4.5 cm above the carina
24e1|Nasogastric tube is been removed
250a|Extensive pleural plaquing
250e|asbestos related disease
254b|no evidence of acute focal pneumonia
2576|vascular congestion
25b2|Lungs are grossly clear
2786|Heart size normal
2986|Extensive asbestos related pleural plaque
2a29|Pleural effusion minimal on the left
2bda|No pneumothorax
2dca|No evidence of pulmonary embolism
2eb7|aortic abnormality
2f74|Extensive mucous plugging in the left lung
2fe8|Patchy and confluent nonenhancing consolidations in the right upper lobe
3102|pneumonia
3233|acute aspiration
3348|Incompletely evaluated dilatation of the common bile duct
35a0|main pancreatic duct
35db|hypodense lesion in the region of the pancreatic head
374c|Expected postsurgical changes for evacuation of a left temporal lobe intraparenchymal hematoma
3821|Unchanged volume residual left temporal hemorrhage products
3890|No new or enlarging hemorrhage
3907|No new infarcts
3a3c|Slight interval improvement of mass effect
3ab0|Multifocal airspace consolidation
3bca|improvement of the right upper and left upper lobes
3bff|stable bilateral pleural effusions
3c46|monitoring and support devices are stable
3cbe|taken a better inspiration
3e11|bilateral pulmonary opacifications are less prominent
3f66|costophrenic angles sharper
4334|Pleural calcification
4748|lung volumes have decreased
479e|crowding of the vascular and bronchial structures
49b3|increase in radiodensity of the right hemithorax
4a18|no substantial change
4ab9|Monitoring and support devices are in stable position
4ba8|Borderline size of the cardiac silhouette is unchanged
4cdf|Mild-to-moderate pulmonary edema has increased
4cf5|Large right pleural effusion
4db0|probably small left effusions are grossly unchanged
4eb0|Opacities in the right upper and right lower lobes have minimally increased
4efb|no evident pneumothorax
4f19|Callus formation
4f76|deformity secondary to a spiral fracture in the left humeral mid diaphysis is unchanged
5042|Cardiomediastinal contours are unchanged
50fc|Bilateral calcified pleural plaques
510d|Pulmonary edema has markedly improved
5149|Mild cardiomegaly is stable
5182|ET tube is in standard position
538a|Left subclavian catheter tip is in the upper to mid SVC
5412|no pneumothorax
548b|NG tube tip is in the stomach
54f1|Pleural plaques
552b|Increasing opacity in the right mid lung
55a6|atelectasis
55e9|pneumonia
55ed|Bilateral pleural effusions larger on the right side likely stable
565a|Increasing opacities in the left lower lobe
5680|increasing atelectasis
583c|effusion
5986|Multifocal opacities throughout the right lung are stable
5aaa|Cardiomegaly is unchanged
5b37|Lines and tubes are in place standard position
5ba7|Previous moderate pulmonary edema has improved
5c2a|Heart size is normal
5c4f|no large pneumonia
5d46|Heavy asbestos related pleural calcification
5d5d|Heart size normal
5d61|No pneumothorax
5d82|Small pleural effusions are presumed
5d9a|No pneumothorax
5e9c|Expected evolution of postsurgical changes status post left craniotomy
5f79|Expected evolution and redistribution of multi compartment hemorrhage
6155|left residual temporal lobe hematoma
61d2|subarachnoid hemorrhages
620e|intraventricular extension
6377|No evidence of new or enlarging hemorrhage
6381|No pulmonary vascular congestion
63b8|pulmonary edema
64c2|Transfered from ___ s/p fall
64f8|Found to have SDH
66b2|Transferred for NSURG eval
6713|emergently brought from the ED to the operating room on ___ for a left sided craniotomy for evacuation of SDH/IPH
6779|CTA had been done prior to the OR
6840|repeated post operatively on ___
6860|No vascular abnormality was noted
690b|started on 3% saline for treatment of cerebral edema
69a8|it was stopped
6a51|stable post surgical changes with interval improvement in mass effect
6db3|Patient's mental status remained poor throughout his ICU course
6ec1|Repeat CT head obtained on ___ was stable
6fd3|Alcohol withdrawal
70f5|Phenobarbital taper which started on ___
712b|phenol taper was stopped
7240|continued on daily thiamine
72db|Agitation
72f2|managed with Seroquel
7802|flipped to AFib with RVR
79fe|hypoxemia from his pneumonia
7a7b|given metoprolol IV
7ad3|dilt bolus followed by a drip
7b62|converted to sinus bradycardia
7bb7|back into AFib w RVR
7bf6|given amiodarone bolus with drip
7c9a|continued in RVR
7d91|required adenosine 6mg, 12mg during the event
7ef1|became hypotensive
7fdb|neo gtt
8036|cardioversion x 3
80e2|AL placed
8275|Chest xray obtained which showed pulmonary edema
8342|given some Lasix
83de|went back into Afib with RVR
8494|BP decreased to low 40's
84de|cardioverted x3 unsuccessfully
859e|levophed gtt was started
85c2|chest compressions were started
8671|vasopressin gtt added
87b5|esmolol gtt added
87ec|Cardiology was consulted
887a|bedside echo obtained
8882|no obvious cardiac issue that would be causing rhythmic issues
8972|continued on esmolol
8992|amiodarone
8aea|neo
8ba9|vasopressin drips
8e05|Vasopressin weaned
8e17|neo weaned
8e23|discontinued on ___
8f73|in Afib with RVR
9029|esmolol
90d0|diltaziem drips
90e7|converted back to sinus
90e8|Esmolol gtt was weaned off as of ___
916d|PO metoprolol
91ad|amiodarone
9286|developed a fever of 102.4
92ab|pan-culture was sent
92ff|probable RUL PNA
9354|started on zosyn
93ad|Vanco
94f3|culture data obtained by bronchoscopy
950a|Vancomycin from ___
9523|Zosyn from ___
9554|Cipro from ___
95a6|developed ventilator associated pneumonia
9638|hypoxemia
9875|required re-intubated for hypoxia and increased work of breathing
9ac3|Lasix was held
9b04|bronchoscopy was done with with copious secretions
9b06|sent for cultures
9c5b|No PE
9cac|left mucus plug
9cc7|R consolidation
9d56|dilated common bile duct
9ed3|possible pancreatic head mass
9ed9|possible outpatient MRCP was recommended
a0e4|furosemide was re-initiated for pulmonary congestion
a28b|p:f ratio improved
a2c3|weaned to PSV
a395|extubated on ___
a45b|decided the patient would not want to be reintubated should he fail extubation
a479|feels that the patient would not want a feeding tube or reintubation
a4cf|Plan for hospice screening was initiated
a5cc|significant respiratory compromise with increased secretions
a980|required frequent suctioning by nursing staff
aab1|determined the patient would be CMO
ab2a|Palliative care was consulted
ac32|Dilaudid was given for respiratory distress
acd9|Ativan was given for agitation
ad28|accepted at a hospice house
ad5f|all non comfort medications were discontinued
ad6b|Acetaminophen 650 mg PR Q6H:PRN pain/anxiety
ad70|Glycopyrrolate 0.1 mg IV Q6H:PRN excess secretions
ade9|HYDROmorphone (Dilaudid) 0.5-1 mg IV Q2H PRN  Pain - Moderate
adfc|LORazepam 0.5-2 mg IV Q2H:PRN anxiety/distress
ae50|Extended Care Facility
af23|Intracranial hemorrhage
b059|Confused - always
b1af|Lethargic but arousable
b1f2|Bedbound
b2aa|underwent a surgery called a craniotomy to have blood

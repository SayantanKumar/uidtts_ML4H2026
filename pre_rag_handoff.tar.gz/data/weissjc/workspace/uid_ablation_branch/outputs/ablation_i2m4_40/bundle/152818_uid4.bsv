003f|male
0286|62 year old
0396|gentleman
044c|underwent an exercise treadmill test for screening
04a7|positive for EKG changes
05c3|shortness of breath
0730|no history of chest pain
0819|no history of myocardial infarction
09f2|referred to Hospital1 for cardiac catheterization
0a52|Cardiac catheterization
0b4f|ejection fraction of 50%
0d7b|left ventricular end diastolic pressure of 20
0e10|90% left anterior descending lesion
0fcc|80% left circumflex lesion
0fe3|80% mid right coronary artery lesion
1170|80% distal right coronary artery lesion
1202|referred to Dr. Last Name for coronary artery bypass grafting
12c3|Hypertension
1474|Type 2 diabetes mellitus
15d0|Hypercholesterolemia
1651|Thirty pack year tobacco history
16ca|quit smoking one month ago
18f2|Gout
1a6a|Gastroesophageal reflux disease
1b08|History of salivary gland removal
1c39|No known drug allergies
1e7d|Glucophage XR 1000 mg p.o. q. day
1ec8|Avandia 4 mg p.o. q. day
1f1f|Diovan 160 mg p.o. q. day
213f|Atenolol 25 mg p.o. q. day
2162|Lipitor 10 mg p.o. q. day
2520|Niaspan 500 mg p.o. q. day
254c|Enteric-coated aspirin
262d|admitted to Hospital1
265f|underwent a coronary artery bypass graft times four
2890|left internal mammary artery to left anterior descending
2adb|saphenous vein graft to right coronary artery
2b01|saphenous vein graft to PDA
2d01|saphenous vein graft to obtuse marginal
2f6a|transferred to the Intensive Care Unit
306a|stable condition in ICU
30ac|Neo-Synephrine infusion
31ce|weaned from mechanical ventilation
32ba|continued to require Neo-Synephrine
331c|maintain systolic blood pressures greater than 100
3420|hematocrit was noted to be 23.1
37d9|transfused one unit of packed red blood cells
385c|given a dose of Lasix
38c1|Neo-Synephrine was weaned off
3986|chest tubes were removed
39ff|started on low dose Lasix
3c1f|started on Lopressor
3c83|tolerated low dose Lasix and Lopressor well
3ee6|transferred from the Intensive Care Unit to the regular part of the hospital
3f13|working with Physical Therapy
3f20|ambulate 500 feet
403a|climb one flight of stairs
4053|hemodynamically stable
415b|without requiring any oxygen
41bd|continued to remain hemodynamically stable
431f|epicardial pacing wires were removed
43df|cleared for discharge to home
440b|Temperature maximum 99.8 F
44c7|pulse 76
4538|sinus rhythm
4696|blood pressure 107/61
47ed|respiratory rate 18
4999|room air oxygen saturation 95%
49c2|weight on 4-19 was 101.4
49fc|weighed 100 kilograms preoperatively
4b7e|White blood cell count 5.8
4c7d|hematocrit 23.5
4f96|platelet count 118
5258|Sodium 140
5281|potassium 3.9
52c5|chloride 103
54e4|bicarbonate 18
553b|BUN 11
563c|creatinine 0.8
5710|glucose 144
5761|PT 29
57c8|INR 1.1
585f|PTT 22.9
5912|alert and oriented times three
59fc|anxious
5a5e|Neurological examination is non-focal
5b01|Heart is regular rate and rhythm
60bb|without rub or murmur
6276|Respiratory breath sounds are clear bilaterally
63b9|breath sounds decreased at the bases
6403|positive bowel sounds
647f|abdomen soft
64d8|abdomen nontender
64e0|abdomen nondistended
6619|tolerating a regular diet
67d3|Sternal incision staples are intact
69f4|incision open to air
6b43|Incision is clean and dry
7031|no erythema at sternal incision
7183|sternum is stable
719b|moderate amount of ecchymosis at vein harvest site
71bc|minimum amount of serosanguinous drainage at vein harvest site
7206|no erythema at vein harvest site
7226|Coronary artery disease
73cc|Status post coronary artery bypass graft times four
750e|Type 2 diabetes mellitus
7626|Postoperative anemia
7839|Atenolol 25 mg p.o. q. day
7a8d|Lasix 20 mg p.o. q. day times seven days
7f6d|Potassium chloride 20 mEq p.o. q. day times seven days
803d|Niferex 150 mg p.o. q. day times one month
80fe|Vitamin C 500 mg p.o. twice a day times one month
820f|Multivitamin one p.o. q. day times one month
822d|Ambien 5 mg p.o. q. h.s. p.r.n.
826c|Colace 100 mg p.o. twice a day
83a8|Avandia 4 mg p.o. q. day
8579|Glucophage 500 mg p.o. twice a day
85b0|Lipitor 20 mg p.o. q. day
86ac|Zantac 150 mg p.o. twice a day
86bf|Niaspan 500 mg p.o. q. day
8839|Percocet 5/325 one to two p.o. q. four to six hours p.r.n.
89da|discharged to home
8b3e|Stable condition
8bdc|follow-up with Dr. Last Name 2912 in one to two weeks
8e78|follow-up with Dr. Last Name in three to four weeks
8ee9|return to Hospital Ward Name on or about 5-5 to have his staples removed

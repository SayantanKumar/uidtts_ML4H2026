0070|M
0243|60 year old
0258|gentleman
02f9|presented
051d|hematemesis
05db|hemoptysis
06e4|found to have a left lower lobe mass
0b3b|underwent bronchoscopy with washings
0c7b|showed to be negative for malignant cells
1286|showed atypical bronchial epithelial cells, likely to be reactive
1592|Rectal fissure
1748|Lumpectomy of the left breast nodule
1830|Knee surgery
1bc3|Hand surgery
1c76|no known drug allergies
1ff0|no home medications
2198|essentially negative
26a5|no acute distress
29f6|afebrile
2ab4|clear to auscultation bilaterally
2ccb|regular rate
2d61|rhythm
2ea5|benign
304c|no mass
31b1|well perfused
3402|warm
34d6|taken to the Operating Room
3781|underwent a left bronchoscopy
391b|lower lobectomy of the left side
39a2|postoperative bleeding
39b5|taken back to the Operating Room
3ed3|repair of the left pulmonary artery
3fbe|transferred to the CSRU
445a|intubated
44dc|stable condition
4595|Vascular Surgery Service was also consulted
47de|received 13 units of packed red blood cells
49cd|four units of fresh frozen plasma
4ad4|one unit of platelets
4b39|blood loss of 1500 cc
4e16|stable on the floor
50a4|monitoring of hematocrit within a normal stable range
5110|extubated
55a4|hypertension
596a|transferred to the floor
5aca|stable condition
5b04|managing his epidural
5e72|tolerating a regular p.o. diet
60cc|making adequate amount of urine
60e2|essentially unremarkable
62dc|discontinued
6307|discharged to home
6325|follow-up with Dr. [**Last Name (STitle) 952**] in the office
6408|discharged to home
65f4|pain medication which is percocet
661f|Stable
6812|To home without service
6daf|Left lung mass status post resection
